# False Positive Database

Signature: first 8 characters of SHA256(`status:body-length:body-substring`). This is a triage hint, NEVER sufficient to automatically dismiss a finding without context comparison.

## Findings Strength Verification
1. Scope confirmation. 2. Repeatability. 3. Server-side observable effect. 4. Relevant control context. 5. Proven rather than presumed impact. 6. Reproducible evidence.
