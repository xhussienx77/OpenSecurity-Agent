# Learned Patterns

| Vulnerability | Trust boundary | FP trap | Source |
|---|---|---|---|
| bfla | server authorization on state-changing API action | client UI hiding functionality does not establish server access control failure | local educational sample, not a retrieved disclosure |
| IDOR | object ownership between users | a public/shared document may intentionally be readable | local educational sample, not a retrieved disclosure |
| business-logic | business state managed on server | pending versus finalized state differences | local educational sample, not a retrieved disclosure |
| cors | browser cross-origin read permission | wildcard headers on public responses do not prove impact | local educational sample, not a retrieved disclosure |
| stored-xss | untrusted markup rendered to another session | markup reflected into plain text has no script execution | local educational sample, not a retrieved disclosure |
