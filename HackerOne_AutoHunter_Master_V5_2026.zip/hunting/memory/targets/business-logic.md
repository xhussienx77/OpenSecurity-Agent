# BUSINESS-LOGIC Target Memory

- Verify in-scope program authorization and technique permissions.
- Identify the asset, trust boundary and legal owned-account control.
- Capture a control response before the smallest permitted comparison.
- Record false-positive alternatives and minimum proof of real impact.
- Update this checklist using attributed accepted/duplicate/FP triage outcomes only.
