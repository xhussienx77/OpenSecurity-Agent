# Context Ledger

Timestamp | Target | Surface | Skills loaded | Test | Result | Evidence | Next action
---|---|---|---|---|---|---|---
