# Methodology

Use explicit scope, independent baselines, owned-account controls, low-volume checks, differential analysis and verified impact.
