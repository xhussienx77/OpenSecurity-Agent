# Report Lessons

Distilled from the local, provenance-tagged public study corpus. Not tested findings.

## Public-style Case Study: API Role Enforcement Drift
- Entry point: owned project configuration endpoint
- Boundary: server authorization on state-changing API action
- Proof: compare permitted and blocked actions using owned project
- FP trap: client UI hiding functionality does not establish server access control failure
- Source: local educational sample, not a retrieved disclosure

## Public-style Case Study: Object Ownership Mismatch
- Entry point: owned document read endpoint
- Boundary: object ownership between users
- Proof: compare the same user-owned document across two tester accounts
- FP trap: a public/shared document may intentionally be readable
- Source: local educational sample, not a retrieved disclosure

## Public-style Case Study: State Transition Mismatch
- Entry point: controlled discount redemption flow
- Boundary: business state managed on server
- Proof: compare allowed and attempted state changes in test environment
- FP trap: pending versus finalized state differences
- Source: local educational sample, not a retrieved disclosure

## Public-style Case Study: CORS Read Access Check
- Entry point: authenticated account profile endpoint
- Boundary: browser cross-origin read permission
- Proof: demonstrate controlled test-origin access to own non-public response
- FP trap: wildcard headers on public responses do not prove impact
- Source: local educational sample, not a retrieved disclosure

## Public-style Case Study: Rendered Markup Under User Control
- Entry point: user-owned text field
- Boundary: untrusted markup rendered to another session
- Proof: safe inert render marker in controlled viewer, with no data collection
- FP trap: markup reflected into plain text has no script execution
- Source: local educational sample, not a retrieved disclosure

