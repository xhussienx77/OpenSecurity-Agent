# Wordlists

Prefer bounded application-specific paths. Never apply a broad wordlist without explicit testing permission, a documented reason and a low rate cap.
