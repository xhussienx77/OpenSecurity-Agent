# HackerOne AutoHunter Master V5

Built from the full user specification in `spec/ORIGINAL_USER_SPEC.md`, with original V4 Burp Bridge and scanning engine preserved under `integrations/v4/`. This is a supervised research framework, NOT a guaranteed vulnerability finder. No live HackerOne program was scanned.

## Quick start (Python 3.10+)
```bash
python scripts/skill_registry.py check
python scripts/skill_registry.py resolve --scenario 'API tenant object ownership' --mode test --paths-only
python scripts/runtime_preflight.py --target test.example.com --scenario 'API tenant object' --mode hunt --workspace testing/example.com/test.example.com --scope-file config/scope.example.json --ensure-session
bash scripts/update.sh --offline
python -m pytest scripts learning_engine -q
```
The sample scope intentionally denies active testing; replace it with an actual program policy reviewed by a human before testing.

## Navigation
- `SKILL.md`: agent installation front door.
- `AGENTS.md`: full mandatory constitution.
- `prioritization.md`: impact-based decision system.
- `agent-briefing.md`: session boot.
- `runtime/`: canonical registry plus OpenCode/Antigravity contracts.
- `.opencode/commands/`: 8 OpenCode command definitions.
- `skills/` and `.agents/skills/`: full mirrored skill library.
- `learning_engine/`: persistent SQLite-backed five-hook learning engine.
- `scripts/`: resolver, scope preflight, update pipeline and tests.
- `writeups/`: sample corpus plus reproducible processing.
- `integrations/v4/`: archived and reusable prior scanner and Burp integration.
- `spec/IMPLEMENTATION_MATRIX.md`: implementation and external limitations.

## Honest limitations
The user spec contains strong claims about autonomous testing, exploit bypasses, credential access, command injection behavior, and exact historical heuristics. These must remain subject to program policy, human verification and supported platform capabilities. The command files alone cannot spawn five real sub-agents, install plugins, use Chrome, or log into accounts. External runtimes, Jython, `npm install`, Burp GUI and real target tests are not available in this build. Do not treat generated reports as proven findings without independent validation.
