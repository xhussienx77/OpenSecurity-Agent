# البداية - HackerOne AutoHunter Master V5

1. اقرأ `README.md` و`SKILL.md` و`spec/IMPLEMENTATION_MATRIX.md`.
2. ظبط سياسة البرنامج المسموح والنطاق في ملف JSON اعتمادًا على سياسة HackerOne، وما تفعلش فحص تلقائي على أي هدف غير مصرح به.
3. نفذ `python scripts/skill_registry.py check` ثم `python scripts/skill_registry.py resolve --scenario "api authorization" --mode test --paths-only`.
4. نفذ preflight وحدد `--scope-file` و`--target` و`--workspace` المناسبين؛ لو ظهر BLOCKED متكملش.
5. لو هتستخدم Burp اقرأ `docs/BURP_INTEGRATION.md`؛ الكود القديم محفوظ في `integrations/v4/`.
6. استعمل `/hunt` و`/report` داخل OpenCode فقط بعد تهيئة OpenCode والتأكد من ظهور الـCommands. لا تضع بيانات الدخول داخل `login.md`.
7. التقرير مسودة فقط، لازم تتحقق بنفسك من الدليل وتأثير الثغرة قبل إرساله.
