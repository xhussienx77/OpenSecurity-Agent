# Project Layout

```text
hunting/
├── AGENTS.md                      # Master constitution
├── prioritization.md              # Investigation priority vs impact
├── agent-briefing.md              # Session start
├── SKILL.md                       # Entry point for external agent
├── README.md, START_HERE_AR.md
├── opencode.json, .opencode.json
├── .opencode/
│   ├── commands/{hunt,recon,scan,update,report,dorking,understand,mindmap}.md
│   └── package.json
├── runtime/
│   ├── registry.json
│   ├── opencode/{loader,ORCHESTRATION,manifest}.md
│   ├── opencode/agents/{recon,dorking,js,fuzzing,understand}-agent.md
│   ├── antigravity/{loader,manifest}.md
│   ├── AGENT_SKILL_ACTIVATION.md
│   └── AGENT_INIT_TEMPLATE.md
├── skills/{55 mirrored skill guides}.md
├── .agents/skills/{55 names}/SKILL.md
├── scripts/{skill_registry,runtime_preflight,update_pipeline,report_draft}.py
├── scripts/update.sh
├── scripts/test_*.py
├── learning_engine/{engine.py,scoring/,schemas/,docs/,scripts/,test_engine.py}
├── memory/{report-lessons,patterns,methodology,FALSE_POSITIVE_DB,CONTEXT_LEDGER}.md
├── memory/targets/{6 checklist files}.md
├── writeups/{raw/,processed/,index.md}
├── references/{skill-router,VERIFICATION_CHECKLIST,MASTER_CONFIG,CONFIG_INDEX,ownership-map,reference-map}.md
├── integrations/v4/               # All prior V4 files including Burp extension
├── docs/BURP_INTEGRATION.md
├── config/scope.example.json
├── testing/, wordlist/, logs/
├── .github/workflows/test.yml
└── spec/{ORIGINAL_USER_SPEC,IMPLEMENTATION_MATRIX,TEST_RESULTS,PROJECT_TREE}.md
```
