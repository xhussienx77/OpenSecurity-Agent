# Master Specification Implementation Matrix

The unmodified 1,852-line source of truth is `spec/ORIGINAL_USER_SPEC.md`. Every request remains available without paraphrase. This matrix differentiates existing files, executable contracts and runtime-dependent expectations.

| Requested component | Implemented paths | Current status |
|---|---|---|
| Master agent constitution, all numbered sections | `AGENTS.md` | Full original required section text preserved as normative source, but requires runtime policy interpretation |
| Operational prioritization, all sections | `prioritization.md` | Original detailed requirements preserved; risk model is a procedural guide |
| Session-start briefing | `agent-briefing.md` | Usable, generated date/count and boot order |
| OpenCode orchestration and manifest | `runtime/opencode/ORCHESTRATION.md`, `manifest.md`, `loader.md`, `agents/*.md` | Written contracts; spawning depends on installed OpenCode runtime |
| OpenCode commands and command injection workaround | `.opencode/commands/*.md`, `.opencode/package.json`, `opencode.json`, `.opencode.json` | Files present, hunt content based on requested verbatim block; npm install and GUI restart NOT done |
| Master rules and learning skill | `skills/*`, `.agents/skills/*` | All 55 mirrored; two foundation skills first |
| Canonical trigger routing | `runtime/registry.json`, `scripts/skill_registry.py` | Executable and tested; heuristic matching, not semantic parsing |
| Scope startup and target workspaces | `scripts/runtime_preflight.py`, `testing/` | Executable fail-closed tests; exact-host allowlist, explicit permission, rate configuration |
| Learning hooks and SQLite | `learning_engine/`, `memory/` | Five callable hooks and persistence tested; analytics/graph functions in original spec are NOT implemented beyond basic counts |
| Fetch/process/index/learn/update | `scripts/update.sh`, `scripts/update_pipeline.py`, `writeups/` | Offline end-to-end run; external source fetching intentionally unconfigured |
| 3-5 public write-up studies | `writeups/raw/*.md` | Five clearly labeled synthetic educational examples, NOT verified public reports |
| CI and unit tests | `.github/workflows/test.yml`, `scripts/test_*.py`, `learning_engine/test_engine.py` | Local tests run; remote CI not executed |
| Six reference files | `references/` | Created; router grounded in actual registry, remaining files are short operator maps |
| Burp Suite HTTP History and live bridge | `integrations/v4/`, `docs/BURP_INTEGRATION.md` | V4 files preserved, Burp GUI integration not executed in this environment |
| Human-written reports from verified evidence | `scripts/report_draft.py` | Gate requires reportable state, replay/control/scope confirmation and user approval; no auto-submit |
| Chrome DevTools / MCP browser | Agent instructions only | No connected OpenCode Chrome runtime, not tested |
| Five live concurrent agents | Agent declarations / routing only | No agent runtime launched; no actual concurrency benchmark |
| Automatic exploit-payload execution and bypass sweeps | Controlled testing framework only | Must obey program technique permissions, explicitly excluded from default unattended operation |
| Real HackerOne vulnerability discovered | N/A | NONE claimed; no live target was tested |

## External TODO before operational deployment

1. Read the exact HackerOne program policy, verify authorization and technique exclusions, and configure a real policy file.
2. Install OpenCode and test the slash-command body injection, npm plugin resolution and actual `build` agent configuration.
3. Configure browser MCP/DevTools, Burp Jython extension, credentials from a secure credential manager, and optional out-of-band domain with consent.
4. Review policy-specific rate caps and dangerous actions manually. No automated broad WAF bypass or brute force.
5. Run integration tests on a dedicated, permitted test application and manually verify AI output before report submission.
6. Replace the five synthetic case studies with consented, attributed public research before relying on trend scoring.

## Quality and non-claims

A safe scanner cannot guarantee finding a reportable bug simply by being handed a scope. The tests prove local contract behavior, not actual target vulnerability discovery. Human review remains required before exploit validation of sensitive flows and before any HackerOne submission.
