---
name: hackerone-autohunter-master
version: 5.0.0
description: Orchestrate scoped, evidence-driven HackerOne research, Burp review, controlled validation, learning and human-reviewed reports.
---

# HackerOne AutoHunter Master

Read `agent-briefing.md` before all else; then `AGENTS.md`, `prioritization.md`, `runtime/opencode/loader.md`, `runtime/registry.json`. Do not silently load the full skill library. Run preflight and the scenario resolver for each new surface. Use only explicitly authorized scopes and techniques. Preserve evidence, redact secrets, verify impact independently and draft human-readable reports only when explicitly requested. Never publish a report automatically.

## Burp Suite
Use the V4 bridge in `integrations/v4/`, see `docs/BURP_INTEGRATION.md`. Review historic and live in-scope requests; route to authorization, API, JS and workflow specialists. Avoid autonomous replay of destructive or identity-changing actions.

## Commands
OpenCode: `/hunt`, `/recon`, `/scan`, `/update`, `/report`, `/understand`, `/mindmap`, `/dorking`. CLI: `python scripts/skill_registry.py check`; `python scripts/runtime_preflight.py --help`; `bash scripts/update.sh --offline`.

## Reporting
OBSERVATION ≠ CONFIRMED. A readable report must cite exact relevant request/response evidence, explain authorization context, reproduction, demonstrated impact and limitations. Human review and submission only.
