---
description: Consolidate scoped target intelligence into a mindmap
agent: build
---

# Mindmap — $ARGUMENTS

Target or notes:
$ARGUMENTS

1. Read `agent-briefing.md`, `AGENTS.md`, `prioritization.md` and `runtime/opencode/loader.md`.
2. Run `python scripts/skill_registry.py check` and preflight with `--mode recon`. Stop on scope rejection.
3. Run `python scripts/skill_registry.py resolve --scenario "$ARGUMENTS" --mode recon --paths-only`; load every returned path or log a reason for deferral.
4. Inspect existing workspace notes. For browser interaction use both available chrome-devtools-mcp and Chrome DevTools, when connected. Never claim browser tools were available without checking.
5. Enforce exact-host scope, program policy, rate limits, exclusions and owned-account-only authentication. Never send brute-force, destructive, third-party, or denial-of-service requests.
6. Analyze evidence conservatively; isolate baseline, controls and candidate differences. Treat scanner signals as leads.
7. Record results, deferred skills, coverage and the next safe test.
8. Write artifacts only inside `testing/<root-domain>/<subdomain>/` (or shared `writeups/` and `memory/` for update).
9. Output scope, source provenance, executed steps, evidence, leads versus confirmed findings, stopped/deferred tasks and next steps.
