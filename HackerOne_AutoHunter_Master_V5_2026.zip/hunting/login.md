# Owned Account Login

Do NOT store passwords, OTPs or session cookies in this repository. Use environment variables or a local credential manager with explicit user permission. Never automate inbox login as a prerequisite to scope verification.
