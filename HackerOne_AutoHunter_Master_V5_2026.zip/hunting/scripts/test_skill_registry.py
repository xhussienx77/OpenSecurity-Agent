import sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import skill_registry as sr
def test_registry_contract():assert not sr.check()
def test_foundations_first():assert sr.resolve('unknown')[:2]==['master-bugbounty-rules','learning-engine-integration']
def test_idor_trigger():assert 'idor-testing' in sr.resolve('object IDOR user ownership')
def test_graphql_trigger():assert 'graphql-testing' in sr.resolve('GraphQL mutation')
def test_unknown_degrades_gracefully():assert 'request-response-analyzer' in sr.resolve('nonspecific')
def test_returned_paths_exist():
 for n in sr.resolve('authorization tenant API'):assert (sr.ROOT/sr.registry()['skills'][n]['path']).exists()
