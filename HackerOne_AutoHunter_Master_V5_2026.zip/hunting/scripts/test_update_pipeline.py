import sys,pathlib,re
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import update_pipeline as u

def test_fetch_offline():assert u.fetch(True)['network_requests']==0
def test_process():assert u.process()['processed']>=5
def test_index():u.process();assert u.index()['indexed']>=5
def test_learn():
 u.process();u.index();result=u.learn()
 assert result['lessons']>=5
 assert 'Knowledge base: '+str(result['lessons']) in (u.ROOT/'agent-briefing.md').read_text()
def test_pipeline_idempotence():
 u.process();u.index();u.learn();before=(u.ROOT/'writeups/index.md').read_text();u.process();u.index();u.learn();assert before==(u.ROOT/'writeups/index.md').read_text()
