"""Offline-first, deterministic write-up learning pipeline. No unverified fetching."""
import argparse, pathlib, hashlib, json, datetime, re, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def raw_items():return sorted(p for p in (ROOT/'writeups/raw').rglob('*.md'))
def fetch(offline=True):
 if not offline:raise ValueError('Online fetching not configured: add reviewed sources and provenance first')
 return {'mode':'offline','raw_count':len(raw_items()),'network_requests':0}
def parse_source(p):
 text=p.read_text();meta={}
 for line in text.splitlines():
  if ':' in line and not line.startswith('#'):
   k,v=line.split(':',1)
   if k.strip().lower() in ('source','date','vulnerability','entry point','precondition','trust boundary','bypass','proof method','fp trap','chain opportunity','tags','target'):
    meta[k.strip().lower()]=v.strip()
 return {'title':next((x.removeprefix('# ').strip() for x in text.splitlines() if x.startswith('# ')),p.stem), 'source':meta.get('source','local_sample'),'date':meta.get('date','undated'),'vulnerability':meta.get('vulnerability','unspecified'),'entry_point':meta.get('entry point','unspecified'),'precondition':meta.get('precondition','unspecified'),'trust_boundary':meta.get('trust boundary','unspecified'),'bypass':meta.get('bypass','unspecified'),'proof_method':meta.get('proof method','unspecified'),'fp_trap':meta.get('fp trap','unspecified'),'chain_opportunity':meta.get('chain opportunity','unspecified'),'tags':meta.get('tags',''),'target':meta.get('target','unspecified'),'fingerprint':hashlib.sha256(text[:300].strip().lower().encode()).hexdigest()}
def process():
 out=ROOT/'writeups/processed';out.mkdir(parents=True,exist_ok=True);seen=set();count=0
 for p in raw_items():
  obj=parse_source(p);key=(obj['source'],obj['title'].lower(),obj['fingerprint'])
  if key in seen:continue
  seen.add(key);dest=out/(p.stem+'.json');dest.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');count+=1
 return {'processed':count}
def entries():
 return [json.loads(p.read_text()) for p in sorted((ROOT/'writeups/processed').glob('*.json'))]
def index():
 lines=['# Public Write-up Index','','| Title | Vuln Type | Target | Source |','|---|---|---|---|']
 for x in entries():lines.append('| '+' | '.join(str(x[k]).replace('|','/') for k in ('title','vulnerability','target','source'))+' |')
 (ROOT/'writeups/index.md').write_text('\n'.join(lines)+'\n');return {'indexed':len(entries())}
def learn():
 items=entries()
 lesson=['# Report Lessons','','Distilled from the local, provenance-tagged public study corpus. Not tested findings.','']
 patterns=['# Learned Patterns','','| Vulnerability | Trust boundary | FP trap | Source |','|---|---|---|---|']
 for x in items:
  lesson.extend([f"## {x['title']}",f"- Entry point: {x['entry_point']}",f"- Boundary: {x['trust_boundary']}",f"- Proof: {x['proof_method']}",f"- FP trap: {x['fp_trap']}",f"- Source: {x['source']}",''])
  patterns.append(f"| {x['vulnerability']} | {x['trust_boundary']} | {x['fp_trap']} | {x['source']} |")
 (ROOT/'memory/report-lessons.md').write_text('\n'.join(lesson)+'\n')
 (ROOT/'memory/patterns.md').write_text('\n'.join(patterns)+'\n')
 method=ROOT/'memory/methodology.md'
 if not method.exists():method.write_text('# Methodology\n\nReview scope, controlled baselines, impact and false positives.\n')
 brief=ROOT/'agent-briefing.md';body=brief.read_text();date=datetime.date.today().isoformat()
 body=re.sub(r'(?m)^Last updated:.*$',f'Last updated: {date}',body)
 body=re.sub(r'(?m)^Knowledge base:.*$',f'Knowledge base: {len(items)} processed write-ups (updated by offline pipeline)',body)
 # Only update header metadata; never destroy the manually authored briefing sections.
 brief.write_text(body)
 return {'lessons':len(items),'briefing_date':date}
def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument('--offline',action='store_true');p.add_argument('--step',choices=['fetch','process','index','learn','all'],default='all');a=p.parse_args(argv)
 if not a.offline:print('BLOCKED: only reviewed offline sample sources are configured',file=sys.stderr);return 2
 tasks={'fetch':lambda:fetch(True),'process':process,'index':index,'learn':learn}
 for step,fn in tasks.items():
  if a.step in ('all',step):print(step,fn())
 return 0
if __name__=='__main__':sys.exit(main())
