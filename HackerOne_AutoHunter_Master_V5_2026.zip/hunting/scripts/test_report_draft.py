import sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import report_draft

def test_no_unverified_report():
 assert report_draft.draft({'state':'OBSERVATION'}).startswith('# Not ready')
def test_redacted_evidence():
 f={'title':'Controlled authorization mismatch','asset':'example.test','state':'REPORTABLE','impact':'Own test account could view controlled resource belonging to a second owned tester account','reproduction':['Send request with Authorization: Bearer SOMETOKEN'],'evidence':'request Cookie: session=secret','scope_verified':True,'two_replays':True,'controls_verified':True,'human_approved_draft':True}
 result=report_draft.draft(f)
 assert 'SOMETOKEN' not in result and 'session=secret' not in result and 'Steps to reproduce' in result
