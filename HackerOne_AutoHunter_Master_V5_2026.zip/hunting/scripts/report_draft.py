"""Generate human-readable reports from redacted, verified evidence records only.
Does not send traffic or submit reports.
"""
import argparse, json, pathlib, re, sys
VALID={'REPORTABLE'}
def clean(text):
 text=str(text)
 text=re.sub(r'(?i)(authorization\s*:\s*(?:bearer|basic)\s+)\S+',r'\1[REDACTED]',text)
 text=re.sub(r'(?i)((?:cookie|set-cookie|x-api-key)\s*:\s*)[^\r\n]+',r'\1[REDACTED]',text)
 text=re.sub(r'(?i)([?&](?:token|api_key|session|password)=)[^&\s]+',r'\1[REDACTED]',text)
 return text
def draft(f):
 errors=[]
 for k in ('title','asset','state','impact','reproduction','evidence','scope_verified','two_replays','controls_verified','human_approved_draft'):
  if k not in f or f[k] in ('',None,False,[]):errors.append(k)
 if f.get('state') not in VALID:errors.append('state must be REPORTABLE')
 if errors:return '# Not ready to report\n\nMissing or invalid: '+', '.join(sorted(set(errors)))+'\n'
 steps=f['reproduction'] if isinstance(f['reproduction'],list) else [f['reproduction']]
 lines=['# '+clean(f['title']),'','## Asset',clean(f['asset']),'','## Severity','Suggested: '+clean(f.get('severity','Unrated; triager decides')),'','## Summary',clean(f.get('summary','The controlled test produced the following verified security impact.')),'','## Demonstrated impact',clean(f['impact']),'','## Steps to reproduce']
 lines.extend(f'{i}. {clean(step)}' for i,step in enumerate(steps,1))
 lines.extend(['','## Evidence',clean(f['evidence']),'','## Expected behavior',clean(f.get('expected','Server enforces the expected access control or state invariant.')),'','## Actual behavior',clean(f.get('actual','Refer to saved controlled request and response evidence.')),'','## Limitations',clean(f.get('limitations','Only the documented owned-account test contexts were evaluated.')),'','## Suggested remediation',clean(f.get('remediation','Verify authorization at the server-side trust boundary.')),'','## Triager notes','This draft was generated from recorded evidence and must be reviewed before submission.'])
 return '\n'.join(lines)+'\n'
def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);a=p.parse_args(argv)
 try:
  f=json.loads(pathlib.Path(a.input).read_text());out=pathlib.Path(a.output).resolve();
  if not out.name.endswith('.md'):raise ValueError('output must be markdown')
  if 'reports' not in out.parts:raise ValueError('output must reside in a reports folder')
  out.parent.mkdir(parents=True,exist_ok=True);text=draft(f);out.write_text(text);print(('DRAFT' if not text.startswith('# Not ready') else 'NOT READY'),out);return 0
 except (OSError,ValueError,TypeError) as e:print('BLOCKED:',e,file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
