import argparse,json,pathlib,sys,urllib.parse,re,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
FOLDERS='notes requests responses screenshots scripts scans wordlists urls subdomains evidence reports'.split()
def host_for(x):
 u=urllib.parse.urlsplit(x if '://' in x else 'https://'+x)
 if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:raise ValueError('invalid URL')
 h=u.hostname.lower().rstrip('.')
 if not re.fullmatch(r'[a-z0-9][a-z0-9.-]{0,251}[a-z0-9]|localhost',h):raise ValueError('invalid hostname')
 return h
def matches(h,p):
 p=p.lower().rstrip('.')
 return (h.endswith(p[1:]) and h!=p[2:]) if p.startswith('*.') else h==p
def allowed(target,policy):
 h=host_for(target);u=urllib.parse.urlsplit(target if '://' in target else 'https://'+target);path=u.path or '/'
 return bool(any(matches(h,p) for p in policy.get('allowed_hosts',[])) and not any(matches(h,p) for p in policy.get('excluded_hosts',[])) and any(path.startswith(p) for p in policy.get('allowed_paths',['/'])) and not any(path.startswith(p) for p in policy.get('excluded_paths',[])))
def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument('--target',required=True);p.add_argument('--scenario',required=True);p.add_argument('--mode',required=True,choices=['hunt','test','scan','recon','report','update']);p.add_argument('--workspace',required=True);p.add_argument('--scope-file',default='config/scope.example.json');p.add_argument('--ensure-session',action='store_true');a=p.parse_args(argv)
 try:
  polfile=(ROOT/a.scope_file).resolve()
  if not polfile.is_relative_to(ROOT):raise ValueError('policy outside project')
  policy=json.loads(polfile.read_text());h=host_for(a.target)
  if not policy.get('authorized'):raise ValueError('authorization not confirmed')
  if not allowed(a.target,policy):raise ValueError('out of scope')
  ws=pathlib.Path(a.workspace)
  if ws.is_absolute() or '..' in ws.parts or h not in ws.parts or ws.parts[0]!='testing' or not (ROOT/ws).resolve().is_relative_to((ROOT/'testing').resolve()):raise ValueError('workspace outside target')
  if a.mode in ('hunt','test','scan') and not policy.get('active_testing_allowed'):raise ValueError('active testing not allowed')
  if float(policy.get('rate_limit_rps',0))<=0:raise ValueError('missing positive rate limit')
  if a.ensure_session:
   for f in FOLDERS:(ROOT/ws/f).mkdir(parents=True,exist_ok=True)
   n=ROOT/ws/'notes/session-bootstrap.md'
   if not n.exists():n.write_text(f'# Session\nTarget: {h}\nScenario: {a.scenario}\nMode: {a.mode}\nCreated: {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n')
   mind=ROOT/ws/'MINDMAP.md'
   if not mind.exists():mind.write_text('# Surface mindmap\n\n## Routes\n## Roles\n## Hypotheses\n')
  print('ALLOWED:',h,a.mode);return 0
 except (ValueError,KeyError,TypeError,OSError,json.JSONDecodeError) as e:
  print('BLOCKED:',str(e),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
