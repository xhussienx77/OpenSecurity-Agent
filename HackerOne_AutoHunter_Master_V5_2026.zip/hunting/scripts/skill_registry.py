import argparse,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def registry():return json.loads((ROOT/'runtime/registry.json').read_text())
def check():
 r=registry();return [d[k] for d in r['skills'].values() for k in ('path','mirror') if not (ROOT/d[k]).is_file()]+[a for a in r['agents'] if not (ROOT/f'runtime/opencode/agents/{a}.md').is_file()]
def resolve(scenario,mode='test'):
 r=registry();chosen=list(r['foundation']);s=scenario.lower()
 for n,d in r['skills'].items():
  if n not in chosen and any(word in s for word in d['triggers']):chosen.append(n)
 if len(chosen)==2 and mode!='update':chosen.append('request-response-analyzer')
 if mode=='report':
  for name in ('false-positive-filter','evidence-hygiene','evidence-validation-and-severity-calibration','report-writer'):
   if name not in chosen:chosen.append(name)
 return chosen
def main():
 p=argparse.ArgumentParser();q=p.add_subparsers(dest='command',required=True);q.add_parser('check');r=q.add_parser('resolve');r.add_argument('--scenario',required=True);r.add_argument('--mode',default='test');r.add_argument('--paths-only',action='store_true');g=q.add_parser('generate');g.add_argument('--output',default='runtime/registry-generated-summary.md');a=p.parse_args()
 if a.command=='check':
  missing=check();print('REGISTRY OK' if not missing else 'MISSING: '+repr(missing));return bool(missing)
 if a.command=='resolve':
  reg=registry()
  for n in resolve(a.scenario,a.mode):print(reg['skills'][n]['path'] if a.paths_only else n)
 if a.command=='generate':
  out=(ROOT/a.output).resolve()
  if not out.is_relative_to(ROOT):print('BLOCKED: output outside project');return 2
  out.parent.mkdir(parents=True,exist_ok=True);out.write_text('# Registry summary\n'+'\n'.join('- '+x for x in registry()['skills']));print(out)
 return 0
if __name__=='__main__':sys.exit(main())
