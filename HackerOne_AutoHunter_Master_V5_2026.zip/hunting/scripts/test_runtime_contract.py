import sys,pathlib,json,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import runtime_preflight as r
from skill_registry import ROOT,registry

def test_policy_defaults_to_block():
 assert r.main(['--target','test.example.com','--scenario','login','--mode','hunt','--workspace','testing/example.com/test.example.com'])==2

def test_out_of_scope_blocks(tmp_path):
 p=ROOT/'config/_test_scope.json';p.write_text(json.dumps({'authorized':True,'allowed_hosts':['test.example.com'],'active_testing_allowed':True,'rate_limit_rps':1}))
 try:assert r.main(['--target','not-example.com','--scenario','x','--mode','hunt','--workspace','testing/example.com/not-example.com','--scope-file','config/_test_scope.json'])==2
 finally:p.unlink()

def test_bootstrap(tmp_path):
 p=ROOT/'config/_test_scope.json';p.write_text(json.dumps({'authorized':True,'allowed_hosts':['test.example.com'],'active_testing_allowed':True,'rate_limit_rps':1}))
 ws=ROOT/'testing/example.com/test.example.com'
 try:
  assert r.main(['--target','test.example.com','--scenario','login form','--mode','hunt','--workspace','testing/example.com/test.example.com','--scope-file','config/_test_scope.json','--ensure-session'])==0
  assert (ws/'notes/session-bootstrap.md').exists()
 finally:
  p.unlink()
  import shutil;shutil.rmtree(ROOT/'testing/example.com',ignore_errors=True)

def test_no_path_traversal():assert not r.allowed('evil.example.com',{'allowed_hosts':['test.example.com']})
def test_manifest_and_loader_present():
 for name in ('runtime/opencode/loader.md','runtime/opencode/manifest.md','runtime/opencode/ORCHESTRATION.md'):assert (ROOT/name).is_file()
 for name in registry()['agents']:assert (ROOT/f'runtime/opencode/agents/{name}.md').exists()
