# Five-hook contract

`before_recon(target, technologies)` → plan; `during_testing(signals)` → bounded scoring; `after_finding(...)` → persistent pending observation; `before_summary(findings)` → ranked findings; `after_triage(id, feedback, notes, provenance)` → verified result in SQLite. Historical accepted outcomes are kept distinct from unconfirmed leads. `memory/learning.db` is created locally on first run and excluded from version control.
