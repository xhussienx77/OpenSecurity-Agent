import argparse, pathlib, sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[2]))
from learning_engine import LearningEngine
p=argparse.ArgumentParser();p.add_argument('--report-only',action='store_true');a=p.parse_args()
e=LearningEngine();print('Learning engine audit:',e.get_statistics(),'signal weights:',len(e.weights),'hooks:5')
