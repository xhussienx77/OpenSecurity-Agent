"""Minimal SQLite backed signal memory; unreviewed results never train priors."""
import json, sqlite3, pathlib, uuid, datetime
DEFAULT_DB=pathlib.Path(__file__).resolve().parents[1]/'memory'/'learning.db'
WEIGHTS=pathlib.Path(__file__).resolve().parent/'scoring'/'signals.json'
class LearningEngine:
 def __init__(self,db_path=None):
  self.path=str(db_path or DEFAULT_DB)
  pathlib.Path(self.path).parent.mkdir(parents=True,exist_ok=True)
  self.db=sqlite3.connect(self.path)
  self.db.execute('CREATE TABLE IF NOT EXISTS findings (id TEXT PRIMARY KEY,target TEXT,endpoint TEXT,class TEXT,signals TEXT,state TEXT,provenance TEXT,created TEXT)')
  self.db.execute('CREATE TABLE IF NOT EXISTS triage (finding_id TEXT,feedback TEXT,notes TEXT,provenance TEXT,created TEXT)')
  self.db.commit();self.weights=json.loads(WEIGHTS.read_text())
 def before_recon(self,target,technologies=None):
  matches=self.db.execute('SELECT class,COUNT(*) FROM findings WHERE target=? GROUP BY class',(target,)).fetchall()
  return {'target':target,'technologies':technologies or [],'prior_classes':dict(matches),'recommended':'review known authorization boundaries and existing evidence'}
 def during_testing(self,signals):
  if isinstance(signals,str):signals=[signals]
  if isinstance(signals,dict):signals=list(signals.keys())
  vals=[min(1,max(0,float(self.weights.get(x,2))/10)) for x in signals]
  return {'signals':signals,'score':round(max(vals,default=0.1),3),'classification':'hypothesis_only'}
 def after_finding(self,target,endpoint='',vulnerability_class='',signals=None,validation_state='OBSERVATION',source_provenance=None,subdomain=None):
  fid=uuid.uuid4().hex
  self.db.execute('INSERT INTO findings VALUES (?,?,?,?,?,?,?,?)',(fid,target,endpoint,vulnerability_class,json.dumps(signals or []),validation_state,json.dumps(source_provenance or {}),datetime.datetime.now(datetime.timezone.utc).isoformat()))
  self.db.commit();return {'id':fid,'target':target,'state':validation_state}
 def after_triage(self,finding_id,feedback_type,notes='',provenance=None):
  if feedback_type not in ('accepted','duplicate','informative','false_positive'):raise ValueError('invalid triage')
  if not self.db.execute('SELECT 1 FROM findings WHERE id=?',(finding_id,)).fetchone():raise ValueError('unknown finding')
  self.db.execute('INSERT INTO triage VALUES (?,?,?,?,?)',(finding_id,feedback_type,notes,json.dumps(provenance or {}),datetime.datetime.now(datetime.timezone.utc).isoformat()))
  self.db.commit();return {'finding_id':finding_id,'feedback':feedback_type}
 def before_summary(self,findings):
  return sorted(findings,key=lambda f:(f.get('validation_state') in ('CONFIRMED','REPORTABLE'),f.get('evidence_quality',0)),reverse=True)
 def get_statistics(self):
  return {'findings':self.db.execute('SELECT COUNT(*) FROM findings').fetchone()[0],'triage':self.db.execute('SELECT COUNT(*) FROM triage').fetchone()[0]}
 def get_tuning(self):return {'weights':self.weights,'policy':'only validated program triage tunes priors'}
 def get_heatmap(self):return dict(self.db.execute('SELECT class,COUNT(*) FROM findings GROUP BY class').fetchall())
 def get_chains(self):return []
 def rebuild_graph(self):return {'nodes':0,'edges':0,'status':'not implemented'}
 def search(self,term):return self.db.execute('SELECT id,target,endpoint,class FROM findings WHERE class LIKE ? LIMIT 20',('%'+term+'%',)).fetchall()
