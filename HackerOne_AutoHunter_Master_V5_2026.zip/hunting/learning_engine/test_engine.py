import pathlib,sys,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from learning_engine import LearningEngine

def test_five_hooks(tmp_path):
 e=LearningEngine(tmp_path/'unit.db')
 assert e.before_recon('example.com',[])['target']=='example.com'
 assert 0<=e.during_testing(['idor_parameter'])['score']<=1
 f=e.after_finding('example.com',endpoint='/api/me',vulnerability_class='idor',signals=['idor_parameter'])
 assert f['id'] and e.get_statistics()['findings']==1
 assert e.after_triage(f['id'],'accepted','test',{'source':'program_triage'})['feedback']=='accepted'
 assert e.get_statistics()['triage']==1
 assert e.before_summary([{'validation_state':'OBSERVATION'},{'validation_state':'REPORTABLE'}])[0]['validation_state']=='REPORTABLE'
 assert e.search('idor')

def test_invalid_triage_rejected(tmp_path):
 e=LearningEngine(tmp_path/'unit.db')
 import pytest
 with pytest.raises(ValueError):e.after_triage('unknown','accepted')
