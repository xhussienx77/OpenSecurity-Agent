---
name: race-condition-testing
description: Authorized security review guidance for race condition testing.
---
# Race Condition Testing

## When to activate
Load for: race, one-time. Run registry resolution before using this skill.

## Testing method
1. Confirm host and exact path within the allowed program scope and technique permissions.
2. Review Burp history and existing evidence. Identify the authority boundary, expected legitimate result and least-invasive comparison.
3. Compare baseline and controlled requests using test accounts and resources the tester owns. Never access unrelated user data or disrupt service.
4. Avoid active testing if program rules prohibit this class. Record a hypothesis and the missing authorization instead.
5. Save the request/response difference with timestamp, roles, controlled object IDs and a marker; redact session secrets from reports.
6. Distinguish unexpected application behavior from proof of unauthorized impact. Require reproducibility and a meaningful control sample.
7. Return observation, proof quality, false-positive alternatives, missing evidence and safe next action. Do not auto-submit.

## Evidence gates
Scope + policy confirmed; control matched; reproducible; impact proved; no out-of-scope dependency; triager-ready description.
