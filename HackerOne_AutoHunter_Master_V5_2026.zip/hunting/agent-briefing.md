# Agent Briefing - Bug Bounty Session Start
Last updated: 2026-11-07
Knowledge base: 5 processed write-ups (updated by offline pipeline)
Role: authorized, evidence-driven security research orchestrator.

## Mandatory boot
1. Read `AGENTS.md`, `prioritization.md` and `memory/CONTEXT_LEDGER.md`.
2. Load `skills/master-bugbounty-rules.md` and `skills/learning-engine-integration.md`.
3. Read `runtime/opencode/loader.md`, `runtime/opencode/manifest.md`, `runtime/opencode/ORCHESTRATION.md`.
4. Verify the user-supplied exact scope and the PROGRAM authorization policy before sending network traffic.
5. Run `python scripts/skill_registry.py check`, then `python scripts/runtime_preflight.py --target test.example.com --scenario 'login form' --mode hunt --workspace testing/example.com/test.example.com --ensure-session --scope-file config/scope.example.json` using an appropriate, explicitly authorized real target instead of the example.
6. Run scenario resolver BEFORE each technique; load only relevant skills.
7. Inspect prior testing notes and the Burp history analysis before additional discovery.
8. Run only non-disruptive, rate-limited tests allowed by the program; no automatic publishing.

## Evidence & triage
Keep request/response baselines (redacted for exports), account ownership comparisons, reproducibility notes, an impact proof and an FP analysis. Distinguish OBSERVATION, LEAD, CONFIRMED and REPORTABLE. Human approval is required to submit a report.

## Knowledge and runtime
`runtime/registry.json` is canonical. `learning_engine/` provides five hooks. `writeups/index.md` is retrieval only; read `memory/report-lessons.md` for distilled lessons. The testing tree is `testing/<root-domain>/<subdomain>/` with the standard folders. Five specialist collectors are optional runtime tasks, capped at three concurrently; the orchestrator alone handles controlled validation.

## Main project source
The full user's requirements, including original task ordering, are preserved without omission in `spec/ORIGINAL_USER_SPEC.md`. For implementation coverage and gaps see `spec/IMPLEMENTATION_MATRIX.md`.
