# Logs

Store only redacted operational logs, not live credentials or session cookies.
