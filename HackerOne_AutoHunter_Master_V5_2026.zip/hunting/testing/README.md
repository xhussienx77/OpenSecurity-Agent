# Testing workspace

A new workspace is created by `scripts/runtime_preflight.py` after explicit authorization. Original HTTP bodies are sensitive; restrict local filesystem permissions and export redacted evidence only.
