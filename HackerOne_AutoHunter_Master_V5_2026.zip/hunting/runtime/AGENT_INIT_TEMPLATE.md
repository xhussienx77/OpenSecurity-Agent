# Session Init Template

Target: [EXPLICIT SCOPE]
Policy: [PERMISSIONS]
Owned accounts: [NON-SECRET LABELS]
Rate cap: [REQUESTS PER SECOND]
Live Burp bridge: [OPTIONAL]
