# Skill Activation

Resolve on every surface using `python scripts/skill_registry.py resolve --scenario "..." --mode test --paths-only` then load each returned skill.
