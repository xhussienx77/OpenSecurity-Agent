# OpenCode Boot Loader

1. Read `agent-briefing.md`; follow it with `AGENTS.md` and `prioritization.md`.
2. Load `runtime/opencode/manifest.md` and `runtime/opencode/ORCHESTRATION.md`.
3. Read the mandatory foundations `skills/master-bugbounty-rules.md` and `skills/learning-engine-integration.md`.
4. Confirm explicit exact targets, exclusions, testing permission and permitted techniques in scope JSON.
5. Run `python scripts/skill_registry.py check`; run preflight in the mode matching the command.
6. Discover and load relevant skills through the resolver; never bulk-load all skills during boot.
7. Reuse notes, preserve original request data locally, redact reporting output.
8. Only invoke available tools; never assume browser or Burp connectivity. Five collectors are runtime roles, NOT automatically spawned by the Markdown file itself.
