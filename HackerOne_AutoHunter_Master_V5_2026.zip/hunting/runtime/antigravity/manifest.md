# Antigravity Manifest

Canonical registry: `runtime/registry.json`; no implicit browser or multi-agent access.
