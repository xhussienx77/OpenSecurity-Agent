# Antigravity Loader

Read briefing and constitution. Execute the scope preflight and skill resolver. Use platform-specific adapters only when actually installed.
