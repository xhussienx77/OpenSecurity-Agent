#!/usr/bin/env python3
"""HackerOne-oriented bounded HTTP security checks for programs permitting automation.

Only scopes explicitly entered by the researcher are used. No remote API is
queried for authorization, no redirects are followed, and no secrets are stored.
Requires Python 3.10+; Python standard library only.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

VERSION = "2.0.0"
MAX_BODY = 16384
USER_AGENT = "H1ScopeHunter/2.0 (authorized-research; low-rate)"
LAB_HOSTS = {"localhost", "127.0.0.1", "::1"}
ROOT = Path(__file__).resolve().parents[1]


class GuardError(ValueError):
    """A scope, consent or input boundary was not satisfied."""


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


OPENER = build_opener(NoRedirect)


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def normalized_origin(raw):
    u = urlsplit(raw.strip())
    try:
        host, port = u.hostname, u.port
    except ValueError as exc:
        raise GuardError("Bad target port") from exc
    if u.scheme not in ("http", "https") or not host or u.username or u.password:
        raise GuardError("Expected one http(s) origin without URL credentials")
    if u.path not in ("", "/") or u.query or u.fragment:
        raise GuardError("Supply only the origin; checks supply their own paths")
    host = host.lower().rstrip(".")
    if u.scheme == "http" and host not in LAB_HOSTS:
        raise GuardError("External targets must use HTTPS")
    if host not in LAB_HOSTS and port not in (None, 443):
        raise GuardError("Non-standard external ports require a separate tool and explicit port scope")
    if u.scheme == "https" and port == 443:
        port = None
    netloc = f"[{host}]" if ":" in host else host
    if port is not None:
        netloc += f":{port}"
    return urlunsplit((u.scheme, netloc, "", "", ""))


def host_matches(host, entry):
    """Exact or explicit wildcard subdomain match; *.x does NOT include x."""
    if not isinstance(entry, str):
        return False
    value = entry.lower().strip().rstrip(".")
    if value.startswith("*."):
        suffix = value[2:]
        return bool(suffix and host.endswith("." + suffix) and host != suffix)
    return host == value


def valid_path(path):
    if not isinstance(path, str) or not path.startswith("/") or path.startswith("//") or "\\" in path:
        return False
    parsed = urlsplit(path)
    if parsed.scheme or parsed.netloc or parsed.fragment:
        return False
    decoded = unquote(parsed.path)
    return not any(chunk in (".", "..") for chunk in decoded.split("/"))


def path_excluded(path, excluded):
    p = urlsplit(path).path
    for prefix in excluded:
        if not valid_path(prefix):
            raise GuardError("Bad excluded path in program policy config")
        prefix = prefix.rstrip("/") or "/"
        if prefix == "/" or p == prefix or p.startswith(prefix + "/"):
            return True
    return False


def gate(config, target, path="/", active=False, kind="scan"):
    if not config.get("policy_reviewed") or not config.get("authorization_confirmed"):
        raise GuardError("Review the HackerOne program rules and set both policy_reviewed and authorization_confirmed=true")
    if not config.get("policy_url") or not config.get("program_handle"):
        raise GuardError("program_handle and policy_url are required")
    origin = normalized_origin(target)
    host = urlsplit(origin).hostname
    inc = config.get("in_scope_hosts", [])
    exc = config.get("out_of_scope_hosts", [])
    if not isinstance(inc, list) or not inc:
        raise GuardError("in_scope_hosts is empty; cannot infer scope")
    if any(host_matches(host, x) for x in exc):
        raise GuardError("Target is explicitly out of scope")
    if not any(host_matches(host, x) for x in inc):
        raise GuardError("Target host is not on the explicit allowlist")
    if not valid_path(path) or path_excluded(path, config.get("out_of_scope_paths", [])):
        raise GuardError("Path invalid or explicitly excluded by program rules")
    if active and not config.get("automation_allowed"):
        raise GuardError("Program must explicitly allow the requested automated tests; automation_allowed=false")
    if kind == "authz" and not config.get("authz_testing_allowed"):
        raise GuardError("Program must allow controlled authorization checks; authz_testing_allowed=false")
    rate = config.get("max_requests_per_second", 1)
    if not isinstance(rate, (float, int)) or isinstance(rate, bool) or not 0 < rate <= 2:
        raise GuardError("Set a conservative program-approved max_requests_per_second in (0, 2]")
    return origin


def request(url, headers=None):
    req_headers = {"User-Agent": USER_AGENT, "Accept": "text/plain,application/json,text/html,*/*;q=0.1",
                   "Accept-Encoding": "identity", **(headers or {})}
    req = Request(url, headers=req_headers, method="GET")
    try:
        resp = OPENER.open(req, timeout=8)
    except HTTPError as exc:
        resp = exc
    except (URLError, TimeoutError, OSError) as exc:
        # No exception repr to avoid accidentally persisting request header values.
        return {"error": type(exc).__name__}
    with resp:
        payload = resp.read(MAX_BODY + 1)
        if len(payload) > MAX_BODY:
            payload = payload[:MAX_BODY]
            truncated = True
        else:
            truncated = False
        return {"status": resp.status, "body": payload,
                "headers": {k.lower(): v for k, v in resp.headers.items()},
                "truncated": truncated}


class RateLimiter:
    def __init__(self, max_rps):
        self.interval = 1 / max_rps
        self.last = None

    def tick(self):
        if self.last is not None:
            elapsed = time.monotonic() - self.last
            if elapsed < self.interval:
                time.sleep(self.interval - elapsed)
        self.last = time.monotonic()


def finding(title, category, severity, confidence, path, evidence, next_step):
    return {"title": title, "category": category, "severity_estimate": severity,
            "confidence": confidence, "path": path, "evidence_redacted": evidence,
            "state": "candidate_needs_manual_validation", "next_step": next_step}


def scans(config, origin):
    lim = RateLimiter(config["max_requests_per_second"])
    findings, probes, notes = [], [], []
    stopped = False

    def probe(path, headers=None):
        nonlocal stopped
        if stopped:
            probes.append({"path": path, "skipped": "scan stopped on rate-limiting or server error"})
            return {}
        try:
            gate(config, origin, path, active=True)
        except GuardError:
            probes.append({"path": path, "skipped": "path excluded by policy"})
            return {}
        lim.tick()
        r = request(origin + path, headers=headers)
        probes.append({"path": path, "status": r.get("status"), "error": r.get("error"),
                       "truncated": r.get("truncated", False)})
        if r.get("status") in (429, 500, 502, 503, 504):
            notes.append(f"Stopped on HTTP {r['status']} at an in-scope path; no further requests sent")
            stopped = True
        return r

    base = probe("/")
    if "error" in base or not base:
        notes.append("Root could not be checked; verify access and path exclusions")
    missing = probe("/__h1_absent_" + secrets.token_hex(10))
    def genuine_page(r):
        return (r.get("status") == 200 and not r.get("truncated") and
                (missing.get("status") != 200 or r.get("body") != missing.get("body")))

    r = probe("/.git/HEAD")
    if genuine_page(r) and re.fullmatch(rb"\s*ref:\s*refs/(heads|tags)/[\w./-]+\s*", r.get("body", b"")):
        findings.append(finding("Git metadata exposed", "information-disclosure", "high", "strong-marker", "/.git/HEAD",
                                "HTTP 200; refs/heads or refs/tags format verified. Content discarded.",
                                "Verify policy eligibility and whether repository objects are exposed; do not download them."))
    r = probe("/.env")
    labels = set(re.findall(rb"(?m)^(APP_KEY|DB_HOST|DB_PASSWORD|DB_USERNAME|SECRET_KEY|AWS_ACCESS_KEY_ID|MAIL_PASSWORD|REDIS_PASSWORD)\s*=", r.get("body", b"")))
    if genuine_page(r) and len(labels) >= 2:
        findings.append(finding("Possible exposed .env configuration", "information-disclosure", "high", "strong-marker", "/.env",
                                f"HTTP 200; {len(labels)} known configuration keys found. Values discarded.",
                                "Do not retrieve or reuse credentials; report minimal evidence after eligibility review."))
    r = probe("/phpinfo.php")
    blob = r.get("body", b"").lower()
    if genuine_page(r) and b"phpinfo()" in blob and re.search(rb"php version\s*\d", blob):
        findings.append(finding("Public phpinfo diagnostics", "information-disclosure", "medium", "strong-marker", "/phpinfo.php",
                                "HTTP 200; phpinfo diagnostics identified; full response withheld.",
                                "Assess whether diagnostic exposure is excluded by the program rules."))
    r = probe("/server-status?auto")
    blob = r.get("body", b"")
    if genuine_page(r) and (b"Apache Server Status for" in blob or (b"ServerVersion:" in blob and b"Total Accesses:" in blob)):
        findings.append(finding("Public Apache server-status", "information-disclosure", "medium", "strong-marker", "/server-status?auto",
                                "HTTP 200; Apache server-status markers found. Response withheld.",
                                "Check program reporting policy and whether status contains sensitive operational data."))
    r = probe("/", {"Origin": "https://h1-scope-test.invalid"})
    cors = r.get("headers", {})
    if (cors.get("access-control-allow-origin") == "https://h1-scope-test.invalid" and
            cors.get("access-control-allow-credentials", "").lower() == "true"):
        findings.append(finding("Possible credentialed CORS origin reflection", "cors", "medium", "weak-signal", "/",
                                "Synthetic Origin reflected with Access-Control-Allow-Credentials: true, without authentication.",
                                "A CORS bug requires proof that sensitive authenticated responses are exposed to an untrusted origin."))
    return findings, probes, notes


def authz_case(config, origin, case):
    if case.get("method", "GET").upper() != "GET":
        raise GuardError("Only GET requests allowed for owned-account differential checks")
    path = case.get("path", "")
    if not valid_path(path) or urlsplit(path).query:
        raise GuardError("Owned-account case requires a plain path without query, fragment or traversal")
    gate(config, origin, path, active=True, kind="authz")
    marker = case.get("synthetic_private_marker")
    owner = case.get("owner")
    if owner not in ("A", "B") or not isinstance(marker, str) or not re.fullmatch(r"H1_TEST_[A-Za-z0-9_-]{6,112}", marker):
        raise GuardError("case requires owner A/B and a harmless synthetic_private_marker starting H1_TEST_ (no secrets)")
    if not case.get("researcher_owns_both_accounts_and_resource"):
        raise GuardError("Set researcher_owns_both_accounts_and_resource=true after confirming")
    method = case.get("auth_method", "bearer")
    if method not in ("bearer", "cookie"):
        raise GuardError("auth_method must be bearer or cookie")
    token_a, token_b = os.environ.get("H1_TEST_A_TOKEN"), os.environ.get("H1_TEST_B_TOKEN")
    if not token_a or not token_b or token_a == token_b:
        raise GuardError("Set two different researcher-owned H1_TEST_A_TOKEN and H1_TEST_B_TOKEN environment variables")
    if method == "bearer":
        a_headers = {"Authorization": "Bearer " + token_a}
        b_headers = {"Authorization": "Bearer " + token_b}
    else:
        a_headers = {"Cookie": token_a}
        b_headers = {"Cookie": token_b}
    lim = RateLimiter(config["max_requests_per_second"])
    lim.tick()
    first = request(origin + path, a_headers if owner == "A" else b_headers)
    if first.get("status") != 200 or marker.encode() not in first.get("body", b"") or first.get("truncated"):
        return [], [{"path": path, "phase": "owner-baseline", "status": first.get("status"), "error": first.get("error")}], [
            "Owner baseline did not show the synthetic marker in a complete HTTP 200 response; cross-account request was not sent."]
    lim.tick()
    cross = request(origin + path, b_headers if owner == "A" else a_headers)
    hits = cross.get("status") == 200 and marker.encode() in cross.get("body", b"") and not cross.get("truncated")
    probes = [{"path": path, "phase": "owner-baseline", "status": first.get("status")},
              {"path": path, "phase": "cross-account", "status": cross.get("status"), "error": cross.get("error")}]
    if hits:
        return [finding("Cross-account access to researcher-owned private marker", "access-control-idor", "high", "strong-signal", path,
                        "An unauthorized test account received HTTP 200 containing a synthetic private marker created by the researcher. Values and tokens withheld.",
                        "Confirm the resource is intended private, repeat at minimal scope only if needed, check policy exclusions, then prepare report.")], probes, []
    return [], probes, ["No cross-account disclosure of the synthetic owned marker observed in this bounded check."]


def render_report(data):
    s = ["# H1 Scope Hunter — Candidate Findings", "", f"**Program:** {data['program']}",
         f"**Target:** `{data['target']}`", f"**Mode:** {data['mode']}",
         f"**Timestamp (UTC):** {data['timestamp_utc']}", "",
         "> Automated matches are candidates, not guaranteed reportable vulnerabilities or bounties.", ""]
    fs = data.get("findings", [])
    if not fs:
        s += ["No candidate matched the selected checks. This is **not** proof that the target is secure.", ""]
    for idx, f in enumerate(fs, 1):
        s += [f"## {idx}. {f['title']}", "", f"- Severity estimate: **{f['severity_estimate']}**",
              f"- Confidence: **{f['confidence']}**", f"- Location: `{f['path']}`",
              f"- Observation: {f['evidence_redacted']}", f"- Validation needed: {f['next_step']}", ""]
    if data.get("notes"):
        s += ["## Notes", ""] + ["- " + n for n in data["notes"]]
    s += ["", "## Scope and limitations", "",
          "All requests were GET, redirects were not followed, and response bodies, tokens and potential secrets were not stored.",
          "No crawlers, fuzzers, state-changing requests, credential attacks or automatic HackerOne submissions were used.", ""]
    return "\n".join(s)


def create_report(program, target, mode, findings, probes, notes, output):
    folder = Path(output)
    folder.mkdir(parents=True, exist_ok=True)
    data = {"version": VERSION, "program": program, "target": target, "mode": mode,
            "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "findings": findings, "probes": probes, "notes": notes}
    write_json(folder / "report.json", data)
    (folder / "report.md").write_text(render_report(data), encoding="utf-8")
    return folder, data


def import_scopes(source):
    """Offline H1 structured_scope export triage, never automatic authorization."""
    doc = load_json(source)
    out = {"review_required": True, "note": "Never copy these directly into the allowlist without reading program policy and asset instructions.",
           "candidate_hosts": [], "excluded_hosts": [], "unsupported_or_ambiguous": []}
    for row in doc.get("data", []):
        a = row.get("attributes", {})
        kind, ident = str(a.get("asset_type", "")).upper(), str(a.get("asset_identifier", "")).strip()
        host = ""
        if kind == "URL":
            parsed = urlsplit(ident)
            if parsed.scheme == "https" and parsed.hostname and parsed.path in ("", "/") and not parsed.query and not parsed.port:
                host = parsed.hostname.lower()
        elif kind in ("DOMAIN", "WILDCARD"):
            if re.fullmatch(r"(?:\*\.)?[A-Za-z0-9.-]+", ident) and ".." not in ident:
                host = ident.lower()
        if not host:
            out["unsupported_or_ambiguous"].append({"asset_type": kind, "identifier": ident[:120],
                                                    "reason": "Path-scoped URL, IP/network, invalid or unsupported scope: manual handling required"})
            continue
        dest = "candidate_hosts" if a.get("eligible_for_submission") is True else "excluded_hosts"
        out[dest].append({"host": host, "instruction": str(a.get("instruction") or "")[:240],
                          "eligible_for_bounty": a.get("eligible_for_bounty"), "source_id": row.get("id")})
    return out


def draft_finding(report_path, number, output):
    report = load_json(report_path)
    findings = report.get("findings", [])
    if number < 1 or number > len(findings):
        raise GuardError("Finding number does not exist")
    f = findings[number - 1]
    result = f"""# [DRAFT — VERIFY FIRST] {f['title']}

**HackerOne program:** {report['program']}
**Asset:** `{report['target']}{f['path']}`
**Proposed severity (not verified):** {f['severity_estimate']}

## Summary
Observed an automated signal consistent with {f['category']}. Do not submit until manual confirmation of scope, eligibility and impact.

## Preconditions
- In-scope asset and allowed testing method confirmed against the live program policy.
- For authorization issues: two researcher-owned accounts and a private synthetic resource.

## Steps to reproduce
1. [Describe the minimal safe request made with a researcher-owned identity.]
2. [Describe the observed behavior and its expected secure alternative.]
3. [Include sanitized HTTP status/header evidence; never include secrets or third-party data.]

## Evidence collected (sanitized)
{f['evidence_redacted']}

## Security impact
[Only state demonstrated confidentiality/integrity/authorization impact. Do not assume impact from a scanner match.]

## Expected behavior
[What authorization/security control should apply?]

## Remediation suggestion
[Validate access server-side, remove exposed diagnostics/config, or constrain CORS appropriately as applicable.]

## Remaining validation
{f['next_step']}
"""
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(result, encoding="utf-8")


def main(argv=None):
    p = argparse.ArgumentParser(description="HackerOne-focused low-noise bounded bug hunter; authorization required")
    sub = p.add_subparsers(dest="cmd", required=True)
    init = sub.add_parser("init", help="Create review-required engagement config")
    init.add_argument("--output", required=True)
    init.add_argument("--program", default="CHANGE_ME")
    scope = sub.add_parser("scope", help="Check URL against local allowlist without networking")
    scope.add_argument("--config", required=True)
    scope.add_argument("--target", required=True)
    scan = sub.add_parser("scan", help="7 bounded GET checks on one reviewed, authorized origin")
    scan.add_argument("--config", required=True)
    scan.add_argument("--target", required=True)
    scan.add_argument("--output", required=True)
    scan.add_argument("--confirm-authorization", action="store_true")
    authz = sub.add_parser("authz", help="Two-account owned-resource differential GET test")
    authz.add_argument("--config", required=True)
    authz.add_argument("--target", required=True)
    authz.add_argument("--case", required=True)
    authz.add_argument("--output", required=True)
    authz.add_argument("--confirm-two-owned-accounts", action="store_true")
    si = sub.add_parser("import-scopes", help="Triage an exported H1 API structured-scopes JSON offline")
    si.add_argument("--input", required=True)
    si.add_argument("--output", required=True)
    rep = sub.add_parser("draft", help="Draft a report for one candidate (not auto-submitted)")
    rep.add_argument("--report", required=True)
    rep.add_argument("--finding", type=int, required=True)
    rep.add_argument("--output", required=True)
    a = p.parse_args(argv)
    try:
        if a.cmd == "init":
            folder = Path(a.output)
            folder.mkdir(parents=True, exist_ok=True)
            target = folder / "program.json"
            if target.exists():
                raise GuardError("program.json already exists; refusing to overwrite")
            config = load_json(ROOT / "config" / "program.sample.json")
            config["program_handle"] = a.program
            write_json(target, config)
            print(f"Created {target}. Edit policy, explicit asset allowlist and permission flags before scanning.")
        elif a.cmd == "scope":
            cfg = load_json(a.config)
            print("IN SCOPE (LOCAL CONFIG ONLY):", gate(cfg, a.target))
            print("This does not verify the current HackerOne policy; confirm manually.")
        elif a.cmd == "scan":
            if not a.confirm_authorization:
                raise GuardError("Pass --confirm-authorization after checking the current program policy")
            cfg = load_json(a.config)
            origin = gate(cfg, a.target, active=True)
            found, probes, notes = scans(cfg, origin)
            folder, data = create_report(cfg["program_handle"], origin, "bounded-web-scan", found, probes, notes, a.output)
            print(f"{len(found)} candidate(s); {len(probes)} bounded probes; reports: {folder / 'report.md'}")
        elif a.cmd == "authz":
            if not a.confirm_two_owned_accounts:
                raise GuardError("Pass --confirm-two-owned-accounts only when both accounts and resource are yours")
            cfg = load_json(a.config)
            origin = gate(cfg, a.target, active=True, kind="authz")
            found, probes, notes = authz_case(cfg, origin, load_json(a.case))
            folder, data = create_report(cfg["program_handle"], origin, "owned-account-authorization", found, probes, notes, a.output)
            print(f"{len(found)} candidate(s); {len(probes)} requests; reports: {folder / 'report.md'}")
        elif a.cmd == "import-scopes":
            write_json(a.output, import_scopes(a.input))
            print(f"Scope candidates exported to {a.output}; requires manual review; no scanning performed")
        elif a.cmd == "draft":
            draft_finding(a.report, a.finding, a.output)
            print(f"Draft only: {a.output}; verify before submitting to HackerOne")
        return 0
    except (GuardError, FileNotFoundError, KeyError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
