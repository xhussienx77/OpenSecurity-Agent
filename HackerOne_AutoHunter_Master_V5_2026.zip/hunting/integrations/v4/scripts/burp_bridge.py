#!/usr/bin/env python3
"""Burp Suite -> AutoHunter bridge.

Passive-only: XML import and localhost metadata receiver; never sends requests
at a target. Original HTTP bodies/headers/tokens are never persisted or sent
elsewhere. Requires manually reviewed scope configuration from AutoHunter.
Python 3.10+ stdlib.
"""
from __future__ import annotations
import argparse
import base64
from collections import defaultdict
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import sys
import threading
from urllib.parse import parse_qsl, urlsplit, unquote
import xml.etree.ElementTree as ET

import h1_hunter as core

VERSION = '4.0.0'
ROOT = Path(__file__).resolve().parents[1]
MAX_XML = 80 * 1024 * 1024
MAX_HTTP_BYTES = 1_500_000
MAX_LIVE_POST = 12_000
MAX_EVENTS = 100_000
VALID_NAME = re.compile(r'^[a-zA-Z][\w.:-]{0,50}$')
SENSITIVE_NAME = re.compile(r'(?i)(pass|secret|token|cookie|session|key|auth|jwt|bearer|signature|code|otp|credential)')
SENSITIVE_PATH_SEGMENT = re.compile(r'(?i)(?:[a-z0-9_-]{22,}|[a-f0-9]{16,}|\d{4,}|[a-f0-9-]{36})')
SAFE_STATIC = set('api v1 v2 v3 v4 v5 graphql rpc users user accounts account members member org organizations tenants tenant roles permissions billing invoice invoices admin webhook webhooks keys key orders order payments payment exports export files file documents document projects project teams team profile profiles settings login logout auth session sessions register signup search reports report download upload verify reset password cart checkout info dashboard public private me myself current .git head .env phpinfo.php server-status health status config system logs log js css assets test feature features form forms notifications notification messages message activity comments comment preferences preference addresses address audit audit-log tokens token access control management invitations invite recovery verification password-reset data metadata oauth openid connect callback refresh product products collections collection items item'.split())
API_HINTS = ('api', 'graphql', 'rpc', 'users', 'accounts', 'members', 'org', 'tenant', 'roles', 'permissions', 'billing', 'invoice', 'admin', 'webhook', 'keys', 'orders', 'payments', 'exports', 'files')
AUTHZ_HINTS = ('user','account','member','org','tenant','role','permission','invoice','order','file','document','project','team','admin','billing')
KNOWN_FLAGS = {'git_exposure','env_exposure','phpinfo','apache_status','stack_trace',
               'cors_credential_origin_reflection','cors_wildcard','cache_public_authenticated','cookie_missing_httponly',
               'cookie_missing_secure','missing_hsts','json_contains_sensitive_key'}
METHODS = {'GET','POST','PUT','PATCH','DELETE','OPTIONS','HEAD','TRACE','CONNECT'}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def read_scope(path):
    config = core.load_json(path)
    if not isinstance(config, dict):
        raise core.GuardError('Invalid scope config')
    return config


def has_scope(config, scheme, host, port, path):
    try:
        if scheme not in ('http','https') or not re.fullmatch(r'[a-zA-Z0-9.:-]{1,255}', host or ''):
            return False
        host = host.lower().rstrip('.')
        netloc = '['+host+']' if ':' in host else host
        if port not in (None, '', 80 if scheme == 'http' else 443):
            netloc += ':'+str(int(port))
        origin = core.normalized_origin(scheme+'://'+netloc)
        # Historical/passive inspection requires reviewed scope but NEVER automation permission.
        core.gate(config, origin, path, active=False)
        return True
    except (ValueError, TypeError, core.GuardError):
        return False


def clean_path(path):
    """Suppress query, URL credentials, IDs, and potentially sensitive slugs."""
    if not isinstance(path, str) or len(path) > 1024:
        return '/{redacted}'
    raw = urlsplit(path).path
    raw = unquote(raw, errors='replace')
    parts = []
    for fragment in raw.split('/'):
        if not fragment:
            parts.append('')
        elif len(fragment) > 56 or SENSITIVE_PATH_SEGMENT.fullmatch(fragment) or re.fullmatch(r'\d+', fragment):
            parts.append('{id}')
        elif fragment in ('{id}','{redacted}','{segment}'):
            parts.append(fragment)
        elif fragment.lower() in SAFE_STATIC or re.fullmatch(r'v[0-9]{1,2}', fragment.lower()):
            parts.append(fragment.lower())
        else:
            parts.append('{redacted}')
    return ('/'.join(parts) or '/')[:300]


def safe_names(items):
    out = set()
    for item in items[:100]:
        if not isinstance(item,str):
            continue
        if VALID_NAME.fullmatch(item) and not SENSITIVE_NAME.search(item):
            out.add(item.lower())
        elif VALID_NAME.fullmatch(item):
            # Credential-field key names are not stored; just a category signal.
            out.add('{credential-field}')
    return sorted(out)[:35]


def parse_raw_http(raw):
    """Parse only ephemeral bytes. Never write raw HTTP messages."""
    raw = raw[:MAX_HTTP_BYTES]
    pos = raw.find(b'\r\n\r\n')
    gap = 4
    if pos < 0:
        pos = raw.find(b'\n\n')
        gap = 2
    if pos < 0:
        return {}, b''
    head = raw[:pos].decode('latin1','replace').splitlines()
    if not head:
        return {}, b''
    headers = {':start': head[0]}
    for line in head[1:250]:
        if ':' not in line:
            continue
        k,v = line.split(':',1)
        k = k.strip().lower()
        if k and k not in headers:
            headers[k] = v.strip()[:2000]
    return headers, raw[pos+gap:]


def header_flags(req, resp, body, status, path):
    mime = resp.get('content-type','').lower()
    encoding = resp.get('content-encoding', '').lower()
    plain = body[:120_000].decode('latin1','replace').lower() if not encoding else ''
    flags = {x: False for x in KNOWN_FLAGS}
    if status == 200 and plain:
        flags['git_exposure'] = path.endswith('/.git/head') and bool(re.search(r'ref:\s*refs/(heads|tags)/', plain))
        flags['env_exposure'] = path.endswith('/.env') and bool(re.search(r'(?m)^\s*(?:app_key|db_password|database_url|aws_access_key_id)\s*=', plain))
        flags['phpinfo'] = 'php version' in plain and ('phpinfo()' in plain or 'php configuration' in plain)
        flags['apache_status'] = 'serverversion:' in plain and 'total accesses:' in plain
        flags['stack_trace'] = any(x in plain for x in ('traceback (most recent call last)', 'exception in thread', 'stack trace:', 'at org.springframework.'))
        flags['json_contains_sensitive_key'] = 'json' in mime and bool(re.search(r'"(?:password|secret|private_key|access_token)"\s*:', plain))
    origin = req.get('origin','')
    allow = resp.get('access-control-allow-origin','')
    flags['cors_credential_origin_reflection'] = bool(origin and origin.lower() not in ('null','') and allow == origin and resp.get('access-control-allow-credentials','').lower() == 'true')
    flags['cors_wildcard'] = allow == '*'
    flags['cache_public_authenticated'] = bool(('authorization' in req or 'cookie' in req) and 'public' in resp.get('cache-control','').lower() and status == 200)
    # Missing attributes alone are not proof of a vulnerability.
    cookies = resp.get('set-cookie','').lower()
    flags['cookie_missing_httponly'] = bool(cookies and ('session' in cookies or 'auth' in cookies) and 'httponly' not in cookies)
    flags['cookie_missing_secure'] = bool(cookies and ('session' in cookies or 'auth' in cookies) and 'secure' not in cookies)
    flags['missing_hsts'] = bool('strict-transport-security' not in resp)
    return flags


def event_from_burp_xml_item(item):
    url = item.findtext('url', default='')
    u = urlsplit(url)
    if u.scheme not in ('https','http') or not u.hostname:
        return None
    try:
        port = u.port
    except ValueError:
        return None
    req_node = item.find('request')
    res_node = item.find('response')
    if req_node is None or res_node is None:
        return None
    def raw_bytes(node):
        s = node.text or ''
        if len(s) > MAX_HTTP_BYTES*2:
            return b''
        if node.get('base64','').lower() == 'true':
            try:
                return base64.b64decode(s, validate=True)[:MAX_HTTP_BYTES]
            except (ValueError, UnicodeEncodeError):
                return b''
        return s.encode('utf-8','replace')[:MAX_HTTP_BYTES]
    req, req_body = parse_raw_http(raw_bytes(req_node))
    resp, resp_body = parse_raw_http(raw_bytes(res_node))
    if not req or not resp:
        return None
    try:
        status = int(resp[':start'].split()[1])
    except (KeyError, IndexError, ValueError):
        return None
    if not 100 <= status <= 599:
        return None
    method = (item.findtext('method') or req[':start'].split()[0]).upper()
    if method not in METHODS:
        return None
    names = [k for k,v in parse_qsl(u.query, keep_blank_values=True, max_num_fields=100)]
    mime = req.get('content-type','').lower()
    if 'application/x-www-form-urlencoded' in mime and len(req_body) < 100000:
        try:
            names += [k for k,v in parse_qsl(req_body.decode('utf-8','replace'), max_num_fields=100)]
        except ValueError:
            pass
    if 'application/json' in mime and len(req_body) < 100000:
        try:
            obj=json.loads(req_body)
            if isinstance(obj,dict):
                names += list(obj.keys())[:40]
        except (UnicodeError, ValueError):
            pass
    path = unquote(u.path, errors='replace') or '/'
    flags = header_flags(req, resp, resp_body, status, path.lower())
    return {'scheme':u.scheme,'host':u.hostname.lower(),'port':port,'path':path,'method':method,
            'status':status,'parameter_names':safe_names(names),'flags':flags,'source':'burp-xml'}


def sanitized_event(obj, scope):
    if not isinstance(obj,dict):
        return None
    scheme, host = obj.get('scheme',''), obj.get('host','')
    rawpath = obj.get('path') or obj.get('path_pattern','')
    if not isinstance(rawpath,str) or not rawpath.startswith('/') or len(rawpath)>1024:
        return None
    # Query strings and fragments are never stored. Gate by path only, not query values.
    purepath = urlsplit(rawpath).path
    if not has_scope(scope,scheme,host,obj.get('port'),purepath):
        return None
    m = str(obj.get('method','')).upper()
    if m not in METHODS:
        return None
    try:
        status = int(obj['status'])
    except (KeyError, TypeError, ValueError):
        return None
    if not 100<=status<=599:
        return None
    flags = obj.get('flags') or {}
    if not isinstance(flags,dict):
        flags = {}
    # Only allow explicit boolean signal names; arbitrary client-provided data is discarded.
    kept_flags = {k: True for k in KNOWN_FLAGS if flags.get(k) is True}
    names = safe_names(obj.get('parameter_names') if isinstance(obj.get('parameter_names'),list) else [])
    return {'scheme':scheme,'host':host.lower().rstrip('.'),'path_pattern':clean_path(purepath),'method':m,
            'status':status,'parameter_names':names,'flags':kept_flags,
            'source':'burp-live' if obj.get('source')=='burp-live' else 'burp-xml'}


def import_xml(xml_file, scope, max_items=MAX_EVENTS):
    src = Path(xml_file)
    if not src.is_file() or src.stat().st_size>MAX_XML:
        raise core.GuardError('Burp XML missing or above 80MB. Split the history into smaller exports')
    # Do not expand XML DTDs/entities from arbitrary third-party files.
    with src.open('rb') as fh:
        if b'<!DOCTYPE' in fh.read(16384).upper() or b'<!ENTITY' in src.read_bytes().upper():
            raise core.GuardError('XML DTD/entities are not accepted')
    seen=0; skipped=0; events=[]
    try:
        for _, node in ET.iterparse(str(src),events=('end',)):
            if node.tag!='item':
                continue
            seen += 1
            if seen > max_items:
                node.clear()
                break
            raw = event_from_burp_xml_item(node)
            event = sanitized_event(raw, scope) if raw else None
            if event:
                events.append(event)
            else:
                skipped+=1
            node.clear()
    except ET.ParseError as exc:
        raise core.GuardError('Malformed Burp XML') from exc
    return events,{'total_items_considered':min(seen,max_items),'skipped_out_of_scope_or_invalid':skipped,
                   'truncated_at_limit':seen>max_items,'max_items':max_items}


def analyze(events, stats=None):
    groups=defaultdict(lambda:{'count':0,'statuses':set(),'params':set(),'flags':set(),'methods':set()})
    for e in events:
        key=(e['host'],e['path_pattern'])
        x=groups[key]; x['count']+=1; x['statuses'].add(e['status']);x['params'].update(e['parameter_names']);x['flags'].update(e['flags']);x['methods'].add(e['method'])
    endpoints=[]; findings=[]
    info = {
        'git_exposure':('Potential exposed Git HEAD reference','information-disclosure','medium','strong-marker'),
        'env_exposure':('Potential exposed environment configuration','information-disclosure','high','strong-marker'),
        'phpinfo':('Potential public PHP diagnostic page','information-disclosure','medium','strong-marker'),
        'apache_status':('Potential public Apache server-status diagnostic page','information-disclosure','medium','strong-marker'),
        'cors_credential_origin_reflection':('Credentialed Origin reflection observed','cors','medium','needs-context'),
        'cache_public_authenticated':('Authenticated response marked cacheable publicly','cache-security','medium','needs-context'),
        'stack_trace':('Application stack trace indicator in response','information-disclosure','low','needs-context'),
        'cookie_missing_httponly':('Possible session cookie without HttpOnly','cookie-security','low','needs-context'),
        'cookie_missing_secure':('Possible session cookie without Secure','cookie-security','low','needs-context'),
    }
    for (host,path),x in groups.items():
        signals=sorted(x['flags'])
        themes=[]
        if any(t in path.lower() for t in AUTHZ_HINTS): themes.append('ownership-or-tenant-boundary')
        if any(t in path.lower() for t in API_HINTS): themes.append('api-or-privileged-endpoint')
        if x['params']: themes.append('parameters-present')
        if '401' in [str(v) for v in x['statuses']] and any(200<=v<300 for v in x['statuses']):
            themes.append('mixed-authentication-responses')
        priority_score=len(themes)*2 + 3*len([f for f in signals if f in info])
        endpoints.append({'host':host,'path_pattern':path,'methods':sorted(x['methods']),
                          'statuses':sorted(x['statuses']),'seen':x['count'],'parameter_names':sorted(x['params'])[:35],
                          'themes':themes,'signal_names':signals,'priority': 'high' if priority_score>=5 else 'medium' if priority_score>=2 else 'low'})
        for f in signals:
            if f not in info: continue
            title,category,severity,confidence=info[f]
            ident=__import__('hashlib').sha256(f'{host}|{path}|{f}'.encode()).hexdigest()[:16]
            findings.append({'id':ident,'asset':host,'path_pattern':path,'title':title,
                             'category':category,'signal':f,'severity_estimate':severity,'confidence':confidence,
                             'validation_status':'needs_human_review','reportable':False,
                             'evidence_redacted':f'HTTP {sorted(x["statuses"])} on {path}; passive {f} marker was observed. No response body retained.',
                             'next_step':'Verify expected security boundary, affected user/role, program exclusions, and reproducible impact using only permitted test accounts.'})
    weight={'high':0,'medium':1,'low':2}
    endpoints.sort(key=lambda e:(weight[e['priority']],-e['seen'],e['host'],e['path_pattern']))
    findings.sort(key=lambda f:(0 if f['confidence']=='strong-marker' else 1,f['asset'],f['path_pattern']))
    return {'version':VERSION,'generated_at_utc':utc_now(),'source':'Burp HTTP history, passive-only',
            'events_analyzed':len(events),'endpoint_patterns':len(endpoints),'endpoints':endpoints,
            'candidates':findings,'candidates_unverified':len(findings),
            'metadata':stats or {},
            'limitations':['Requests/responses were not replayed or modified by this integration.',
                           'IDOR/BOLA and business logic paths are hypotheses, not confirmed bugs.',
                           'Headers and content flags are indicators, not demonstrated impact.',
                           'No cookies, Authorization headers, request/response bodies, query values, or literal object IDs retained.',
                           'Live mode drops queued events if Burp extension or local receiver cannot keep up; use complete XML backfill.']}


def save_report(report, output):
    out=Path(output)
    out.mkdir(parents=True,exist_ok=True)
    write_json(out/'burp_analysis.json',report)
    lines=['# AutoHunter V4 — Burp HTTP traffic review','',f"Analyzed: **{report['events_analyzed']}** request/response pairs; **{report['endpoint_patterns']}** endpoint patterns; **{len(report['candidates'])}** unverified signals.",
           '', '> Offline/passive indicators only. Not automatically reportable on HackerOne.', '', '## Candidate security signals', '']
    for f in report['candidates']:
        lines += [f"### {f['title']}",f"- Host: `{f['asset']}`",f"- Path pattern: `{f['path_pattern']}`",f"- Evidence: {f['evidence_redacted']}",f"- Researcher check: {f['next_step']}",'']
    if not report['candidates']:
        lines += ['No concrete security signal from the selected passive rules. This is **not** a clean bill of health.', '']
    lines += ['## High-priority endpoints to review (not vulnerability claims)','']
    for e in report['endpoints'][:80]:
        if e['priority'] == 'low': continue
        lines += [f"- `{e['host']} {e['path_pattern']}` — methods {', '.join(e['methods'])}; observed statuses {e['statuses']}; themes {', '.join(e['themes']) or 'none'}"]
    lines += ['','## Privacy & coverage',''] + ['- '+note for note in report['limitations']]
    (out/'BURP_REVIEW.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    drafts=out/'burp_drafts'; drafts.mkdir(exist_ok=True)
    for f in report['candidates']:
        draft=f"""# [UNVERIFIED] {f['title']}\n\n**Asset:** `{f['asset']}`\n**Endpoint pattern:** `{f['path_pattern']}`\n**Status:** Needs manual confirmation; not ready for HackerOne submission.\n\n## Summary\nA passive review of researcher-captured Burp HTTP traffic identified a potential security signal.\n\n## Observation\n{f['evidence_redacted']}\n\n## Reproduction\nNot yet independently confirmed. Open the original item in Burp HTTP History and verify the result on an in-scope, permitted test account.\n\n## Impact\nNot established. Do not claim an exploit or severity until you demonstrate a concrete, safe effect.\n\n## Recommended next step\n{f['next_step']}\n\n## Notes\nNo original session cookies, tokens, raw responses, user data or query values were exported into this draft. Do not submit without human review.\n"""
        (drafts/(f['id']+'.md')).write_text(draft,encoding='utf-8')


def init_config(scope_path, output):
    scope_path=Path(scope_path).resolve()
    scope=read_scope(scope_path)
    if not scope.get('policy_reviewed') or not scope.get('authorization_confirmed'):
        raise core.GuardError('Before live review, confirm your program policy in the reviewed scope config')
    out=Path(output)
    if out.exists():
        raise core.GuardError('Refusing to overwrite existing Burp bridge secret')
    cfg={'scope_file':str(scope_path),'bridge_token':secrets.token_urlsafe(32),
         'local_port':8766,'allowed_hosts':scope['in_scope_hosts'],
         'mode':'passive-only','created_utc':utc_now()}
    write_json(out,cfg)
    try: out.chmod(0o600)
    except OSError: pass
    return out


def read_bridge_config(config_path):
    conf=core.load_json(config_path)
    if not isinstance(conf,dict) or not isinstance(conf.get('bridge_token'),str) or len(conf['bridge_token'])<25:
        raise core.GuardError('Invalid bridge configuration')
    if not isinstance(conf.get('local_port'),int) or not 1024<=conf['local_port']<=65535:
        raise core.GuardError('Local port must be 1024-65535')
    scope=read_scope(conf['scope_file'])
    return conf,scope


def handler_factory(config,scope,output):
    out=Path(output)
    out.mkdir(parents=True,exist_ok=True)
    event_path=out/'burp_events.ndjson'
    write_lock=threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path!='/ingest':
                return self.reply(404)
            if self.client_address[0]!='127.0.0.1':
                return self.reply(403)
            if not secrets.compare_digest(self.headers.get('X-AutoHunter-Token',''),config['bridge_token']):
                return self.reply(403)
            if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
                return self.reply(415)
            try:
                length=int(self.headers.get('Content-Length','0'))
            except ValueError:
                return self.reply(400)
            if not 0<length<=MAX_LIVE_POST:
                return self.reply(413)
            try:
                event=json.loads(self.rfile.read(length))
            except (ValueError,UnicodeError):
                return self.reply(400)
            sanitized=sanitized_event(event,scope)
            if not sanitized:
                return self.reply(403)
            with write_lock:
                if event_path.exists() and event_path.stat().st_size >= MAX_XML:
                    return self.reply(507)
                with event_path.open('a',encoding='utf-8') as fp:
                    fp.write(json.dumps(sanitized,ensure_ascii=False,separators=(',',':'))+'\n')
            self.reply(202)
        def do_GET(self):
            self.reply(404)
        def reply(self,status):
            self.send_response(status)
            self.send_header('Content-Length','0')
            self.end_headers()
        def log_message(self,fmt,*args):
            # Never log paths or incoming HTTP headers, even on malformed events.
            return
    return Handler


def analyze_file(path, scope, max_items=MAX_EVENTS):
    src=Path(path)
    if not src.is_file():
        raise core.GuardError('Live event file not found')
    if src.stat().st_size > MAX_XML:
        raise core.GuardError('Live JSONL exceeds 80MB; rotate input')
    events=[]; skipped=0
    with src.open(encoding='utf-8') as fh:
        for n,line in enumerate(fh):
            if n>=max_items:
                break
            try: event=sanitized_event(json.loads(line),scope)
            except (ValueError,TypeError): event=None
            if event: events.append(event)
            else: skipped += 1
    return events,{'invalid_or_out_of_scope':skipped}


def main(argv=None):
    p=argparse.ArgumentParser(description='AutoHunter v4: Burp History XML + live passive localhost bridge')
    sub=p.add_subparsers(dest='command',required=True)
    it=sub.add_parser('import-xml',help='Offline analysis of Burp Save Items XML, no network')
    it.add_argument('--scope',required=True);it.add_argument('--xml',required=True);it.add_argument('--output',required=True)
    ini=sub.add_parser('init',help='Create secret/config for passive live integration')
    ini.add_argument('--scope',required=True);ini.add_argument('--output',required=True)
    srv=sub.add_parser('serve',help='Listen only on 127.0.0.1; no target traffic')
    srv.add_argument('--config',required=True);srv.add_argument('--output',required=True)
    rpt=sub.add_parser('report-live',help='Summarize the captured redacted live events')
    rpt.add_argument('--config',required=True);rpt.add_argument('--input',required=True);rpt.add_argument('--output',required=True)
    a=p.parse_args(argv)
    try:
        if a.command=='import-xml':
            scope=read_scope(a.scope)
            events,stats=import_xml(a.xml,scope)
            report=analyze(events,stats)
            save_report(report,a.output)
            print(f"Imported {report['events_analyzed']} in-scope Burp pairs; {len(report['candidates'])} unverified signals. Output: {a.output}")
        elif a.command=='init':
            print('Created local secret file:',init_config(a.scope,a.output))
            print('Keep this file private, next to BurpAutoHunter.py extension. Never commit it.')
        elif a.command=='serve':
            config,scope=read_bridge_config(a.config)
            server=ThreadingHTTPServer(('127.0.0.1',config['local_port']),handler_factory(config,scope,a.output))
            print(f"Passive receiver listening on http://127.0.0.1:{config['local_port']}; press Ctrl+C to stop",flush=True)
            try: server.serve_forever()
            except KeyboardInterrupt: pass
            finally: server.server_close()
        elif a.command=='report-live':
            conf,scope=read_bridge_config(a.config)
            events,stats=analyze_file(a.input,scope)
            report=analyze(events,stats)
            save_report(report,a.output)
            print(f"Analyzed {report['events_analyzed']} redacted events; {len(report['candidates'])} unverified signals. Output: {a.output}")
    except (core.GuardError,OSError,ValueError) as exc:
        print('ERROR:',str(exc),file=sys.stderr)
        return 2
    return 0


if __name__=='__main__':
    raise SystemExit(main())
