#!/usr/bin/env python3
"""Offline-only HAR request-path triage. Never sends HTTP requests.

HAR often contains credentials and personal data: keep originals private. Output
contains no cookies, query values, bodies, tokens, or literal resource IDs.
"""
import argparse
from collections import defaultdict
import datetime as dt
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

TOKENISH = re.compile(r"^(?:[0-9]{2,}|[0-9a-f]{8}-[0-9a-f-]{20,}|[a-z0-9_-]{24,})$", re.I)
INTEREST = {
    "authorization/tenancy": ("account", "user", "profile", "team", "tenant", "org", "member", "role", "permission"),
    "sensitive-resource": ("invoice", "document", "report", "file", "export", "order", "address", "payment"),
    "privileged-function": ("admin", "settings", "billing", "webhook", "token", "invite", "recovery", "api-key"),
    "api-surface": ("graphql", "api", "rpc", "v1", "v2", "rest"),
}


def path_template(path):
    parts = path.split("/")
    return "/".join("{id}" if TOKENISH.fullmatch(x) else x for x in parts) or "/"


def triage_har(data, in_scope_hosts):
    groups = defaultdict(lambda: {"count": 0, "methods": set(), "status_codes": set(), "themes": set()})
    skipped = 0
    for entry in data.get("log", {}).get("entries", []):
        req = entry.get("request", {})
        raw = req.get("url", "")
        parts = urlsplit(raw)
        host = (parts.hostname or "").lower()
        if host not in in_scope_hosts or parts.scheme not in ("https", "http"):
            skipped += 1
            continue
        method = str(req.get("method", "GET")).upper()
        path = path_template(parts.path)
        key = (host, path)
        row = groups[key]
        row["count"] += 1
        row["methods"].add(method)
        status = entry.get("response", {}).get("status")
        if isinstance(status, int):
            row["status_codes"].add(status)
        low = path.lower()
        for category, needles in INTEREST.items():
            if any(n in low for n in needles):
                row["themes"].add(category)
    paths = []
    for (host, template), row in groups.items():
        themes = sorted(row["themes"])
        score = 2 * len(themes) + (2 if "authorization/tenancy" in themes else 0) + (1 if "privileged-function" in themes else 0)
        paths.append({"host": host, "path_pattern": template, "methods": sorted(row["methods"]),
                      "statuses": sorted(row["status_codes"]), "seen": row["count"], "interest": themes,
                      "review_priority": "high" if score >= 5 else "medium" if score >= 2 else "low"})
    paths.sort(key=lambda x: ({"high": 0, "medium": 1, "low": 2}[x["review_priority"]], x["host"], x["path_pattern"]))
    return {"note": "Offline triage ONLY; no exploit claimed. Query values, headers, cookies, response bodies and identifiers omitted.",
            "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "skipped_entries_outside_exact_host_allowlist": skipped, "endpoints": paths}


def main():
    p = argparse.ArgumentParser(description="Offline HAR triage; no web requests")
    p.add_argument("--har", required=True)
    p.add_argument("--exact-host", action="append", required=True, help="Repeat for each reviewed exact host")
    p.add_argument("--output", required=True)
    a = p.parse_args()
    obj = json.loads(Path(a.har).read_text(encoding="utf-8"))
    data = triage_har(obj, {h.lower() for h in a.exact_host})
    Path(a.output).parent.mkdir(parents=True, exist_ok=True)
    Path(a.output).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Triage of {len(data['endpoints'])} endpoint patterns saved to {a.output} (offline; no raw tokens written)")


if __name__ == "__main__":
    main()
