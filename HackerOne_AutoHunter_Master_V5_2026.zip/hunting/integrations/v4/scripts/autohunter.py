#!/usr/bin/env python3
"""Autohunter v3: scope-gated, bounded, resumable evidence-first workflow.

No hidden network operations. No creds or complete HTTP bodies stored.
Python 3.10+, standard library. Active traffic needs explicit program approval.
"""
from __future__ import annotations
import argparse
from collections import deque
import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import sys
from urllib.parse import urlsplit, urljoin, urlunsplit

import h1_hunter as core
import har_triage as har

VERSION = '4.0.0'
ROOT = Path(__file__).resolve().parents[1]
SENSITIVE_PATH = re.compile(r'(?:^|/)(?:logout|log-out|signout|delete|destroy|remove|purchase|checkout|refund|transfer|unsubscribe|reset-password|confirm-payment|send|execute)(?:/|$)', re.I)
ENDPOINT_PATTERN = re.compile(r'''["'`](\/api\/[a-zA-Z0-9_./{}-]{3,180}|\/graphql\b|\/v\d+\/[a-zA-Z0-9_./{}-]{3,180})["'`]''')


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def json_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    core.write_json(path, data)


def file_write(path, contents):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(contents, encoding='utf-8')


def safe_url(url, config):
    u = urlsplit(url)
    if u.query or u.fragment or u.username or u.password:
        return None
    try:
        origin = core.normalized_origin(urlunsplit((u.scheme, u.netloc, '', '', '')))
        path = u.path or '/'
        core.gate(config, origin, path, active=True)
    except (core.GuardError, ValueError):
        return None
    if SENSITIVE_PATH.search(path) or re.search(r'(?i)\.(?:png|jpg|gif|svg|css|woff|pdf|zip|tar|gz|map|ico)$', path):
        return None
    return origin + path


class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        if tag != 'a':
            return
        attr = dict(attrs)
        if attr.get('href'):
            self.links.append(attr['href'])


def bounded_crawl(config, origin, max_pages=6):
    """Pure GET HTML crawler, 1 origin, no queries/forms/redirects/side-effect-looking paths."""
    max_pages = min(12, max(1, int(max_pages)))
    queue = deque([origin + '/'])
    visited = set()
    lim = core.RateLimiter(config['max_requests_per_second'])
    entries = []
    stop = False
    while queue and len(visited) < max_pages and not stop:
        url = queue.popleft()
        candidate = safe_url(url, config)
        if not candidate or candidate in visited:
            continue
        visited.add(candidate)
        lim.tick()
        r = core.request(candidate)
        path = urlsplit(candidate).path
        entries.append({'path': path, 'status': r.get('status'), 'error': r.get('error')})
        if r.get('status') in (429, 500, 502, 503, 504):
            stop = True
            continue
        if r.get('status') != 200 or r.get('truncated'):
            continue
        ctype = r.get('headers', {}).get('content-type', '')
        if 'text/html' not in ctype:
            continue
        p = LinkParser()
        try:
            p.feed(r['body'].decode('utf-8', 'replace'))
        except ValueError:
            continue
        for href in p.links[:60]:
            target = safe_url(urljoin(candidate, href), config)
            if target and target not in visited and target not in queue and target.startswith(origin + '/'):
                queue.append(target)
    return {'visited': entries, 'stopped_on_server_error': stop,
            'note': 'Bounded HTTP GET, without redirects, queries, forms, or automatic JS execution; link list is not vulnerability evidence'}


def collect_js_offline(directory, approved_hosts):
    """Extract only URL path patterns from local JS; no execution and no strings/secrets."""
    directory = Path(directory)
    if not directory.is_dir():
        raise core.GuardError('JS path must be a directory')
    found = set()
    visited = 0
    for f in sorted(directory.rglob('*')):
        if visited >= 100:
            break
        if not f.is_file() or f.is_symlink() or f.suffix.lower() not in ('.js', '.mjs', '.txt') or f.stat().st_size > 1_000_000:
            continue
        visited += 1
        txt = f.read_text(encoding='utf-8', errors='replace')
        for p in ENDPOINT_PATTERN.findall(txt):
            if '..' in p or len(p) > 160:
                continue
            template = har.path_template(p)
            # Replace literal numeric and long alnum path fragments before writing.
            parts = template.split('/')
            clean = '/'.join('{id}' if re.fullmatch(r'[a-zA-Z0-9_-]{24,}', part) else part for part in parts)
            found.add(clean)
    return {'files_examined': visited, 'endpoint_path_patterns': sorted(found)[:500],
            'note': 'Offline JS string pattern extraction only; no vulnerability claim and no request sent'}


def select_har_hosts(config, seeds):
    return {urlsplit(x).hostname for x in seeds}


def fingerprint(origin, item):
    blob = json.dumps([origin, item.get('category', ''), item.get('path', ''), item.get('title', '')], sort_keys=True)
    return hashlib.sha256(blob.encode()).hexdigest()[:16]


def rank_findings(findings):
    for f in findings:
        base = {'high': 6, 'medium': 4, 'low': 2}.get(str(f.get('severity_estimate')).lower(), 1)
        conf = 3 if f.get('confidence') in ('strong-marker', 'strong-signal') else 0
        f['triage_score'] = base + conf
        f['triage_tier'] = 'P1' if base + conf >= 9 else 'P2' if base + conf >= 6 else 'P3'
        f['validation_status'] = 'needs_human_review'
        f['reportable'] = False
    return sorted(findings, key=lambda f: -f['triage_score'])


def pretty_report(program, origin, f, reviewed=None):
    reviewed = reviewed or {}
    verified = bool(reviewed.get('verified_by_researcher') and reviewed.get('evidence_reviewed'))
    typ = f.get('category', 'security')
    target = origin + f.get('path', '/')
    intro = {
        'access-control-idor': 'A controlled two-account authorization check suggests that one researcher-owned account can read a resource belonging to another researcher-owned account.',
        'information-disclosure': 'During a limited, read-only review, the application returned a response consistent with an exposed server-side resource.',
        'cors': 'The application responded to a synthetic, untrusted Origin in a way that may warrant further CORS assessment.',
    }.get(typ, 'A limited security check produced a result that needs further confirmation.')
    severity = f.get('severity_estimate', 'unrated')
    evidence = f.get('evidence_redacted', 'None recorded')
    if verified:
        impact = reviewed['demonstrated_impact'].strip()
        expected = reviewed['expected_behavior'].strip()
        actual = reviewed['actual_behavior'].strip()
        repro = reviewed['reproduction_steps'].strip()
        title = f['title']
        status = 'RESEARCHER-VERIFIED — REVIEW BEFORE SUBMISSION'
    else:
        impact = 'Not established by the automation. Confirm a practical security impact before submitting.'
        expected = 'Document the intended authorization or exposure rule after program review.'
        actual = 'The automated observation above is not yet independently confirmed.'
        repro = '1. Reproduce the minimal allowed request using a researcher-owned test identity.\n2. Confirm that the observed result is not intended or excluded.\n3. Record sanitized request/response metadata and concrete impact.'
        title = '[UNVERIFIED DRAFT] ' + f['title']
        status = 'DRAFT — NOT READY TO SUBMIT'
    return f'''# {title}

**Status:** {status}  
**Program:** {program}  
**Asset:** `{target}`  
**Severity:** {severity} (researcher must verify against program rules)

## Summary
{intro} {('The following details were independently reviewed by the researcher.' if verified else 'This is a lead rather than a confirmed vulnerability.')}

## What I observed
{evidence}

## Steps to reproduce
{repro}

## Expected behavior
{expected}

## Actual behavior
{actual}

## Demonstrated security impact
{impact}

## Suggested remediation
Review the server-side security boundary on the affected endpoint and add regression tests for the expected access and exposure rules.

## Research notes
The initial scan used bounded GET requests, suppressed response bodies, and did not follow redirects. Testing permissions and severity are subject to the current individual HackerOne program policy. No report was automatically submitted.
'''


def make_hypotheses(har_report, js_report):
    rows = []
    for e in har_report.get('endpoints', []) if har_report else []:
        theme = e.get('interest', [])
        if not theme:
            continue
        priority = e['review_priority']
        rows.append({'kind': 'offline_hypothesis', 'source': 'HAR', 'host': e['host'], 'endpoint_pattern': e['path_pattern'],
                     'reason': 'Endpoints associated with ' + ', '.join(theme) + ' warrant authorization / workflow review.',
                     'priority': priority, 'verified': False})
    for p in (js_report or {}).get('endpoint_path_patterns', [])[:100]:
        rank = 'high' if any(x in p.lower() for x in ('/admin', '/billing', '/users', '/roles')) else 'medium'
        rows.append({'kind': 'offline_hypothesis', 'source': 'JS', 'endpoint_pattern': p,
                     'reason': 'Reference found in supplied local JavaScript; verify existence, ownership and authorization manually.',
                     'priority': rank, 'verified': False})
    order = {'high': 0, 'medium': 1, 'low': 2}
    return sorted(rows, key=lambda x: (order.get(x['priority'], 3), x['endpoint_pattern']))


def validate_seeds(config):
    seeds = config.get('seed_origins')
    if not isinstance(seeds, list) or not seeds or len(seeds) > 10:
        raise core.GuardError('seed_origins must contain 1-10 explicitly approved exact HTTP(S) origins')
    cleaned = []
    for seed in seeds:
        if not isinstance(seed, str):
            raise core.GuardError('seed origins must be URLs')
        normalized = core.gate(config, seed, '/', active=True)
        if normalized not in cleaned:
            cleaned.append(normalized)
    if config.get('crawl_enabled') not in (True, False, None):
        raise core.GuardError('crawl_enabled must be boolean')
    if config.get('crawl_enabled') and not config.get('crawler_allowed'):
        raise core.GuardError('Crawler explicitly disabled by program policy config')
    return cleaned


def plan(config):
    targets = []
    for target in config.get('seed_origins', []):
        try:
            origin = core.normalized_origin(target)
            status = 'allowed-by-local-policy' if core.gate(config, origin, '/', active=True) else 'blocked'
        except core.GuardError as exc:
            origin, status = target, 'BLOCKED: ' + str(exc)
        targets.append({'origin': origin, 'status': status})
    return {'version': VERSION, 'program': config.get('program_handle'), 'policy_url': config.get('policy_url'),
            'targets': targets, 'modules': {'bounded_exposure_checks': True, 'bounded_crawler': bool(config.get('crawl_enabled')),
                'offline_HAR': True, 'offline_JS': True, 'burp_xml_offline': True, 'burp_passive_live_import': True, 'owned_account_authz': 'requires separate two-owned-account approval' if config.get('owned_cases') else False,
                'nuclei': 'offline JSONL import supported; automatic Nuclei execution disabled'},
            'conditions': ['Current program policy manually reviewed', 'Explicit allowed host list and exact seed origins',
                           'Permitted automated GET checks', 'Researcher must validate before reporting']}



def check_owned_cases(config, seeds, account_consent=False):
    cases = config.get('owned_cases', [])
    if not isinstance(cases, list) or len(cases) > 5:
        raise core.GuardError('owned_cases must be a list of at most 5 researcher-owned test cases')
    if not cases:
        return []
    if not account_consent:
        raise core.GuardError('Owned authorization cases require --i-own-two-accounts')
    a, b = os.getenv('H1_TEST_A_TOKEN'), os.getenv('H1_TEST_B_TOKEN')
    if not a or not b or a == b:
        raise core.GuardError('Set different H1_TEST_A_TOKEN and H1_TEST_B_TOKEN for two owned accounts')
    checked = []
    for entry in cases:
        if not isinstance(entry, dict) or not entry.get('case_file') or not entry.get('origin'):
            raise core.GuardError('Each owned case requires origin and case_file')
        origin = core.normalized_origin(entry['origin'])
        if origin not in seeds:
            raise core.GuardError('Owned case origin must be one of the exact seed origins')
        case = core.load_json(entry['case_file'])
        path = case.get('path', '')
        core.gate(config, origin, path, active=True, kind='authz')
        if not core.valid_path(path) or urlsplit(path).query or case.get('method','GET').upper() != 'GET':
            raise core.GuardError('Owned case must be read-only GET with plain path')
        if not case.get('researcher_owns_both_accounts_and_resource') or case.get('owner') not in ('A','B'):
            raise core.GuardError('Case must attest two owned accounts and an owned synthetic resource')
        if not re.fullmatch(r'H1_TEST_[A-Za-z0-9_-]{6,112}',str(case.get('synthetic_private_marker',''))):
            raise core.GuardError('Case requires an owned synthetic H1_TEST_ marker')
        if case.get('auth_method','bearer') not in ('bearer','cookie'):
            raise core.GuardError('Case auth_method must be bearer or cookie')
        checked.append((origin, case))
    return checked


def run(config_file, output, approved=False, har_file=None, js_dir=None, resume=False, account_consent=False, burp_xml=None, burp_events=None):
    out = Path(output)
    cfg = core.load_json(config_file)
    seeds = validate_seeds(cfg) # validate everything before first active request
    if not approved:
        raise core.GuardError('Active scanning requires --i-reviewed-policy, after verifying actual program rules')
    owned_cases = check_owned_cases(cfg, seeds, account_consent=account_consent)
    if out.exists() and any(out.iterdir()) and not resume:
        raise core.GuardError('Output directory already has files; choose a new directory or --resume')
    out.mkdir(parents=True, exist_ok=True)
    json_write(out/'plan.json', plan(cfg))
    old = core.load_json(out/'state.json') if resume and (out/'state.json').exists() else {}
    results = old.get('runs', [])
    already = {x['origin'] for x in results if x.get('done')}
    halted = False
    halt_reason = ''
    findings = old.get('findings', [])
    authz_runs = old.get('authz_runs', [])
    index = {x['id'] for x in findings}
    for origin in seeds:
        if origin in already:
            continue
        fnd, probes, notes = core.scans(cfg, origin)
        row = {'origin': origin, 'done': True, 'probes': probes, 'notes': notes, 'crawl': None, 'time_utc': stamp()}
        for f in fnd:
            f['asset'] = origin
            f['id'] = fingerprint(origin, f)
            if f['id'] not in index:
                index.add(f['id'])
                findings.append(f)
        if cfg.get('crawl_enabled') and not any('Stopped on HTTP' in n for n in notes):
            row['crawl'] = bounded_crawl(cfg, origin, max_pages=cfg.get('max_crawl_pages', 6))
        results.append(row)
        if any('Stopped on HTTP' in note for note in notes):
            halted = True
            halt_reason = f'Stopped remaining campaign after a throttling/server-error response from {origin}'
        if row.get('crawl') and row['crawl'].get('stopped_on_server_error'):
            halted = True
            halt_reason = f'Stopped remaining campaign after crawling a throttled/unstable target {origin}'
        # Checkpoint immediately: interrupted sessions can be resumed without reprobing completed hosts.
        json_write(out/'state.json', {'version': VERSION, 'program': cfg['program_handle'], 'runs': results, 'findings': findings})
        if halted:
            break
    # Exact, read-only researcher-owned account comparisons, only after independent consent.
    tested_cases = {(x['origin'], x['path']) for x in authz_runs if x.get('done')}
    for origin, case in ([] if halted else owned_cases):
        unique = (origin, case['path'])
        if unique in tested_cases:
            continue
        fnd, probes, notes = core.authz_case(cfg, origin, case)
        authz_runs.append({'origin': origin, 'path': case['path'], 'done': True,
                           'probes': probes, 'notes': notes, 'time_utc': stamp()})
        for f in fnd:
            f['asset'] = origin
            f['id'] = fingerprint(origin, f)
            if f['id'] not in index:
                index.add(f['id'])
                findings.append(f)
        json_write(out/'state.json', {'version': VERSION, 'program': cfg['program_handle'],
                   'runs': results, 'authz_runs': authz_runs, 'findings': findings})
    hr = None
    jsr = None
    if har_file:
        hr = har.triage_har(core.load_json(har_file), select_har_hosts(cfg, seeds))
        json_write(out/'har_endpoints.json', hr)
    if js_dir:
        jsr = collect_js_offline(js_dir, select_har_hosts(cfg, seeds))
        json_write(out/'js_endpoints.json', jsr)
    hypotheses = make_hypotheses(hr, jsr)
    if burp_xml or burp_events:
        # Import previously observed Burp history; never replay HTTP requests.
        import burp_bridge
        burp_rows = []
        import_stats = {}
        if burp_xml:
            rows, meta = burp_bridge.import_xml(burp_xml, cfg)
            burp_rows.extend(rows)
            import_stats['xml'] = meta
        if burp_events:
            rows, meta = burp_bridge.analyze_file(burp_events, cfg)
            burp_rows.extend(rows)
            import_stats['live'] = meta
        burp_report = burp_bridge.analyze(burp_rows, import_stats)
        burp_bridge.save_report(burp_report, out/'burp')
        for e in burp_report['endpoints']:
            if e['priority'] == 'low':
                continue
            hypotheses.append({'kind':'offline_hypothesis','source':'BURP', 'host':e['host'],
                   'endpoint_pattern':e['path_pattern'], 'priority':e['priority'],
                   'reason':'Observed Burp traffic with themes: '+', '.join(e['themes'] or e['signal_names']),
                   'verified':False})
        for candidate in burp_report['candidates']:
            f={'id': candidate['id'], 'asset':'https://'+candidate['asset'],
              'path':candidate['path_pattern'], 'title':candidate['title'],
              'category':candidate['category'], 'severity_estimate':candidate['severity_estimate'],
              'confidence':candidate['confidence'], 'validation_status':'needs_human_review',
              'reportable':False, 'evidence_redacted':candidate['evidence_redacted'],
              'next_step':candidate['next_step'], 'state':'candidate_needs_manual_validation'}
            if f['id'] not in index:
                findings.append(f)
                index.add(f['id'])
    json_write(out/'hypotheses.json', hypotheses)
    findings = rank_findings(findings)
    state = {'version': VERSION, 'program': cfg['program_handle'], 'policy_url': cfg['policy_url'],
             'timestamp_utc': stamp(), 'halt_reason': halt_reason, 'runs': results, 'authz_runs': authz_runs, 'findings': findings, 'hypotheses': hypotheses}
    json_write(out/'state.json', state)
    render_bundle(out, state)
    return state


def render_bundle(out, state):
    out = Path(out)
    findings = state.get('findings', [])
    for f in findings:
        file_write(out/'drafts'/f"{f['id']}.md", pretty_report(state['program'], f['asset'], f))
    summary = [f"# H1 Autohunter v{VERSION} — Run summary", '', f"Program: **{state['program']}**",
               f"Checked origins: **{len(state.get('runs', []))}**; Candidate signals: **{len(findings)}**; Offline hypotheses: **{len(state.get('hypotheses', []))}**", '',
               '> A candidate is not a confirmed, reportable vulnerability. No HackerOne reports were submitted.', '']
    if state.get('halt_reason'):
        summary += ['**Campaign halted:** '+state['halt_reason'], '']
    for f in findings:
        summary += [f"## {f['title']}", f"- Candidate ID: `{f['id']}`", f"- Asset: `{f['asset']}{f['path']}`", f"- Triage: {f['triage_tier']} / confidence {f.get('confidence')}",
                    f"- Evidence: {f['evidence_redacted']}", f"- Next: {f['next_step']}", '']
    if not findings:
        summary.append('No candidate from the selected checks. This does **not** prove the assets are secure.')
    summary.append(f"Researcher-owned authorization cases: **{len(state.get('authz_runs', []))}**")
    summary += ['', '## Coverage and exclusions', '']
    for row in state.get('runs', []):
        summary.append(f"- `{row['origin']}`: {len(row['probes'])} HTTP probes; crawler {'enabled' if row.get('crawl') else 'not run'}")
        for n in row.get('notes', []):
            summary.append('  - ' + n)
    summary += ['', 'Out of scope: mass fuzzing, brute force, automatically executing third-party template packs, active exploitation, high-impact transactions, unowned resources, and auto-submission.']
    file_write(out/'SUMMARY.md', '\n'.join(summary) + '\n')


def review(out, decision_file):
    out = Path(out)
    data = core.load_json(out/'state.json')
    decision = core.load_json(decision_file)
    fid = decision.get('id')
    match = next((x for x in data.get('findings', []) if x['id'] == fid), None)
    if not match:
        raise core.GuardError('Review ID not found in this run')
    if not decision.get('verified_by_researcher') or not decision.get('evidence_reviewed'):
        raise core.GuardError('Researcher verification required; no automated promotion to verified')
    mandatory = ('demonstrated_impact','expected_behavior','actual_behavior','reproduction_steps')
    if any(not isinstance(decision.get(k), str) or len(decision[k].strip()) < 15 for k in mandatory):
        raise core.GuardError('Complete all four reviewed fields with >=15 characters each')
    if any(re.search(r'(?i)(bearer\s+[A-Za-z0-9_.-]{15,}|api[_-]?key\s*[:=]\s*\S+)', decision[k]) for k in mandatory):
        raise core.GuardError('Possible credential in review fields; redact before writing')
    reviews = data.setdefault('researcher_reviews', {})
    reviews[fid] = {k:decision[k] for k in mandatory}
    reviews[fid].update({'verified_by_researcher': True, 'evidence_reviewed': True, 'reviewed_at_utc': stamp()})
    json_write(out/'state.json', data)
    file_write(out/'ready_for_review'/f'{fid}.md', pretty_report(data['program'], match['asset'], match, reviews[fid]))
    return fid


def ingest_nuclei(out, source, config):
    """Never execute external templates. Safely summarize redacted JSONL created elsewhere."""
    src = Path(source)
    if src.stat().st_size > 10_000_000:
        raise core.GuardError('JSONL too large (max 10 MB)')
    rows=[]
    for n, line in enumerate(src.read_text(encoding='utf-8', errors='replace').splitlines()):
        if n >= 2000:
            break
        try:
            raw = json.loads(line)
        except json.JSONDecodeError:
            continue
        name = str(raw.get('template-id') or raw.get('templateID') or 'unknown')[:100]
        severity = str((raw.get('info') or {}).get('severity') or 'unknown')[:16]
        matched = str(raw.get('matched-at') or raw.get('host') or '')
        u = urlsplit(matched)
        if not u.hostname or not any(core.host_matches(u.hostname.lower(), h) for h in config.get('in_scope_hosts', [])) or any(core.host_matches(u.hostname.lower(), h) for h in config.get('out_of_scope_hosts', [])):
            continue
        # Excluded paths and malformed paths must not be normalized into candidates.
        if not core.valid_path(u.path or '/') or core.path_excluded(u.path or '/', config.get('out_of_scope_paths', [])):
            continue
        # Don't preserve raw paths, matched snippets, or HTTP response data.
        rows.append({'template_id': name, 'severity_unverified': severity, 'hostname': u.hostname.lower(),
                     'path_pattern': har.path_template(u.path or '/'), 'status': 'template_match_requires_researcher_validation'})
    json_write(Path(out)/'nuclei_candidates.json', {'matches': rows, 'note':'Imported offline; no templates executed; no proof of exploit'})
    return len(rows)


def doctor():
    return {'python': sys.version.split()[0], 'optional_tools': {x: shutil.which(x) or 'not installed' for x in ('nuclei','katana','subfinder','ffuf')},
            'engine':'Python standard library, no external keys required',
            'nuclei_policy':'manual vetted runs + offline import only; no arbitrary template execution'}


def cli(argv=None):
    p=argparse.ArgumentParser(description='Scope-first HackerOne bug-hunter v3 (permission gated)')
    sub=p.add_subparsers(dest='cmd', required=True)
    ini=sub.add_parser('init', help='Create reviewed scope config; no network')
    ini.add_argument('--scope-file', required=True, help='One exact HTTPS origin per line (localhost HTTP allowed)')
    ini.add_argument('--program', required=True)
    ini.add_argument('--output', required=True, help='Destination config .json')
    pre=sub.add_parser('plan', help='Offline scope and module preflight')
    pre.add_argument('--scope', required=True)
    hunt=sub.add_parser('hunt', help='Run bounded GET checks after policy review')
    hunt.add_argument('--scope', required=True)
    hunt.add_argument('--output', required=True)
    hunt.add_argument('--i-reviewed-policy', action='store_true')
    hunt.add_argument('--har', default=None)
    hunt.add_argument('--js-dir', default=None)
    hunt.add_argument('--burp-xml', default=None, help='Offline Burp Save Items XML; no replay')
    hunt.add_argument('--burp-events', default=None, help='Previously captured redacted Burp bridge JSONL')
    hunt.add_argument('--resume', action='store_true')
    hunt.add_argument('--i-own-two-accounts', action='store_true', help='Separate consent for explicitly configured owned-account authorization checks')
    rv=sub.add_parser('review', help='Promote one researcher-reviewed finding to report draft')
    rv.add_argument('--output', required=True)
    rv.add_argument('--decision', required=True)
    ing=sub.add_parser('ingest-nuclei', help='Offline import only; external template execution disabled')
    ing.add_argument('--output', required=True)
    ing.add_argument('--jsonl', required=True)
    ing.add_argument('--scope', required=True)
    sub.add_parser('doctor', help='Print tool availability and runtime readiness')
    a=p.parse_args(argv)
    try:
        if a.cmd == 'init':
            target=Path(a.output)
            if target.exists():
                raise core.GuardError('Refusing to overwrite existing config')
            origins=[]
            for line in Path(a.scope_file).read_text(encoding='utf-8').splitlines():
                line=line.strip()
                if not line or line.startswith('#'):
                    continue
                origin=core.normalized_origin(line)
                if origin not in origins:
                    origins.append(origin)
            if not origins or len(origins)>10:
                raise core.GuardError('1-10 exact seed origins required')
            cfg=core.load_json(ROOT/'config'/'program.sample.json')
            cfg['program_handle']=a.program
            cfg['policy_url']='https://hackerone.com/'+a.program
            cfg['seed_origins']=origins
            cfg['in_scope_hosts']=sorted({urlsplit(x).hostname for x in origins})
            cfg['crawl_enabled']=False
            cfg['crawler_allowed']=False
            cfg['max_crawl_pages']=6
            json_write(target, cfg)
            print(f'Created {target}; authorization flags DENY by default. Verify live program policy and exclusions before changing them.')
        elif a.cmd=='plan':
            print(json.dumps(plan(core.load_json(a.scope)), indent=2))
        elif a.cmd=='hunt':
            data=run(a.scope, a.output, approved=a.i_reviewed_policy, har_file=a.har, js_dir=a.js_dir, resume=a.resume, account_consent=a.i_own_two_accounts, burp_xml=a.burp_xml, burp_events=a.burp_events)
            print(f"{len(data['runs'])} origins, {len(data['findings'])} candidate signals, {len(data['hypotheses'])} offline hypotheses. See {Path(a.output)/'SUMMARY.md'}")
        elif a.cmd=='review':
            fid=review(a.output,a.decision)
            print(f'Researcher-reviewed report draft created: {Path(a.output)/"ready_for_review"/(fid+".md")}; not submitted.')
        elif a.cmd=='ingest-nuclei':
            print(f"Imported {ingest_nuclei(a.output,a.jsonl,core.load_json(a.scope))} JSONL template matches for offline review")
        elif a.cmd=='doctor':
            print(json.dumps(doctor(), indent=2))
    except (core.GuardError, ValueError, KeyError, OSError, json.JSONDecodeError) as ex:
        print('ERROR:',str(ex),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    sys.exit(cli())
