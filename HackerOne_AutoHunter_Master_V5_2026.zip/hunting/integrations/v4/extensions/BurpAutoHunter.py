# -*- coding: utf-8 -*-
"""Burp Suite live passive bridge. Jython 2.7 / legacy Extender API.

Load from Burp > Extensions after installing Jython standalone runtime.
Captures in-scope completed HTTP request/response *metadata*, never raw bodies.
Sends only to localhost receiver, does not modify traffic or replay requests.
"""
from burp import IBurpExtender, IHttpListener, IExtensionStateListener
import json
import os
import re
import threading
import urllib2
from Queue import Queue, Full, Empty


class BurpExtender(IBurpExtender, IHttpListener, IExtensionStateListener):
    def registerExtenderCallbacks(self, callbacks):
        self.callbacks = callbacks
        self.helpers = callbacks.getHelpers()
        self.callbacks.setExtensionName('AutoHunter V4 — Passive Burp Bridge')
        cfg_file = os.environ.get('AUTOHUNTER_BURP_CONFIG')
        if not cfg_file:
            cfg_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'burp_bridge.local.json')
        try:
            with open(cfg_file, 'r') as fh:
                cfg = json.load(fh)
            self.token = cfg['bridge_token']
            self.port = int(cfg.get('local_port', 8766))
            self.hosts = [str(h).lower().strip('.') for h in cfg['allowed_hosts']]
            if not self.token or not self.hosts or self.port < 1024:
                raise ValueError('Missing secret or reviewed host list')
        except Exception:
            callbacks.printError('AutoHunter: missing/invalid bridge config, run `burp_bridge.py init` and place JSON beside this extension.')
            return
        self.queue = Queue(maxsize=2000)
        self.dropped = 0
        self.running = True
        self.worker = threading.Thread(target=self._sender)
        self.worker.setDaemon(True)
        self.worker.start()
        callbacks.registerHttpListener(self)
        callbacks.registerExtensionStateListener(self)
        callbacks.printOutput('AutoHunter: passive capture active for allowed hosts; metadata goes only to localhost on port %s.' % self.port)

    def extensionUnloaded(self):
        self.running = False

    def _host_allowed(self, host):
        host = host.lower().rstrip('.')
        for entry in self.hosts:
            if entry.startswith('*.'):
                suffix = entry[1:]
                if host.endswith(suffix) and host != entry[2:]:
                    return True
            elif host == entry:
                return True
        return False

    def _sender(self):
        endpoint = 'http://127.0.0.1:%s/ingest' % self.port
        while self.running:
            try:
                item = self.queue.get(True, 0.3)
            except Empty:
                continue
            try:
                data = json.dumps(item)
                request = urllib2.Request(endpoint, data, {
                    'Content-Type': 'application/json', 'X-AutoHunter-Token': self.token,
                })
                response = urllib2.urlopen(request, timeout=0.7)
                response.close()
            except Exception:
                # Burp must always continue normally even when receiver is stopped.
                self.dropped += 1
                if self.dropped in (1, 100, 1000) or (self.dropped % 5000 == 0):
                    self.callbacks.printError('AutoHunter: some events were not delivered (%s). Export HTTP History XML for complete backfill.' % self.dropped)
            finally:
                self.queue.task_done()

    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        if messageIsRequest or not self.running:
            return
        try:
            service = messageInfo.getHttpService()
            host = str(service.getHost()).lower().rstrip('.')
            if not self._host_allowed(host):
                return
            req_bytes = messageInfo.getRequest()
            resp_bytes = messageInfo.getResponse()
            if req_bytes is None or resp_bytes is None:
                return
            req = self.helpers.analyzeRequest(messageInfo)
            resp = self.helpers.analyzeResponse(resp_bytes)
            url = req.getUrl()
            path = str(url.getPath()) or '/'
            if len(path) > 1024:
                return
            method = str(req.getMethod()).upper()
            # Do not send query values, cookies, response body, Authorization, etc.
            names=[]
            for p in list(req.getParameters())[:100]:
                names.append(str(p.getName())[:60])
            req_headers={}
            for header in req.getHeaders()[1:250]:
                s = str(header)
                if ':' in s:
                    k,v=s.split(':',1)
                    k=k.lower().strip()
                    if k in ('origin','cookie','authorization'):
                        req_headers[k]=(v.strip()[:200] if k=='origin' else 'present')
            res_headers={}
            for header in resp.getHeaders()[1:250]:
                s=str(header)
                if ':' not in s:
                    continue
                k,v=s.split(':',1)
                k=k.lower().strip()
                if k in ('set-cookie','access-control-allow-origin','access-control-allow-credentials','cache-control','strict-transport-security'):
                    if k == 'set-cookie':
                        # Only need to know flags, not the actual cookie value.
                        old=res_headers.get(k, '')
                        v_lower=v.lower()
                        res_headers[k]=(old+';'+('session' if 'session' in v_lower else 'auth' if 'auth' in v_lower else 'cookie')+';'+('secure' if 'secure' in v_lower else '')+';'+('httponly' if 'httponly' in v_lower else ''))[:300]
                    else:
                        res_headers[k]=v.strip()[:200]
            status=int(resp.getStatusCode())
            body_start=resp.getBodyOffset()
            body_text=self.helpers.bytesToString(resp_bytes[body_start:body_start+65536]).lower()
            low_path=path.lower()
            flags={
                'git_exposure': status==200 and low_path.endswith('/.git/head') and 'ref: refs/heads/' in body_text,
                'env_exposure': status==200 and low_path.endswith('/.env') and ('app_key=' in body_text or 'db_password=' in body_text),
                'phpinfo': status==200 and 'php version' in body_text and 'phpinfo' in body_text,
                'apache_status': status==200 and 'serverversion:' in body_text and 'total accesses:' in body_text,
                'stack_trace': status==200 and ('traceback (most recent call last)' in body_text or 'stack trace:' in body_text),
                'cors_credential_origin_reflection': bool(req_headers.get('origin') and req_headers['origin']==res_headers.get('access-control-allow-origin') and res_headers.get('access-control-allow-credentials','').lower()=='true'),
                'cors_wildcard': res_headers.get('access-control-allow-origin')=='*',
                'cache_public_authenticated': bool(('cookie' in req_headers or 'authorization' in req_headers) and 'public' in res_headers.get('cache-control','').lower() and status==200),
                'cookie_missing_httponly': bool('session' in res_headers.get('set-cookie','') and 'httponly' not in res_headers.get('set-cookie','')),
                'cookie_missing_secure': bool('session' in res_headers.get('set-cookie','') and 'secure' not in res_headers.get('set-cookie','')),
                'missing_hsts': bool('strict-transport-security' not in res_headers),
            }
            event={'scheme':str(service.getProtocol()).lower(),'host':host,'port':int(service.getPort()),
                   'path':path,'method':method,'status':status,'flags':flags,
                   'parameter_names':names,'source':'burp-live'}
            try:
                self.queue.put_nowait(event)
            except Full:
                self.dropped += 1
                if self.dropped % 100 == 1:
                    self.callbacks.printError('AutoHunter: queue overflow; %s events dropped. Backfill from XML export.' % self.dropped)
        except Exception:
            # Passive analysis must never disrupt the user's browsing or testing.
            return
