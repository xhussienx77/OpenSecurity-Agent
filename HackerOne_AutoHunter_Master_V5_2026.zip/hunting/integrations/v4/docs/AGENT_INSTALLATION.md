# Loading the AutoHunter Skill in an AI coding agent

The SKILL.md file is an **instruction file**. It does not itself run commands. Your agent must have authorized terminal access to Python 3.10+ and the program scope configuration.

## Claude Code, Codex and compatible agent SKILL.md format

Copy the **entire** `hackerone-autohunter-v3` directory (not SKILL.md alone) to a project skills folder supported by your agent. For many Claude Code installations use `.claude/skills/hackerone-autohunter/`; for many Codex-style tools use `.agents/skills/hackerone-autohunter/`. Check your specific agent's current documentation before choosing a path.

Example agent request:

> Use the hackerone-autohunter skill. Start by reading the current program policy and my reviewed scope config. Run only the stages the policy permits. Validate each candidate with researcher-owned data and clearly separate hypotheses, observed signals, and independently confirmed findings. Draft reports in natural English without inventing evidence. Never submit automatically.

An agent can **orchestrate** CLI calls from the shell only when that shell is available to it. If shell is unavailable, it can inspect a supplied run summary and help with offline hypotheses / reporting, but must not claim it scanned the target.

## External tools

Strix, Nuclei, Katana, Subfinder, ffuf are **not** installed by this package. `python scripts/autohunter.py doctor` reports whether their binaries are visible, but does not install or run them. You must separately review their license, security, commands and the program's authorization, and control network access. When a program bans scanners, remain offline.
