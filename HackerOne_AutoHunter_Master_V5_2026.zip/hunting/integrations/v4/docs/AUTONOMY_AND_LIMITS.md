# Autonomous vs reviewed activities

| Stage | This package does automatically | Explicit approval / manual prerequisites |
| --- | --- | --- |
| Parse exact seed origins | Yes, offline | The user supplies a scope file; not a source of legal consent |
| Check allow/deny rules | Yes | The researcher transcribes and confirms the current HackerOne program policy |
| Basic HTTP exposure checks | Yes (7 GET requests per seed, broadly) | Automation permission and CLI policy confirmation |
| Same-origin micro-crawl | Optional; bounded | Additional `crawler_allowed` plus policy review, disabled by default |
| HAR and JS inventory | Yes, offline | Files exported by the user from their own account/session |
| Owned-account IDOR differential | Optional; two read-only GETs per case | Two researcher-owned accounts, synthetic resource, tokens in env vars, both flags and policy approval |
| Nuclei results | Offline import and host/path filtering | Scanner/template auditing and execution outside this package |
| Validation | Scoring and basic noise reduction | Human review of impact, false positives, duplicates, exclusions |
| HackerOne report draft | Yes, evidence-constrained Markdown | The researcher supplies true reproduction steps and verified impact |
| Submit to HackerOne | Never | Human action outside the package |

**No claims about real-world bounty yield:** 26 local tests assert software behavior, not security effectiveness on live targets. No program was contacted as part of package validation.
