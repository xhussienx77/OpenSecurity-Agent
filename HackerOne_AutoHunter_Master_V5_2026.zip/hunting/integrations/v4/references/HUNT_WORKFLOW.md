# H1 Evidence-First Hunting Method

## Operate in 5 modes

1. **Policy parser:** accept program policy link/text and compile a scoped, manually verified config. Ask only for information required to distinguish permission from speculation.
2. **Offline reconnaissance:** examine user-provided HAR, Burp, JavaScript, OpenAPI, URL inventory. Build a model of account roles, resources, ownership, and business workflows. Do not broadcast scans to discovered domains.
3. **Bounded scanner:** only after explicit automation permission, use `h1_hunter.py scan` on a single exact allowlisted origin; classify output as candidates.
4. **Hypothesis validation:** use two researcher-owned accounts for one selected IDOR/authorization test. Never enumerate third-party IDs or use third-party data. Treat a differential matching a synthetic private marker as strong evidence, but still verify privacy expectations.
5. **Report:** collect minimal reproducible steps, prove policy boundary, describe demonstrated impact without inflated severity, remove tokens/PII, check duplicates and exclusions, draft, then let user submit on HackerOne.

## Prioritization for credible findings

Focus on *features* rather than generic payload spraying:
- Multi-tenant apps: account A vs account B resource ownership; tenant switching; object and function-level authorization.
- APIs: same endpoint in distinct roles; object IDs used both on UI/API; REST/GraphQL field exposure; hidden but reachable actions.
- Workflows: invitations, organization roles, password reset edge cases, state transitions; use only synthetic own resources and non-destructive sequences.
- Exposures: configuration/debug pages with genuine sensitive content. Never download exposed repositories or extract keys to demonstrate impact.

For each hypothesis, record expected secure behavior, observer role, owned test data, exact minimal request, alternative explanations, what would falsify it, stop condition, likely reportability exclusion, and evidence.

## Evidence maturity

- **Lead**: observed endpoint/header or tool signature.
- **Candidate**: specific potential vulnerability flagged by tooling.
- **Strong signal**: a concrete reproduction with controlled researcher-owned accounts or a distinctive validated exposure marker.
- **Validated**: manual confirmation rules out benign behavior and establishes policy/authorization boundary violation.
- **Reportable**: validated, accepted scope/class, novel and demonstrably consequential under the program's rules.

Never automatically move a finding to **Validated** or **Reportable** because a scanner matched a template. Use exact response codes, screenshots or sanitized raw HTTP snippets only when provided by researcher. Never store credentials or other-user data.

## Avoid time sinks

Headers, version banners, 403 responses, CDN error pages, CORS reflection without authenticated data leakage, public content accessible by unauthenticated visitors, 200 soft-404 pages and speculative bugs with no actual impact are typically weak signals. Review program-specific exclusions.

## Hand-off template

`Program | exact asset | permission evidence | last reviewed | finding hypothesis | expected result | observations | what remains unverified | next lowest-risk test`.
