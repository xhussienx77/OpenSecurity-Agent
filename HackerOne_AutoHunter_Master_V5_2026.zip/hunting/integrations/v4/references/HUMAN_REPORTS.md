# Humanized HackerOne reporting, without invented evidence

The best reports are short, specific and reproducible. "Humanized" means readable, first-hand technical writing, **not** pretending an AI-generated claim was observed by a person.

## Required structure

1. **Title:** affected behavior + boundary; no emotional adjectives or bounty claims.
2. **Summary:** in 2–4 sentences, explain the tested account/resource/permission and observed effect.
3. **Preconditions:** environment, exact in-scope asset and researcher-owned test identities.
4. **Steps:** numbered, minimal and reproducible, with redacted headers and no secrets.
5. **Actual vs expected:** concrete comparison (e.g., unauthorized owned test account received a private synthetic marker).
6. **Impact:** only *demonstrated* impacts; no assumption of administrator compromise, data breach, monetary loss, or CVSS.
7. **Evidence:** status, sanitized request path/method, timestamp and synthetic markers. Avoid complete response bodies.
8. **Mitigation:** a practical authorization/control suggestion that does not overstate root cause.
9. **Limitations:** any incomplete reproduction, program exclusion, or uncertainty.

## Writing style

Use natural English, specific verbs and simple sentences. Avoid "critical vulnerability allowing attackers to compromise the entire system" without direct evidence. Avoid filler such as "Dear HackerOne Team". Prefer "When I requested a private test document from my second account, the endpoint responded with 200 and included the marker I had created in my first account" **only if this really happened**. Otherwise use "A scanner returned a candidate signal that still needs manual verification."

Do not state verified if the evidence was produced only by tool output without review. `review.json` requires an explicit researcher assertion and four substantive fields. This is an integrity boundary, not a cryptographic attestation of actual vulnerability. The human researcher remains accountable.

Do not automatically submit, contact program teams out-of-band, disclose private findings, or attach raw HAR files containing credentials.
