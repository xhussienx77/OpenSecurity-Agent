# HackerOne Program Authorization & Scope Gate

Use this reference before **any** active or authenticated testing. Scope is defined by the individual HackerOne program's current Security page, not by the fact that a website is publicly reachable. The HackerOne Disclosure Guidelines explicitly tell researchers to review individual program settings/policies first.

**Record:** program handle/policy URL; last reviewed date; in-scope and excluded hostname patterns; whether each asset is eligible for submission/bounty; any path restrictions; excluded finding classes; allowed automation/crawling/fuzzing, rate limits, hours; authorized account types and other constraints.

**Never infer:** that `*.example.com` includes `example.com`; that a domain in CT logs is eligible; that an API hosted by a third-party vendor is in scope; that a wildcard permits nonstandard ports, other protocols, login portals, redirects, payment providers or infrastructure owned by someone else.

**Human authorization gate:** This package's config starts with `policy_reviewed=false`, `authorization_confirmed=false`, `automation_allowed=false`, `authz_testing_allowed=false` and an empty host allowlist. Set these true only if actually supported by program policy and permission. The CLI's flags are additional attestations, not a substitute for policy.

**What the tool enforces:** exact hostname/explicit wildcard allowlisting; deny rules overriding allow rules; excluded path prefixes; HTTPS except localhost labs; no redirect-following; GET-only probes; <=2 requests/second; minimal evidence. This tool **cannot** infer every condition in written program policies; you must manually apply other restrictions. It does not automatically verify policy freshness.

**H1 structured scope:** The Hacker API's `GET /hackers/programs/{handle}/structured_scopes` can supply structured asset data for accounts with API access. Run `import-scopes` on exported JSON only to make a review queue. `eligible_for_submission` and `eligible_for_bounty` are different fields. Even an API-listed host may have policy instructions that restrict how it can be tested. Path-specific URLs, CIDRs, mobile apps and other complex assets are flagged for manual review instead of broadening scope.

**Stop conditions:** out-of-scope redirect, unexpected third-party sensitive content, real secrets, rate limiting / blocks, 5xx instability, evidence of customer harm, or unintended state-changing action. Do not chase a redirect beyond the origin. If sensitive information is inadvertently visible, stop; don't collect or publish it.

**Authoritative references** (checked November 2026):
- https://www.hackerone.com/terms/disclosure-guidelines
- https://api.hackerone.com/hacker-resources/
- https://docs.hackerone.com/en/articles/8475358-requesting-disclosure
