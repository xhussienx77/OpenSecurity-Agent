> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: XSS, CSRF, CORS, clickjacking, DOM, and postMessage

## Security properties and root causes

Client-side vulnerabilities occur when untrusted content executes in an unintended origin/context, a browser sends authenticated state-changing requests without an adequate anti-CSRF design, cross-origin permissions are broader than intended, or UI framing/message channels violate trust assumptions. Root causes include context-insensitive output handling, unsafe DOM sinks, missing CSRF defenses for cookie-authenticated mutations, overly broad CORS policies with credentials, weak frame protections, and postMessage handlers that trust origin or message shape.

## Where to look / indicators

- Search, comments, profile fields, markdown/rich text, file names, notification previews, admin dashboards, support tickets.
- Client-side reads from query/hash/referrer/storage/postMessage followed by HTML/script/URL sinks.
- Authenticated state-changing requests using cookies; actions with no CSRF token or origin validation.
- CORS reflecting arbitrary origins, wildcard plus credentials assumptions, or permissive subdomain regex.
- Sensitive pages that can be framed; clickjacking claims should identify an actionable sensitive UI.
- `postMessage` listeners that accept messages without strict origin and schema checks.

## Safe validation methodology

1. Verify scope and the program's policy on XSS/CSRF. Use a researcher-owned test account and non-sensitive page/data.
2. For XSS, identify input source, transformation, output context, and sink. Determine reflected/stored/DOM-based path. A string appearing in a response is not execution.
3. Use PortSwigger Academy or a local lab for executable proof. On production, use only a benign, non-persistent proof explicitly permitted by the program; avoid alert-only assumptions if program policy disallows it. Never target administrators or other users with payloads.
4. For CSRF, map cookie credentials and a state-changing action. Test only a harmless setting on a researcher-owned account, with no email/password/payment/security change. Check token, SameSite, Origin/Referer enforcement, and content-type behavior. Do not submit a request that affects another user.
5. For CORS, compare exact `Origin`, `Access-Control-Allow-Origin`, `Access-Control-Allow-Credentials`, `Vary`, and preflight behavior. Do not treat a permissive non-credentialed public API as sensitive data exposure.
6. For clickjacking, inspect frame protections and identify a meaningful action; do not induce a victim to click. Demonstrate only in a local proof page or browser dev setup.
7. For postMessage, inspect sender origin validation, target origin, message schema, and privileged effects. Use a local harness or lab; do not message another user's session.
8. Stop once the minimal behavior is established; avoid persistence, broad user exposure, or collecting browser data.

## Lab examples

Practice XSS, CSRF, CORS, clickjacking, DOM sinks, and postMessage labs in PortSwigger Academy. Use a local HTML harness for postMessage and framing experiments. Juice Shop can provide local frontend examples. Keep all proof pages on localhost.

## False positives

- Input is encoded for the correct output context and displayed as text.
- CSP blocks execution in the relevant context; still assess whether a genuine sink exists.
- Browser extension or proxy transforms output.
- CORS response is public and contains no credentialed sensitive data.
- Cookies use SameSite protections that prevent the claimed cross-site request in the tested browser.
- A page can be framed but no meaningful sensitive action exists.
- postMessage event data is validated later by a trusted handler.

## Impact

For XSS, identify whose browser/origin and what action/data is reachable; avoid assuming account takeover. For CSRF, show which state-changing operation can be triggered with the victim's ambient authority. For CORS, demonstrate access to a specific sensitive response using the researcher's own account and controlled origin only if expressly permitted. For clickjacking, show the sensitive UI/action at risk. For postMessage, state how untrusted origin/message crosses into a privileged action.

## Evidence / remediation

Record source → sink trace, sanitized request/response, browser context, origin, cookie behavior, and exact harmless effect. Remediate with context-aware output encoding, safe DOM APIs, strict sanitization for rich text, CSRF tokens plus origin validation and appropriate SameSite cookies, exact CORS allowlists with `Vary: Origin`, anti-framing policy, and strict postMessage origin/schema validation.

## Common mistakes

Calling reflected HTML XSS without execution; testing other users or administrators; confusing CORS with server-side authorization; reporting wildcard ACAO on a public endpoint as data theft; and treating `X-Frame-Options` absence alone as impact.
