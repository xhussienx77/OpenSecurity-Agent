> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: SQL, NoSQL, command, template, LDAP, XPath injection

## Security property and root causes

Untrusted input must remain data rather than altering the syntax or semantics of a query, command, expression, directory filter, or template. Root causes include unsafe string concatenation, dynamic query construction, overly powerful expression evaluators, shell invocation with user input, and missing context-aware encoding or allowlisting.

## Where to look / indicators

- Search, filter, sort, report, login, product, admin, export, import, and analytics inputs.
- Numeric/string IDs, JSON filters, query operators, sort field/direction, file conversion, preview, template customization, directory lookup.
- Server errors or behavior changes tied to metacharacters, types, quote balancing, or unexpected expression handling.
- Source code showing dynamic SQL, shell commands, LDAP filters, XPath, template compilation, or user-controlled object keys.

## Safe methodology

1. Check program rules for injection testing and callbacks. Production testing must not run arbitrary commands, read files, access secrets, or cause delays/load.
2. Start with normal input baseline. Change one syntactic feature at a time using harmless values and compare response structure. Avoid destructive statements, stacked queries, file reads, shell metacharacter execution, or time-delay payloads on production.
3. Prefer source review or a deliberately vulnerable lab to establish the mechanism. In production, use only non-invasive confirmation techniques explicitly allowed by the program.
4. For SQL/NoSQL, determine whether the input reaches a query and whether query structure changes; an error string alone is not enough. Do not enumerate database contents.
5. For command injection, do not attempt OS commands on a production target. Use code review or a lab; if a program provides a harmless canary mechanism, use only the one it documents.
6. For template injection, a reflected string may be plain text. In a lab, confirm server-side evaluation with a harmless arithmetic expression and establish template context. Never attempt file/system access in production.
7. For LDAP/XPath, use controlled lab examples and safe syntactic comparisons; don't enumerate directory entries or access user records.
8. Stop if output reveals records, secrets, host paths, environment data, or unexpected side effects; redact and report minimal evidence.

## Lab environments

Use PortSwigger SQLi and server-side template injection labs, OWASP WebGoat, or Juice Shop local containers. For command/LDAP/XPath practice, use a dedicated intentionally vulnerable lab with synthetic data. Keep local services bound to loopback.

## False positives

- Generic 500 from malformed input rather than injection.
- WAF or proxy error page.
- Client-side validation or reflected text without evaluation.
- Database error text that leaks technology but not query control.
- Timing noise, caching, load, or rate limiting.
- A filter language is intentionally exposed and safely constrained.

## Impact

Assess whether an attacker can alter query logic, bypass login, access or modify data, execute code, or influence a directory/template operation. State required privileges and affected data/action. Do not claim RCE from a parser error or theoretical sink.

## Evidence / remediation

Use exact input, sanitized request/response, baseline comparison, source line if available, and a bounded lab reproduction. Remediation: parameterized queries; safe query builders; allowlisted fields/operators; avoid shell invocation or use argument arrays and fixed executable paths; context-specific template escaping; constrained expression evaluation; safe LDAP filter encoding; and least-privilege service accounts.

## Common mistakes

Running payload lists blindly; using destructive/time-based payloads on production; confusing syntax errors with exploitable injection; overclaiming database or operating-system access; and not proving the input reaches the sensitive interpreter.
