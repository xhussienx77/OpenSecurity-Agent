> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: JWT, OAuth, cache, takeover, WebSockets, prototype pollution, supply chain

This playbook groups modern application patterns that may overlap other playbooks. Select the narrowest specific method and keep scope boundaries intact.

## JWT

**Mechanism/root causes:** token validation can fail when signature, algorithm, issuer, audience, expiry, not-before, key selection, or token type are handled inconsistently. Applications may also accept tokens intended for another service or trust unverified claims.

**Look for:** JWT-shaped bearer tokens, multiple token issuers, mobile/browser differences, refresh flows, key rotation, role/tenant claims, and services validating the same token independently.

**Safe method:** inspect decoded claims without exposing token values; use researcher-owned accounts; compare the app's expected issuer/audience and expiration behavior. Never change claims or forge/sign tokens against production unless the program explicitly authorizes a harmless test and supplies a safe fixture. Use PortSwigger JWT labs for algorithm/key-confusion learning. Don't paste live tokens into external AI tools.

**False positives:** opaque token mistaken for JWT; unsigned sample only used in a lab; claim is informational and separately checked server-side; token intentionally audience-shared among a documented service group.

**Impact/evidence:** identify the exact validation failure and one controlled authorization consequence. Preserve token metadata and redacted request/response, not the token itself. Use maintained libraries and validate signature algorithm, issuer, audience, expiry, token type, and key provenance.

## OAuth / OpenID Connect

Use `AUTHENTICATION.md` as the main procedure. Check exact redirect URI matching, `state`, PKCE, nonce, issuer, audience, authorization-code binding, client type, account linking, and logout/token revocation. Follow RFC 9700 and current provider docs. Only use identity-provider accounts controlled by the researcher and registered test clients. Never redirect codes/tokens to an uncontrolled domain or test against other users.

## Web cache vulnerabilities

**Mechanism:** cache keys may omit a request dimension that changes the response, or normalization may make an attacker-controlled path appear static. Cache poisoning and cache deception are different behaviors. Review cache key, `Vary`, cache status headers, path normalization, cookies, and authorization handling.

**Safe method:** use an isolated test path and synthetic content owned by the researcher; avoid poisoning shared caches or affecting another user's response. Do not test sensitive pages in production. A cache header or reflected parameter alone is not proof. Use PortSwigger cache labs for controlled demonstrations.

**Impact/remediation:** show whether another cache consumer could receive attacker-influenced or private content, without actually exposing another user's content. Ensure sensitive responses are private/no-store, cache keys include relevant dimensions, and proxies normalize paths consistently.

## Subdomain takeover assessment

**Mechanism:** a DNS record may point to an unclaimed external service. A dangling CNAME is a lead, not proof of claimability or authorization to claim it.

**Safe method:** compare DNS and provider response with current vendor documentation; verify hostname is explicitly in program scope. Do not create accounts, claim resources, upload content, or alter DNS. Do not demonstrate takeover by taking control. Capture DNS chain and a non-invasive provider error page only. Notify the program with the exact hostname and evidence.

**False positives:** provider intentionally returns an unconfigured response; resource is reserved; service requires ownership proof; CNAME target is shared/managed; DNS record is retired but not claimable.

**Remediation:** remove stale DNS records, reserve resources, monitor dangling records, and apply provider-specific ownership controls.

## WebSocket security

Map handshake authentication separately from message-level authorization. For every message type, identify channel/room/object, caller identity, and permitted action. Use two researcher-owned accounts and synthetic rooms only. Do not join another user's private room or replay sensitive messages. Check origin validation as an additional control, not a substitute for authorization. Use local labs for cross-site WebSocket hijacking concepts.

## Prototype pollution

**Mechanism:** attacker-controlled object keys (such as prototype-sensitive names) modify object prototypes and may influence later security-sensitive logic. Many apparent pollution indicators do not produce an exploitable sink.

**Where:** deep merge utilities, query parsers, JSON config merges, object assignment, dependency versions, client-side state and server deserialization.

**Safe method:** review source/dependency versions and use a local lab. In production, do not attempt to alter global runtime state or trigger privileged behavior. A harmless controlled marker may be used only where allowed and does not itself prove security impact. Trace source → merge → polluted property → security-sensitive sink.

**False positives:** own-property data rather than prototype mutation; patched library; pollution isolated to a local object; no reachable security-sensitive sink; scanner signature false positive.

**Remediation:** safe merge functions, reject dangerous keys, use null-prototype objects/Maps, update dependencies, and avoid trusting inherited properties.

## PostMessage and client-side trust

Use `CLIENT_SIDE.md`. Check exact `event.origin`, message schema, sender trust, target origin, and whether message actions cross a privileged boundary. Don't assume same-site is same-origin; don't treat a wildcard target as automatically exploitable without a sensitive receiver.

## Supply-chain exposure

**Where:** frontend package manifests/lockfiles, third-party scripts, build pipelines, GitHub Actions, package publishing, dependency confusion surfaces, outdated vulnerable libraries, and leaked CI artifacts.

**Safe method:** review public manifests and version metadata; use trusted advisories and package metadata; do not publish packages, squat names, poison caches, access secrets, or test build credentials. Confirm the vulnerable code path is actually reachable and affected version/configuration is present. Keep dependency scanners in advisory mode unless scanning a codebase you own.

**False positives:** version range not affected; vulnerable function unused; patched fork/backport; build-only dependency; advisory does not match runtime configuration.

**Impact/remediation:** describe the affected dependency, vulnerable path, reachable usage, and realistic consequence. Recommend upgrade to fixed version, lockfile pinning, provenance/signature verification, least-privilege CI tokens, protected branches, and dependency review.

## Common mistakes across this category

- Treating a decoded JWT claim as an authorization decision.
- Claiming takeover by registering or modifying a resource.
- Poisoning a shared cache to prove a theoretical issue.
- Confusing a vulnerable dependency version with exploitable application behavior.
- Stopping analysis at a prototype pollution source without a sink.
- Testing a private WebSocket room belonging to someone else.
