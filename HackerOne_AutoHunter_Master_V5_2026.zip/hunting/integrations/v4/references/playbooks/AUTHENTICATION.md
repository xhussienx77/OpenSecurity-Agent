> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: authentication, sessions, recovery, MFA, OAuth

## Security property and root causes

Authentication establishes an identity; session management preserves that identity safely; authorization decides what it may do. Failures arise from weak credential lifecycle, token confusion, missing server-side state validation, insecure reset/invitation flows, inconsistent MFA enforcement, insecure OAuth client configuration, or session invalidation gaps.

## Where to look / indicators

- Login, logout, registration, invitation, account linking, password reset/change, email/phone verification, MFA enrollment/recovery, remember-me, refresh-token, SSO, OAuth callback.
- Differences between browser, mobile, API, and legacy endpoints.
- Session cookies, token audience/issuer/expiry, refresh behavior, session rotation, device/session lists.
- Recovery links with state, expiry, single-use, binding to intended account, or email-change flows.
- OAuth `redirect_uri`, `state`, PKCE, nonce, client type, authorization-code exchange, account-linking behavior.

## Controlled methodology

1. Read program rules; do not conduct password spraying, credential stuffing, brute force, social engineering, or send messages to users. Use only researcher-owned accounts and approved test email/phone addresses.
2. Map the normal login and logout sequence. Record cookie attributes (Secure, HttpOnly, SameSite, Path, Domain) and token claims without copying secret values.
3. Test lifecycle with one controlled session: login, privilege change if safely available, password change, logout, and session revocation. Observe whether old sessions remain valid only where this behavior can be tested without harming a real account.
4. For reset, use a researcher-owned account; request one reset and inspect whether token is bound to the account, expires, is single-use, and becomes invalid after password reset. Do not inspect another person's mailbox or reset flow.
5. For MFA, use an enrolled researcher-controlled account and recovery codes generated for that account. Check whether sensitive actions consistently require the intended factor. Do not attempt bypasses against other users or automate guesses.
6. For OAuth, use an application and identity-provider account you control. Map actors, redirect URI registration, `state`, PKCE, nonce (OIDC), issuer, audience, and account-linking confirmation. Do not redirect authorization responses to domains you do not control.
7. Stop on unexpected account access, token exposure, or delivery to an unintended recipient. Preserve minimal redacted evidence.

## Lab examples

Practice password reset, MFA, OAuth, JWT/session, and authentication labs in PortSwigger Academy. Use WebGoat/Juice Shop locally for session and auth concepts. In labs, demonstrate why reset tokens should be single-use and why exact redirect URI validation matters.

## False positives

- Session remains valid by explicit product policy with documented token lifetime.
- Remember-me cookie is a separate scoped session.
- A reset email is delayed or cached; request IDs can correlate events.
- OAuth redirect URI belongs to an approved registered subdomain or native app scheme.
- MFA is step-up enforced only for sensitive actions by design.
- Token is an opaque identifier; apparent JWT text may be a decoy or invalid sample.

## Impact

Describe whether the issue permits authentication as another account, session persistence after revocation, recovery takeover, MFA downgrade, or OAuth account misbinding. Do not claim account takeover from a reflected reset token or weak cookie flags alone. Demonstrate only with the researcher's accounts.

## Evidence / remediation

Keep sanitized flow diagram, exact account labels, token metadata (not raw tokens), request/response pairs, expiry/single-use observations, and expected behavior. Remediation may include maintained protocol libraries, exact redirect URI matching, PKCE for public clients, `state`/nonce validation, secure token audience/issuer validation, rotation/revocation, single-use short-lived reset tokens, uniform MFA policy, and secure recovery controls. Consult current OAuth BCP RFC 9700 and JWT BCP RFC 8725.

## Common mistakes

Sharing live tokens with AI; testing reset for someone else; assuming JWT signature algorithm changes are exploitable without validating the verifier; ignoring session invalidation; and calling a missing cookie attribute account takeover without a demonstrated attack path.
