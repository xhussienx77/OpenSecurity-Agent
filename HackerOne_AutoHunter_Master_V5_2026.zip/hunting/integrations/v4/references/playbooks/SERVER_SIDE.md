> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: SSRF, XXE, traversal, uploads, deserialization, smuggling, cache

## Security properties and root causes

Server-side flaws arise when untrusted input controls a server resource access, parser, filesystem path, object deserializer, HTTP message boundary, host routing, or shared cache key. These classes can be high impact; production validation must be tightly bounded and program-approved.

## Where to look / indicators

- URL fetchers, webhooks, importers, previews, PDF/image converters, avatar fetch, link unfurling, integrations.
- XML upload or SOAP endpoints, file parsers, archive extraction, document conversion.
- Download/export paths, user filenames, archive extraction, template/static file handlers.
- Serialized cookies, signed objects, framework-specific data blobs, message queues.
- Reverse proxies and gateways with ambiguous request framing, multiple `Content-Length`/`Transfer-Encoding` interpretations, or HTTP/2 translation.
- Cacheable dynamic responses, user-specific content, unkeyed headers/query parameters, alternate path normalization.
- Host/forwarded-host usage in password reset links, absolute URLs, tenant routing, and redirects.

## Safe validation methodology by class

### SSRF

Map the feature and server-side fetch expectation. Review code or use a local lab. In production, do not probe loopback, RFC1918, link-local, cloud metadata, control planes, internal DNS, or third-party callbacks. Use only a program-provided safe callback endpoint or explicitly sanctioned fixture and a single harmless request. A URL echoed or stored is not SSRF; evidence must show a server-side network interaction.

### XXE

Prefer source review and labs. Do not attempt local file reads, external entity exfiltration, or internal network fetches in production. Confirm parser configuration and whether external entity resolution is enabled with a harmless local fixture where possible.

### Path traversal

Use synthetic files and harmless path normalization checks in a lab. Do not read `/etc/passwd`, source code, secrets, or files outside researcher-owned test fixtures on production. Distinguish path normalization behavior from an actual protected-file access.

### File upload

Use a researcher-owned account and harmless inert file. Check extension/content validation, storage location, download authorization, content disposition/type, and whether the uploaded object executes or is served from a trusted origin. Never upload shells, malware, polyglots designed to execute, or oversized files. Do not overwrite another user's file.

### Insecure deserialization

Review the code path and serializer trust boundary. Do not execute gadget chains or attempt code execution on production. Use local labs to understand gadget behavior; prove only whether attacker-controlled serialized input is accepted and interpreted, not RCE absent safe evidence.

### Request smuggling

Production request smuggling testing can desynchronize shared infrastructure and affect other users. Do not send ambiguous framing or timing payloads to production unless the program explicitly provides a dedicated safe test origin and methodology. Prefer a local proxy/backend lab. No tests that could poison shared connections.

### Host header / cache poisoning / cache deception

Use only researcher-owned content and a dedicated test path. Do not poison shared caches or affect other users. Review how the application constructs links and cache keys. A reflected Host value is not necessarily exploitable. Distinguish cache deception (unkeyed path confusion/static extension) from poisoning (attacker-controlled input influences a shared cached response).

## Lab examples

Use PortSwigger Academy labs for SSRF, XXE, path traversal, upload, deserialization, request smuggling, and web cache attacks. Recreate proxy/backend behavior in isolated containers for smuggling. Never apply lab payloads blindly to production.

## False positives

- URL validation occurs but fetch is never executed.
- Egress proxy rejects destination; a DNS lookup alone may not establish HTTP SSRF.
- XML parser disables external entity resolution.
- Path traversal characters are normalized safely or blocked before file access.
- Uploaded files are inert and served from isolated storage with safe headers.
- Cache is private/no-store or key includes all security-relevant dimensions.
- Host header is used only in a harmless display context.
- A scanner's smuggling signal is timing noise, proxy behavior, or unsupported HTTP version.

## Impact and evidence

Describe exact server-side boundary and one safe observed effect. Do not claim internal network access, secret theft, RCE, cross-user cache poisoning, or production desynchronization without evidence that can be collected safely. Record the request, response, test fixture, server-side callback proof if approved, cache headers, account ownership, and cleanup.

## Remediation

SSRF: destination allowlists, safe DNS resolution and revalidation at connection time, redirect controls, egress filtering. XXE: disable external entities/DTD and use hardened parsers. Traversal: canonicalize and enforce root directory, generated names. Upload: validate content, store out of web root, random names, safe serving. Deserialization: avoid native unsafe formats, use signed/allowlisted schemas. Smuggling: consistent proxy/backend parsing and protocol normalization. Cache: complete cache keys, private/no-store for sensitive content, normalize paths consistently, strip untrusted forwarding headers.

## Common mistakes

Testing internal IPs on production; reading secrets; sending smuggling payloads through shared frontends; uploading active content; confusing a reflected URL with SSRF; and assuming a cache header alone proves cache poisoning.
