> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: access control, IDOR/BOLA, privilege, and tenancy

## Security property and root causes

A principal may perform only the actions permitted for the specific object, tenant, role, and workflow context. IDOR/BOLA occurs when a server uses a client-controlled object reference without enforcing the caller's authority over that object. Broken function-level authorization (BFLA) exposes an action to a principal who should not have it. Horizontal privilege escalation crosses between peers; vertical escalation reaches a more privileged role. Multi-tenant failures cross an organization boundary.

Typical root causes: checking that a user is logged in but not that they own the object; relying on hidden UI controls; trusting `user_id`, `tenant_id`, `role`, or object IDs from the client; missing authorization on export/bulk/mobile/API routes; inconsistent checks among GET/POST/PATCH/DELETE; unsafe nested-resource lookup; stale role cache; or trusting an invitation/relationship without checking its state.

## Where to look / indicators

- Object IDs in URLs, JSON bodies, GraphQL variables, filenames, export IDs, invoice/report/document IDs.
- Profile, team/member, organization, project, ticket, file, message, billing, audit, and admin features.
- Endpoints that accept owner/tenant/role/status/approval fields.
- Bulk operations, search filters, exports, alternate API versions, mobile routes, and background jobs.
- UI shows one user's data while API returns object references; client hides buttons based on role.
- Similar responses from two controlled accounts with different ownership or roles.

## Controlled methodology

1. Confirm exact endpoint and authenticated testing are in scope. Create two accounts and resources only if permitted; keep them under the researcher's control. Ideally same plan and role, different ownership/tenant.
2. Record a baseline request from Account A to an object A created. Record a baseline request from Account B to an object B created.
3. Form one hypothesis, e.g. B may read A's synthetic invoice because server lookup is by ID only.
4. Change exactly one variable: keep B's authentication and replace only object reference with A's synthetic object ID. Do not enumerate IDs.
5. Observe actual data/operation, not just status code. Verify ownership independently from account A's normal view.
6. Stop immediately after the minimum cross-boundary result. Do not fetch more objects or attempt writes unless separately authorized and necessary to prove impact.
7. For vertical checks, compare a low-privilege researcher-owned account against a permitted test admin/role account. Never promote the account or modify real role assignments unless program supplies a safe fixture.
8. For property-level authorization, compare a single benign field in a test-owned object. Avoid changing account email, password, MFA, payout, or role in production.

## Safe lab examples

Use PortSwigger Academy access-control labs or a local Juice Shop environment. In a lab, create two users and one synthetic record per user; compare owner-scoped reads. Do not translate numeric ID patterns or lab-only bypass tricks into production without scope review and a safe test plan.

## False positives

- Object intentionally public or shared.
- Accounts belong to the same tenant or shared test organization.
- Resource is a demo fixture, public catalog item, or shared support ticket.
- Cached response is not account-specific; verify cache behavior only with permitted, synthetic data and no cache poisoning attempt.
- Endpoint returns a generic envelope/error rather than protected data.
- UI role difference is intended or a test account has an unexpected role.
- Data in the body is stale client-side cache rather than fresh server access.

## Impact assessment

State whose object/action boundary is crossed, what fields/action are accessible, required account privileges, tenant boundaries, and realistic consequence. Distinguish read vs write vs delete vs privileged function. One synthetic invoice proves a bounded access-control weakness; it does not prove all invoices or account takeover.

## Evidence and report

Capture sanitized Account A/B identities (labels only), object creation/ownership proof, one baseline per account, one cross-account request/response, timestamp/request IDs, expected vs actual result, and stop point. Do not include other-user data. Recommended remediation: server-side authorization in the data access path, principal-derived tenant/owner filters, deny-by-default action checks, DTO allowlists, and regression tests for each role/object/action combination.

## Common mistakes

Testing other people's IDs; brute-forcing identifiers; relying on status codes; changing multiple variables; treating UI hiding as server-side protection; assuming a UUID is authorization; claiming vertical escalation without a privileged action; and continuing after minimum proof.
