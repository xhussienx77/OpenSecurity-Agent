> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: information disclosure, debug surfaces, storage, and secrets

## Security property and root causes

Sensitive data should be accessible only to authorized principals and only in the amount and context required. Disclosure issues commonly arise from verbose errors, debug endpoints, public object storage, source maps, backups, exposed credentials, logs, misconfigured access policies, and stale API or documentation artifacts.

## Where to look / indicators

- Error pages, stack traces, debug routes, health/metrics endpoints, API docs, admin diagnostics.
- Source maps and bundled assets, build manifests, backup/archive names, old deployments, config files.
- Cloud storage links, static buckets, object versioning, directory listing, public export files.
- Tokens/keys/password-like strings in public source repositories or frontend bundles.
- Error messages that include file paths, internal hostnames, SQL fragments, or environment details.

## Safe methodology

1. Confirm scope and policy for information disclosure. Never access a discovered secret, authenticate with it, test it against another service, or browse unrelated storage contents.
2. Use public, in-scope artifacts and researcher-owned data. For a suspected secret, capture only the smallest redacted fingerprint and location; do not reveal value in chat/report.
3. For cloud storage, request only the exact object or listing already documented as in scope and necessary to prove public access. Do not enumerate bucket contents or download customer data. If an object appears personal/sensitive, stop and report location without opening it further.
4. For debug endpoints, use minimal non-sensitive route/metadata checks; do not invoke actions or access environment dumps.
5. For source maps, determine whether they are publicly served and whether they contain source code beyond intended client code. Source code exposure alone may be informational; assess secrets and sensitive business logic separately without attempting to use them.
6. For backup files, do not download full databases, archives, or configuration bundles. Report exposed location and a small safe header/metadata proof if policy permits.
7. For credentials already exposed, do not validate them by logging in. Notify through program channel and redact.

## False positives

- Key is a public client identifier intended for browser use and restricted by origin/referrer or API scope.
- Source map contains ordinary client-side source but no secret or privileged material.
- Debug route exposes only non-sensitive health status.
- Cloud object is intentionally public product media.
- Error detail is visible only to an authenticated administrator by design.
- Secret-like string is test fixture, fake sample, revoked credential, or non-secret identifier.

## Impact

Separate information type, sensitivity, access condition, freshness, and realistic use. Do not claim account compromise based on an unvalidated token-looking string. Never test leaked credentials. Report access control to the resource and the minimum exposed metadata without copying sensitive records.

## Evidence and remediation

Record exact in-scope URL/path, access context, response headers, redacted snippet or object metadata, timestamp, and the stopping point. Recommend least-privilege storage policies, private-by-default buckets, secret rotation by the owner, removal of debug artifacts, safe error handling, access logging, and build pipeline controls preventing secrets in frontend/source-map output.

## Common mistakes

Downloading everything to prove a leak; using exposed credentials; exposing PII in a report; declaring a public API key a secret without understanding its client-side purpose; and overstating a stack trace as critical data exposure.
