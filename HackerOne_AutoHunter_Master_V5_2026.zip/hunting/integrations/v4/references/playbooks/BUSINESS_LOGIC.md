> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: business logic, workflows, race conditions, and transactions

## Security property and root causes

Business logic vulnerabilities violate a product invariant even when every individual input appears syntactically valid. Examples include changing workflow order, replaying one-time actions, exceeding intended entitlements, inconsistent price/quantity validation, stale state, or non-atomic concurrent operations. Root causes include trusting the client to enforce sequence, duplicated validation, missing server-side invariants, weak idempotency, and race-prone read/modify/write logic.

## Where to look / indicators

- Signup/invitation/verification, checkout, subscription, billing sandbox, coupon/discount, cart, refunds, payouts, approvals, publishing, file import/export, account linking, seat/role changes.
- Multi-step workflows with hidden UI buttons or state names in JSON.
- Repeated requests, stale browser tabs, retry behavior, duplicate webhooks, idempotency keys.
- Quantity, price, currency, status, owner, plan, entitlement, approval, or timestamp fields.
- Differences between UI and API validation; one workflow path enforcing checks while another skips them.

## Methodology

1. Confirm written permission for the exact business workflow. If it involves payments, refunds, payouts, real entitlements, customer emails, or irreversible changes, request a dedicated sandbox/test fixture. Do not use real financial instruments or affect live customer state.
2. Draw the intended state machine: states, allowed transitions, actor, preconditions, side effects, and invariants. Ground this in UI/docs or mark it as an assumption.
3. Use researcher-owned synthetic accounts and objects. Establish the normal sequence once.
4. Form a precise hypothesis: e.g. “The server accepts the `approved` transition from a draft state for a normal user, bypassing the required reviewer role.”
5. Test a single transition or field with a harmless state. Avoid attempts to obtain free real goods/services or transfer real value.
6. For duplicate/replay behavior, use only a sandbox or non-financial operation with reversible researcher-owned data; check idempotency and state consistency with a minimal repeat.
7. Race conditions can create load or duplicate side effects. Do not run concurrent production requests by default. Use a local lab or explicitly provided sandbox race-testing window with very low bounded concurrency and approved test data.
8. Stop immediately if a real transaction, message to another user, entitlement, or irreversible action occurs unexpectedly. Do not attempt cleanup that could create more impact; follow program instructions.

## Useful analytical models

- **State transition table:** current state × actor × action → expected next state / side effects.
- **Invariant list:** e.g. total charged equals server-calculated price × quantity; a one-time token is consumed once; only reviewer role can approve; refund total cannot exceed captured amount.
- **Trust boundary:** which values originate from the client vs server-calculated source of truth.
- **Idempotency:** what happens when the same authorized operation is retried; does it create duplicate side effects?
- **Atomicity:** are validation and state update committed together, or can another request interleave?

## Lab examples

Use PortSwigger business logic and race-condition labs. Build a toy local checkout with fake credits and an in-memory state machine to understand replay, stale state, and concurrent updates. Keep all value fictional and local.

## False positives

- Workflow intentionally permits the tested transition for the account's role.
- Sandbox shows delayed consistency or asynchronous processing.
- UI hides an action but API has a documented alternate route for that user.
- Duplicate requests are deduplicated server-side even if the UI displays retries.
- Coupon or discount rules permit stacking by product design.
- Race symptom is network retry, cache, or client rendering rather than duplicate state change.

## Impact

Describe exactly which invariant was broken, what state/entitlement changed, which actor can trigger it, and what remains untested. Never extrapolate a test-coupon effect to real monetary loss or a local race to production scale. Provide a clear statement if only a test/sandbox value was involved.

## Evidence and remediation

Document initial state, account/role, single action/request, resulting state, expected state, and any idempotency/concurrency context. Remediation: server-side state machine, atomic transaction/constraint, idempotency keys, server-calculated prices and entitlements, centralized validation, authorization at each transition, and regression tests including retries and concurrency where safe.

## Common mistakes

Testing live payments; assuming hidden UI controls enforce policy; using high-concurrency race scripts against production; confusing delayed consistency with a race; and claiming business impact without demonstrating the relevant invariant in a sandbox.
