> Adapted from researcher-provided skill material. Program-specific restrictions in `../HACKERONE_POLICY.md` always override any example below.

# Playbook: REST, GraphQL, WebSocket, and API authorization

## Security properties

An API must authenticate the caller, authorize each function and object, expose only intended properties, validate state transitions, rate-limit resource-intensive actions according to risk, and maintain a correct inventory of live API versions. OWASP API Security Top 10 2023 categories include BOLA, broken authentication, property-level authorization, unrestricted resource consumption, BFLA, sensitive business flows, SSRF, security misconfiguration, improper inventory management, and unsafe consumption of APIs.

## Where to look / indicators

- OpenAPI/Swagger docs, GraphQL schemas/introspection (only where allowed), JS route definitions, mobile traffic, versioned paths, legacy API hosts.
- JSON fields such as `userId`, `ownerId`, `tenantId`, `role`, `permissions`, `price`, `status`, `isAdmin`, `approved`, `plan`, and nested object IDs.
- Bulk endpoints, batch operations, export/report routes, search/filter/sort, file references, webhook/integration endpoints.
- GraphQL resolvers, aliases, nested object traversal, mutations, subscription channels.
- WebSocket handshake cookies/tokens, message action names, channel/room IDs, and per-message authorization.

## Methodology

1. Confirm API host, versions, authentication method, and allowed automation. Keep external dependencies separate from program-owned API hosts.
2. Build an endpoint inventory from official docs, observed app traffic, and permitted JS analysis. Record method, path, parameters, auth requirement, object/tenant boundary, and side effects.
3. Establish baseline requests using researcher-owned accounts. Redact tokens.
4. Apply the relevant playbook: access control for BOLA/BFLA; authentication for tokens; business logic for workflow transitions; injection for query interpreters.
5. For property authorization/mass assignment, compare an allowlisted benign field against a non-privileged field in a synthetic object. Never alter role, payout, price, or account-security fields in production.
6. For rate limits/resource consumption, do not load-test or brute-force. Only test a program-defined low-volume limit with permission and stop at the first clear control gap. Report the risk without exhausting service resources.
7. For GraphQL, map query/mutation fields and resolver-level authorization. Do not run deep/broad introspection or expensive nested queries unless explicitly allowed. Keep aliases/batches small; avoid resource exhaustion.
8. For WebSockets, use controlled accounts and a test-owned room/channel. Compare per-message authorization after an authenticated connection. Never join another user's private channel.
9. Check deprecated/legacy versions passively; do not probe outside the exact approved API scope.

## BOLA vs BFLA vs property-level authorization

- **BOLA:** caller accesses another principal's object by changing a reference.
- **BFLA:** caller invokes a function/action reserved for another role.
- **Broken object property-level authorization:** caller reads or changes properties they should not see or modify, including mass assignment or excessive data exposure.

Keep the claim narrowly aligned to the proof. A hidden field in an API response may be intentional metadata; show why it is confidential. A client-supplied role is only a lead until a server-side privilege boundary changes.

## Lab practice

Use PortSwigger API testing and GraphQL labs; OWASP crAPI (where installed separately) and Juice Shop can provide local API examples. Use synthetic accounts and localhost-bound services. Don't infer production behavior from lab schemas.

## False positives

- Fields are public by design or necessary for UI behavior.
- API gateway returns cached or normalized response unrelated to current identity.
- Two accounts share a tenant/role.
- GraphQL field is deprecated but not reachable or not in scope.
- A WebSocket message is broadcast to a public channel.
- Rate limit exists at gateway even if not visible in one endpoint response.
- API's error envelope returns 200 with an application-level denial.

## Impact and evidence

For each finding, include exact API version, operation, caller role, synthetic object owner, minimal request/response, and expected/actual behavior. Explain the affected data/action and realistic consequence. Avoid broad “all APIs are vulnerable” conclusions from one resolver or endpoint.

## Remediation

Use centralized authentication and object/function/property authorization, principal-derived tenant filters, explicit input/output schemas, resolver-level checks, per-message WebSocket authorization, cost-aware GraphQL limits, endpoint lifecycle/inventory management, safe API consumption, and resource controls tailored to business impact.

## Common mistakes

Treating all 200 responses as success; assuming OpenAPI spec equals runtime behavior; running expensive GraphQL queries; mass assignment against privileged production fields; fuzzing every API path; and overlooking alternate routes that share the same backend authorization function.
