# GitHub research and command cookbook — November 7, 2026

**Design notes, not a fork:** The scripts in this package are original stdlib Python combined with the user-provided V2 skill. External repositories are **not cloned/bundled**, and no incompatible third-party source is copied. Live GitHub pages may change: review flags and licenses at usage time.

| Project | Official source | Idea incorporated / reason |
| --- | --- | --- |
| Strix | https://github.com/usestrix/strix | Evidence-driven validation and specialist skill selection. Unlike Strix, this bundle does not ship an LLM/docker agent or dynamic exploits. |
| H-mmer/pentest-agents | https://github.com/H-mmer/pentest-agents | Seven-question confidence gate, workflow state and concise hypothesis log. No agent code copied. |
| PentestAgent | https://github.com/GH05TCREW/pentestagent | Playbook/task separation, persistent notes, natural human reporting. |
| reconFTW | https://github.com/six2dez/reconftw | Incremental stages, checkpoint/resume, explicit scope and circuit-breaker ideas. |
| Nuclei | https://github.com/projectdiscovery/nuclei | Signature checks and JSONL result format; imports untrusted matches offline only. |
| Katana | https://github.com/projectdiscovery/katana | Scope-conscious endpoint inventory; built-in micro-crawler is intentionally smaller/stricter. |
| Subfinder | https://github.com/projectdiscovery/subfinder | Passive-only domain candidates; passive discoveries are not active scanning authorization. |
| ffuf | https://github.com/ffuf/ffuf | Wordlist fuzzing considered but not bundled or default-enabled, because many programs prohibit aggressive enumeration. |

## Tool command patterns (human-reviewed; never blanket-apply)

**Passive candidate enumeration only** for a scope-approved root domain, when querying third-party passive sources is allowed. Output must be manually filtered against precise eligible assets before any active test:

```bash
subfinder -d example.com -silent -max-time 1 -o passive-candidates.txt
```

**Limited single-origin crawl** only when the program explicitly permits crawling, and when paths excluded by policy can be effectively blocked with appropriate filters. Katana's default registered-domain scope is **too broad** for an exact-origin allowlist, so use `-fs fqdn` and do not default to this when path exclusions exist. Take special care with GET endpoints that cause state changes.

```bash
katana -u https://approved.example.com -fs fqdn -d 1 -c 1 -p 1 -rl 1 -ct 30s -o katana-endpoints.txt
```

**Nuclei** only with an individually reviewed local HTTP GET-only template, not the default community collection. Audit outbound destinations, paths, HTTP methods, template payloads, rate behavior and account context first. `-ni` disables OAST; `-dr` blocks redirect following; `-or` omits raw traffic in output. The example must not be used if the program forbids automation or if the template targets excluded paths.

```bash
nuclei -u https://approved.example.com -t ./reviewed-templates/one-safe-check.yaml -rl 1 -c 1 -bs 1 -ni -dr -or -j -silent -duc -o nuclei-output.jsonl
python scripts/autohunter.py ingest-nuclei --scope engagement/scope.json --jsonl nuclei-output.jsonl --output runs/first
```

**IDOR:** No brute-force IDs and no guessing other users' resources. Use the built-in two-account differential with an exact synthetic private record as documented in `SKILL.md`. Use existing `HAR` captures from your own browser/Burp session to choose the relevant endpoints.

**Other powerful frameworks:** Strix can conduct deeper pentesting when explicitly authorized, but it requires separate installation, configuration, and review of its capabilities. A Skill file **cannot** magically equip an agent with Strix's Docker environment, LLM, browser, or network access. This V3 package intentionally does not execute Strix or PentestAgent automatically.

## Provenance of features vs. verified behavior

- Github references were checked against public project pages on November 7, 2026.
- Adopted **methodological concepts**, not copied third-party source code.
- CLI flags above are based on the publicly documented tool CLI flags; binaries are not included and their end-to-end behavior is **not tested** in this archive.
- Only the bundled Python components have local unit/integration tests. Lab successes do not prove real HackerOne impact.
