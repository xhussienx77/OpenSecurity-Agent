# AI triage playbook for Burp captures

Run only over `burp_analysis.json` and `BURP_REVIEW.md`, **not** the original XML containing raw secrets.

1. Inventory: host, path pattern, method, statuses, seen count, signal names, parameter names, current program rule constraints.
2. Authorization: choose endpoints with an ownership boundary (`/api/accounts/{id}`, `/api/files/{id}`) and propose one *minimal* owned-account compare, only if the program permits. Never enumerate object IDs or fetch another person's resources.
3. Authentication/session: distinguish expected 200 vs 401 and cookie attribute clues. Lack of security attributes alone rarely justifies a paid report; identify demonstrable effect.
4. CORS: a credentialed origin-reflection marker needs further contextual checks (trust boundary, browser rules, sensitive response and true attacker-origin control). Wildcard alone isn't a credentialed read exploit.
5. Information disclosure: `/.env`, `/.git/HEAD`, phpinfo and Apache server-status require consistent actual response/content, not a 200 soft-404. Redact data before any LLM prompt. Stop on third-party data.
6. Business logic: map allowed workflow, actors, pre/post invariants and side-effect risks; recommend **manual review** on the researcher's test records rather than automated mutations.
7. Confidence ranking: strong raw marker -> candidate; unsupported route name -> hypothesis; separately reproduced authorized effect -> researcher-verifiable finding. Do not convert any candidate to confirmed without explicit independent observation.
8. Reporting: neutral natural English, facts only; numbered exact approved reproduction steps, expected vs actual, screenshots/request references *only if supplied*, measured impact not estimated impact, privacy-safe evidence, remediation. Do not submit without researcher approval.

Flag coverage: XML is the source for backfill; live mode may drop events under load. The extension does not itself replay any request or verify cross-account authorization.
