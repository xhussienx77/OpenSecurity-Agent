# Tools and Command Guardrails

## Standard-library scanner

`python scripts/h1_hunter.py scan --config engagement/program.json --target https://YOUR_IN_SCOPE_HOST --output engagement/results --confirm-authorization`

Produces candidate findings from 7 GET requests max: `/`, a random non-existing path, `/.git/HEAD`, `/.env`, `/phpinfo.php`, `/server-status?auto`, and a synthetic CORS Origin on `/`. Each scoped path is independently checked. No follow redirects. No response bodies/secrets written. Skips excluded paths. This is narrow by design: it is not a comprehensive DAST platform.

## Owned-account authorization differential

`H1_TEST_A_TOKEN` / `H1_TEST_B_TOKEN` are environment variables (bearer token or cookie header value depending on case). The case contains an owned private resource path and a synthetic harmless marker present in that resource. The tool first verifies the owner's access and marker. Only then sends a single GET as the other researcher-owned test account. A match is strong evidence requiring manual privacy check.

## Offline HAR triage

`python scripts/har_triage.py --har own-browser-export.har --exact-host YOUR_IN_SCOPE_HOST --output engagement/endpoints.json`

Does NOT contact any host. Original HAR may hold sessions/passwords; keep the file on your own machine. The report discards raw headers, query values, bodies and resource IDs. Note that arbitrary short path segments may still contain sensitive data; inspect/sanitize before sharing.

## Optional Nuclei (not executed by this package)

Nuclei is a powerful template runner, but default template packs can generate huge or prohibited traffic. Only use if a program explicitly allows automation and the specific checks. Review the local YAML templates and their protocols before manually running. Example for a single known safe, reviewed HTTP template:

```bash
nuclei -u https://YOUR_IN_SCOPE_HOST -t ./reviewed-template.yaml -pt http -rl 1 -c 1 -bs 1 -retries 0 -timeout 8 -ni -or -j -o nuclei.jsonl
```

Not every template is safe. This command is an example for user review, not a claim that every template obeys program rules. Test installed flag support with `nuclei -h`. Exclude DoS, brute force, OAST, cloud metadata, account-impacting, out-of-scope callback and exploitation templates. Do not run broad scans by default.

Official Nuclei docs: https://docs.projectdiscovery.io/opensource/nuclei/running and https://github.com/projectdiscovery/nuclei
