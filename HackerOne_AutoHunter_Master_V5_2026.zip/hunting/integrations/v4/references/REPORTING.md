# HackerOne Report Standard

Do not submit raw scanner alerts as proven vulnerabilities. A useful report includes:

1. **Title** tied to a verified security boundary (`Cross-tenant access to private draft via GET /api/drafts/{id}`), not generic "critical IDOR".
2. **Affected program & asset** exactly as listed in scope, and any relevant path/role.
3. **Prerequisites** and exact owned test accounts, no login secrets.
4. **Steps to reproduce** as few as possible, numbered, with expected-vs-observed behavior and sanitized status/response fragments.
5. **Impact** based on what actually happened (e.g., unauthorized read of **researcher-owned** private data), not assertions about all users.
6. **Evidence** safely redacted; marker-only or truncated examples when possible. No credentials, PII, customer records, full repository dumps, proprietary source uploads, or real money effects.
7. **Mitigation** one or two practical sentences, and optional CWE/CVSS only when justified.
8. **Policy check** excluded classes, duplicate/known behavior, rate/automation requirements; record when checked.

If a finding is not reproducible, say so and keep it private as a lead. If the program's disclosure policy requires approval, do not make finding details public without it.

References: https://www.hackerone.com/terms/disclosure-guidelines and https://wstg.owasp.org/stable/4-Web_Application_Security_Testing/.
