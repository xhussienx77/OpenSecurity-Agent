"""Tests never touch HackerOne sites. Only a local HTTP receiver fixture is used."""
import base64
import http.client
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import h1_hunter as core
import burp_bridge as b


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.scope={'program_handle':'demo','policy_url':'https://hackerone.com/demo',
                    'policy_reviewed':True,'authorization_confirmed':True,'automation_allowed':False,
                    'in_scope_hosts':['app.example.com'],'out_of_scope_hosts':['blocked.example.com'],
                    'out_of_scope_paths':['/admin/private'],'max_requests_per_second':1}
        self.scopepath=self.root/'scope.json'
        b.write_json(self.scopepath,self.scope)

    def make_xml(self, url='https://app.example.com/api/users/123456?access_token=TOPSECRET12345',
                 status=200, response_body=b'Traceback (most recent call last): pass', response_headers='',
                 request_headers='Cookie: session=COOKIE_SECRET\r\nAuthorization: Bearer TOPSECRET12345'):
        item=ET.Element('item')
        ET.SubElement(item,'url').text=url
        ET.SubElement(item,'method').text='GET'
        req=(f'GET /api/users/123456?access_token=TOPSECRET12345 HTTP/1.1\r\nHost: app.example.com\r\n{request_headers}\r\n\r\n').encode()
        resp=(f'HTTP/1.1 {status} OK\r\nContent-Type: text/plain\r\n{response_headers}\r\n').encode()+b'\r\n'+response_body
        ET.SubElement(item,'request',{'base64':'true'}).text=base64.b64encode(req).decode()
        ET.SubElement(item,'response',{'base64':'true'}).text=base64.b64encode(resp).decode()
        root=ET.Element('items');root.append(item)
        path=self.root/'save.xml';ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
        return path

    def test_xml_redaction_and_candidate(self):
        xml=self.make_xml()
        with patch.object(core,'request',side_effect=AssertionError('must never scan')):
            rows,stat=b.import_xml(xml,self.scope)
        self.assertEqual(stat['total_items_considered'],1)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['path_pattern'],'/api/users/{id}')
        self.assertNotIn('access_token',json.dumps(rows))
        report=b.analyze(rows)
        self.assertEqual(report['candidates'][0]['signal'],'stack_trace')
        self.assertFalse(report['candidates'][0]['reportable'])
        b.save_report(report,self.root/'result')
        texts='\n'.join(p.read_text() for p in (self.root/'result').rglob('*') if p.is_file())
        for secret in ('COOKIE_SECRET','TOPSECRET12345','123456','Traceback (most recent call last): pass'):
            self.assertNotIn(secret,texts)

    def test_xml_out_scope(self):
        rows,stats=b.import_xml(self.make_xml(url='https://blocked.example.com/admin/private'),self.scope)
        self.assertEqual(rows,[])
        self.assertEqual(stats['skipped_out_of_scope_or_invalid'],1)

    def test_xml_path_exclusion(self):
        rows,_=b.import_xml(self.make_xml(url='https://app.example.com/admin/private/123'),self.scope)
        self.assertEqual(rows,[])

    def test_xml_dtd_disallowed(self):
        xml=self.root/'unsafe.xml'
        xml.write_text('<!DOCTYPE items [<!ENTITY x "boom">]><items>&x;</items>')
        with self.assertRaises(core.GuardError):
            b.import_xml(xml,self.scope)

    def test_sensitive_short_slug_suppressed(self):
        e=b.sanitized_event({'scheme':'https','host':'app.example.com','path':'/api/custompath/alice',
                             'method':'GET','status':200,'parameter_names':['password','filter','api_key','q'],
                             'flags':{'stack_trace':True,'untrusted_secret':'abc'}},self.scope)
        self.assertNotIn('alice',str(e))
        self.assertNotIn('custompath',str(e))
        self.assertIn('filter',e['parameter_names'])
        self.assertNotIn('password',str(e))
        self.assertNotIn('untrusted_secret',str(e))

    def test_flags_require_status_200(self):
        rows,_=b.import_xml(self.make_xml(url='https://app.example.com/.git/HEAD',status=404,
                                    response_body=b'ref: refs/heads/main'),self.scope)
        self.assertFalse(rows[0]['flags'].get('git_exposure'))

    def test_credential_cors_reflection_signal(self):
        xml=self.make_xml(url='https://app.example.com/api/users/123',request_headers='Origin: https://untrusted.invalid',
             response_headers='Access-Control-Allow-Origin: https://untrusted.invalid\r\nAccess-Control-Allow-Credentials: true')
        rows,_=b.import_xml(xml,self.scope)
        self.assertTrue(rows[0]['flags']['cors_credential_origin_reflection'])
        self.assertTrue(any(x['signal']=='cors_credential_origin_reflection' for x in b.analyze(rows)['candidates']))

    def test_missing_scope_permission_no_scan(self):
        self.scope['authorization_confirmed']=False
        self.assertIsNone(b.sanitized_event({'scheme':'https','host':'app.example.com','path':'/',
                                             'method':'GET','status':200},self.scope))

    def test_receiver_secret_and_scope(self):
        conf={'bridge_token':'TEST-token-not-real-but-long-enough-0123456','local_port':8766}
        from http.server import ThreadingHTTPServer
        httpd=ThreadingHTTPServer(('127.0.0.1',0), b.handler_factory(conf,self.scope,self.root/'live'))
        t=threading.Thread(target=httpd.serve_forever,daemon=True);t.start()
        self.addCleanup(lambda: (httpd.shutdown(),httpd.server_close(),t.join(timeout=2)))
        valid={'scheme':'https','host':'app.example.com','path':'/api/users/123456?cookie=DO_NOT_STORE',
               'method':'GET','status':200,'parameter_names':['jwt','q'],
               'flags':{'stack_trace':True,'evil_blob':'do-not-write'},'extra':'BEARER_MUST_NOT_STORE','source':'burp-live'}
        def post(token, event):
            c=http.client.HTTPConnection('127.0.0.1',httpd.server_address[1],timeout=2)
            c.request('POST','/ingest',json.dumps(event),{'Content-Type':'application/json','X-AutoHunter-Token':token})
            status=c.getresponse().status;c.close();return status
        self.assertEqual(post('wrong',valid),403)
        self.assertEqual(post(conf['bridge_token'],valid),202)
        valid['host']='blocked.example.com'
        self.assertEqual(post(conf['bridge_token'],valid),403)
        stored=(self.root/'live'/'burp_events.ndjson').read_text()
        for secret in ('123456','DO_NOT_STORE','BEARER_MUST_NOT_STORE','evil_blob'):
            self.assertNotIn(secret,stored)
        rows,_=b.analyze_file(self.root/'live'/'burp_events.ndjson',self.scope)
        self.assertEqual(len(rows),1)

    def test_v4_combined_pipeline_adds_burp_evidence_without_external_network(self):
        import autohunter
        self.scope.update({'automation_allowed':True,'seed_origins':['https://app.example.com'],
                           'crawl_enabled':False,'crawler_allowed':False})
        b.write_json(self.scopepath,self.scope)
        xml=self.make_xml(url='https://app.example.com/.git/HEAD',
                          response_body=b'ref: refs/heads/main')
        # Stub out the old V3 active probes; this test is exclusively offline.
        with patch.object(core,'scans',return_value=([],[],[])) as mocked:
            result=autohunter.run(self.scopepath,self.root/'combined',approved=True,burp_xml=str(xml))
        mocked.assert_called_once()
        self.assertTrue(any(x['category']=='information-disclosure' for x in result['findings']))
        self.assertTrue(any(x['source']=='BURP' for x in result['hypotheses']))
        self.assertTrue((self.root/'combined'/'burp'/'BURP_REVIEW.md').is_file())
        self.assertTrue((self.root/'combined'/'SUMMARY.md').is_file())
        self.assertTrue(all(not x['reportable'] for x in result['findings']))

    def test_init_secret(self):
        conf=b.init_config(self.scopepath,self.root/'config.json')
        data=json.loads(conf.read_text())
        self.assertGreaterEqual(len(data['bridge_token']),25)
        self.assertEqual(data['scope_file'],str(self.scopepath))
        with self.assertRaises(core.GuardError):
            b.init_config(self.scopepath,conf)


if __name__=='__main__':
    unittest.main()
