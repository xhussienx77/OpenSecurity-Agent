"""Local, controlled tests for scope, detection, privacy and authorization boundaries."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('h1_hunter', BASE / 'scripts' / 'h1_hunter.py')
hunter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hunter)
spec2 = importlib.util.spec_from_file_location('har_triage', BASE / 'scripts' / 'har_triage.py')
har = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(har)


class LocalLab(BaseHTTPRequestHandler):
    def do_GET(self):
        status, payload = 200, b'<html>Home</html>'
        if self.path == '/.git/HEAD':
            payload = b'ref: refs/heads/main\n'
        elif self.path == '/.env':
            payload = b'APP_KEY=SECRET_NOT_TO_SAVE_123\nDB_HOST=localhost\n'
        elif self.path == '/phpinfo.php':
            payload = b'<html>phpinfo() PHP Version 8.4</html>'
        elif self.path == '/server-status?auto':
            payload = b'ServerVersion: Apache/2.4\nTotal Accesses: 123\n'
        elif self.path == '/api/notes/own-a':
            auth = self.headers.get('Authorization', '')
            if auth in ('Bearer TEST_ACCOUNT_A', 'Bearer TEST_ACCOUNT_B'):
                payload = b'{"note":"H1_TEST_PRIVATE_NOTE_12345"}'
            else:
                status, payload = 401, b'unauthorized'
        elif self.path == '/redirect':
            status, payload = 302, b''
        elif self.path != '/':
            status, payload = 404, b'not found'
        self.send_response(status)
        self.send_header('Content-Type', 'text/html')
        if self.path == '/redirect':
            self.send_header('Location', 'https://outside.example/')
        if self.headers.get('Origin') == 'https://h1-scope-test.invalid':
            self.send_header('Access-Control-Allow-Origin', self.headers['Origin'])
            self.send_header('Access-Control-Allow-Credentials', 'true')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *args):
        pass


class ScopeUnitTests(unittest.TestCase):
    def setUp(self):
        self.config = {
            'program_handle': 'local-fixture', 'policy_url': 'https://hackerone.com/local-fixture',
            'policy_reviewed': True, 'authorization_confirmed': True,
            'automation_allowed': True, 'authz_testing_allowed': True,
            'in_scope_hosts': ['127.0.0.1'], 'out_of_scope_hosts': [],
            'out_of_scope_paths': ['/forbidden'], 'max_requests_per_second': 2
        }

    def test_default_deny(self):
        no = dict(self.config, policy_reviewed=False)
        with self.assertRaises(hunter.GuardError):
            hunter.gate(no, 'http://127.0.0.1:1', active=True)

    def test_automation_restriction(self):
        no = dict(self.config, automation_allowed=False)
        with self.assertRaises(hunter.GuardError):
            hunter.gate(no, 'http://127.0.0.1:1', active=True)

    def test_external_hosts_and_ports_fail(self):
        with self.assertRaises(hunter.GuardError):
            hunter.gate(self.config, 'https://not-mine.example', active=True)
        with self.assertRaises(hunter.GuardError):
            hunter.normalized_origin('https://in-scope.example:8080')
        with self.assertRaises(hunter.GuardError):
            hunter.normalized_origin('http://in-scope.example')
        with self.assertRaises(hunter.GuardError):
            hunter.normalized_origin('https://good.example@bad.example')

    def test_wildcards_do_not_expand_apex(self):
        self.assertTrue(hunter.host_matches('a.b.example.com', '*.example.com'))
        self.assertFalse(hunter.host_matches('example.com', '*.example.com'))
        self.assertFalse(hunter.host_matches('evil-example.com', '*.example.com'))
        self.assertFalse(hunter.host_matches('badexample.com', '*.example.com'))

    def test_exclusion_priority(self):
        config = dict(self.config, in_scope_hosts=['*.example.com'], out_of_scope_hosts=['admin.example.com'])
        with self.assertRaises(hunter.GuardError):
            hunter.gate(config, 'https://admin.example.com')
        with self.assertRaises(hunter.GuardError):
            hunter.gate(self.config, 'http://127.0.0.1:1234', '/forbidden/login')

    def test_paths_block_traversal(self):
        for bad in ('//evil.example/x', '/abc/../xyz', '/abc/%2e%2e/file', 'https://evil.example/'):
            self.assertFalse(hunter.valid_path(bad), bad)

    def test_import_scope_export_is_not_authorization(self):
        with tempfile.TemporaryDirectory() as t:
            f = Path(t) / 'scope.json'
            f.write_text(json.dumps({'data': [
                {'id': '1', 'attributes': {'asset_type': 'URL', 'asset_identifier': 'https://ok.example/', 'eligible_for_submission': True}},
                {'id': '2', 'attributes': {'asset_type': 'URL', 'asset_identifier': 'https://ok.example/admin', 'eligible_for_submission': True}},
                {'id': '3', 'attributes': {'asset_type': 'DOMAIN', 'asset_identifier': 'excluded.example', 'eligible_for_submission': False}},
            ]}))
            result = hunter.import_scopes(f)
            self.assertTrue(result['review_required'])
            self.assertEqual(len(result['candidate_hosts']), 1)
            self.assertEqual(len(result['unsupported_or_ambiguous']), 1)
            self.assertEqual(len(result['excluded_hosts']), 1)

    def test_har_omits_tokens_query_and_identifiers(self):
        raw = {'log': {'entries': [
            {'request': {'method': 'GET', 'url': 'https://app.example/api/users/123456?token=SECRET_XYZ',
                         'headers': [{'name': 'Cookie', 'value': 'SECRET_COOKIE'}]}, 'response': {'status': 200, 'content': {'text': 'SECRET_BODY'}}},
            {'request': {'method': 'POST', 'url': 'https://outside.example/admin'}, 'response': {'status': 201}}]}}
        result = har.triage_har(raw, {'app.example'})
        serialized = json.dumps(result)
        self.assertIn('/api/users/{id}', serialized)
        for secret in ('SECRET_XYZ', 'SECRET_COOKIE', 'SECRET_BODY', '123456'):
            self.assertNotIn(secret, serialized)
        self.assertEqual(result['skipped_entries_outside_exact_host_allowlist'], 1)


class LocalNetworkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), LocalLab)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.target = f'http://127.0.0.1:{cls.server.server_port}'
        cls.config = {
            'program_handle': 'local-fixture', 'policy_url': 'https://hackerone.com/local-fixture',
            'policy_reviewed': True, 'authorization_confirmed': True,
            'automation_allowed': True, 'authz_testing_allowed': True,
            'in_scope_hosts': ['127.0.0.1'], 'out_of_scope_hosts': [],
            'out_of_scope_paths': [], 'max_requests_per_second': 2
        }

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_end_to_end_findings_and_secret_redaction(self):
        with tempfile.TemporaryDirectory() as t:
            c = Path(t) / 'config.json'
            c.write_text(json.dumps(self.config))
            r = subprocess.run([sys.executable, str(BASE / 'scripts' / 'h1_hunter.py'), 'scan',
                                '--config', str(c), '--target', self.target,
                                '--output', str(Path(t) / 'results'), '--confirm-authorization'],
                               capture_output=True, text=True, timeout=45)
            self.assertEqual(r.returncode, 0, r.stderr)
            data = json.loads((Path(t) / 'results' / 'report.json').read_text())
            self.assertEqual(len(data['findings']), 5)
            raw_report = (Path(t) / 'results' / 'report.md').read_text() + json.dumps(data)
            self.assertNotIn('SECRET_NOT_TO_SAVE_123', raw_report)
            self.assertTrue(all(f['state'] == 'candidate_needs_manual_validation' for f in data['findings']))
            self.assertLessEqual(len(data['probes']), 7)
            hunter.draft_finding(Path(t) / 'results' / 'report.json', 1, Path(t) / 'draft.md')
            self.assertIn('DRAFT — VERIFY FIRST', (Path(t) / 'draft.md').read_text())

    def test_authz_owned_accounts_and_minimal_evidence(self):
        case = {'method': 'GET', 'owner': 'A', 'path': '/api/notes/own-a', 'auth_method': 'bearer',
                'synthetic_private_marker': 'H1_TEST_PRIVATE_NOTE_12345', 'researcher_owns_both_accounts_and_resource': True}
        from unittest.mock import patch
        with patch.dict(os.environ, {'H1_TEST_A_TOKEN': 'TEST_ACCOUNT_A', 'H1_TEST_B_TOKEN': 'TEST_ACCOUNT_B'}):
            found, probes, notes = hunter.authz_case(self.config, self.target, case)
        self.assertEqual(len(probes), 2)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]['category'], 'access-control-idor')
        self.assertNotIn('H1_TEST_PRIVATE_NOTE_12345', json.dumps(found))
        self.assertNotIn('TEST_ACCOUNT_A', json.dumps(found))

    def test_authz_denied_preconditions(self):
        case = {'method': 'POST', 'owner': 'A', 'path': '/api/notes/own-a', 'auth_method': 'bearer',
                'synthetic_private_marker': 'H1_TEST_PRIVATE_NOTE_12345', 'researcher_owns_both_accounts_and_resource': True}
        with self.assertRaises(hunter.GuardError):
            hunter.authz_case(self.config, self.target, case)

    def test_no_redirect_follow(self):
        result = hunter.request(self.target + '/redirect')
        self.assertEqual(result.get('status'), 302)


if __name__ == '__main__':
    unittest.main()
