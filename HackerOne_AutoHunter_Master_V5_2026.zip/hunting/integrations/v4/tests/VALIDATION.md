# AutoHunter V4 local validation — 2026-11-07

```powershell
py -m unittest discover -s tests -v
```

**Result: 37/37 passing local tests on November 7, 2026.**

The suite tests scope boundaries, passive XML parsing, secret sanitization, CORS/exposure signals, offline-only behaviour, localhost bridge token handling, Jython-compatible event ingestion data, and previous V3 scan functionality. Tests use synthetic Burp-like XML and a disposable localhost receiver; no actual HackerOne assets were scanned, and **the Jython extension was not run inside Burp Suite itself**.

No test can guarantee a real bounty finding or reveal false-positive rates for arbitrary apps. Report drafts remain unverified until reviewed with owned resources and program permissions.
