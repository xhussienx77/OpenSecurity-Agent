"""V3 offline integration and safety tests. Only localhost fixture is contacted."""
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE/'scripts'))
import autohunter as ap
import h1_hunter as core


class TestApp(BaseHTTPRequestHandler):
    urls = []
    def do_GET(self):
        self.__class__.urls.append(self.path)
        code = 200
        mime = 'text/html'
        data = b'<html><a href="/help">Help</a><a href="/logout">Logout</a><a href="https://external.invalid/">External</a><a href="/pay?amount=100">Query</a></html>'
        if self.path == '/.git/HEAD':
            data, mime = b'ref: refs/heads/main\n', 'text/plain'
        elif self.path == '/.env':
            data, mime = b'DB_PASSWORD=HIDDEN_VALUE\nAPP_KEY=HIDDEN_VALUE\n', 'text/plain'
        elif self.path == '/help':
            data = b'<html>help</html>'
        elif self.path == '/api/notes/owned':
            if self.headers.get('Authorization','') in ('Bearer TEST_A_OWNED','Bearer TEST_B_OWNED'):
                data, mime = b'{"note":"H1_TEST_OWNED_NOTE_12345"}', 'application/json'
            else:
                code, data = 401, b'unauthorized'
        elif self.path == '/phpinfo.php':
            data = b'phpinfo() PHP Version 8.4'
        elif self.path == '/server-status?auto':
            data = b'ServerVersion: Apache/2.4\nTotal Accesses: 123'
        elif self.path.startswith('/__h1_absent_'):
            code, data = 404, b'Not Found'
        elif self.path == '/forbidden':
            data = b'NEVER'
        elif self.path == '/rate':
            code, data = 429, b'try later'
        elif self.path not in ('/', '/help'):
            code, data = 404, b'not found'
        self.send_response(code)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, *a):
        pass


class V3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1',0),TestApp)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.origin = 'http://127.0.0.1:'+str(self.port)
        self.cfg = dict(program_handle='test-fixture', policy_url='https://hackerone.com/test-fixture',
            policy_reviewed=True, authorization_confirmed=True, automation_allowed=True,
            authz_testing_allowed=True, in_scope_hosts=['127.0.0.1'], out_of_scope_hosts=[],
            out_of_scope_paths=['/forbidden'], max_requests_per_second=2, seed_origins=[self.origin],
            crawl_enabled=False, crawler_allowed=False)
        self.config = self.dir/'policy.json'
        core.write_json(self.config, self.cfg)

    def test_denies_without_consent(self):
        with self.assertRaises(core.GuardError):
            ap.run(self.config, self.dir/'results', approved=False)
        self.assertFalse((self.dir/'results').exists())

    def test_denies_out_of_scope_preflight_no_http(self):
        self.cfg['seed_origins'] = [self.origin, 'https://out-of-scope.invalid']
        core.write_json(self.config, self.cfg)
        TestApp.urls.clear()
        with self.assertRaises(core.GuardError):
            ap.run(self.config,self.dir/'output',approved=True)
        self.assertEqual([],TestApp.urls)

    def test_disabled_automation(self):
        self.cfg['automation_allowed'] = False
        core.write_json(self.config, self.cfg)
        with self.assertRaises(core.GuardError):
            ap.run(self.config,self.dir/'out',approved=True)

    def test_scans_sanitizes_and_resumes(self):
        st=ap.run(self.config,self.dir/'out',approved=True)
        self.assertGreaterEqual(len(st['findings']),2)
        contents=(self.dir/'out'/'state.json').read_text()
        self.assertNotIn('HIDDEN_VALUE',contents)
        self.assertTrue((self.dir/'out'/'SUMMARY.md').exists())
        self.assertTrue(any((self.dir/'out'/'drafts').glob('*.md')))
        self.assertTrue(all(not f['reportable'] for f in st['findings']))
        urls_count=len(TestApp.urls)
        again=ap.run(self.config,self.dir/'out',approved=True,resume=True)
        self.assertEqual(urls_count,len(TestApp.urls))
        self.assertEqual(len(st['findings']),len(again['findings']))

    def test_bounded_crawl_rejects_cross_host_query_sensitive(self):
        TestApp.urls.clear()
        data=ap.bounded_crawl(self.cfg,self.origin,max_pages=5)
        self.assertTrue(any(r['path']=='/help' for r in data['visited']))
        self.assertFalse(any('/logout' in x or '/pay' in x or '/forbidden' in x for x in TestApp.urls))
        self.assertFalse(any('external' in x for x in TestApp.urls))

    def test_crawler_permission_necessary(self):
        self.cfg['crawl_enabled']=True
        core.write_json(self.config,self.cfg)
        with self.assertRaises(core.GuardError):
            ap.run(self.config,self.dir/'out',approved=True)

    def test_har_and_js_offline_redact(self):
        jsdir=self.dir/'js'
        jsdir.mkdir()
        (jsdir/'bundle.js').write_text("fetch('/api/v1/users/1234567890123456789012345')")
        r=ap.collect_js_offline(jsdir,{'127.0.0.1'})
        self.assertIn('/api/v1/users/{id}',r['endpoint_path_patterns'])
        self.assertNotIn('1234567890123456789012345',json.dumps(r))
        hr={'endpoints':[{'host':'127.0.0.1','path_pattern':'/api/users/{id}','interest':['authorization/tenancy'], 'review_priority':'high'}]}
        self.assertEqual(ap.make_hypotheses(hr,r)[0]['priority'],'high')

    def test_review_requires_real_confirmation(self):
        st=ap.run(self.config,self.dir/'out',approved=True)
        fid=st['findings'][0]['id']
        decision=self.dir/'decision.json'
        core.write_json(decision,{'id':fid,'verified_by_researcher':False})
        with self.assertRaises(core.GuardError):
            ap.review(self.dir/'out',decision)
        self.assertFalse((self.dir/'out'/'ready_for_review').exists())
        core.write_json(decision,{'id':fid,'verified_by_researcher':True, 'evidence_reviewed':True,
           'demonstrated_impact':'Researcher demonstrated access in controlled environment only.',
           'expected_behavior':'This resource must not be available publicly.',
           'actual_behavior':'The resource response was delivered to an unauthenticated session.',
           'reproduction_steps':'1. Open a permitted URL as a test user. 2. Inspect the limited response.'})
        ap.review(self.dir/'out',decision)
        md=(self.dir/'out'/'ready_for_review'/f'{fid}.md').read_text()
        self.assertIn('RESEARCHER-VERIFIED',md)
        self.assertIn('controlled environment only',md)

    def test_authz_is_not_silently_enabled(self):
        case = self.dir/'case.json'
        core.write_json(case,{'path':'/api/notes/owned','owner':'A','method':'GET',
            'researcher_owns_both_accounts_and_resource':True,
            'synthetic_private_marker':'H1_TEST_OWNED_NOTE_12345'})
        self.cfg['owned_cases']=[{'origin':self.origin,'case_file':str(case)}]
        core.write_json(self.config,self.cfg)
        TestApp.urls.clear()
        with self.assertRaises(core.GuardError):
            ap.run(self.config,self.dir/'out',approved=True,account_consent=False)
        self.assertEqual([],TestApp.urls)

    def test_authorized_owned_account_case_in_same_pipeline(self):
        from unittest.mock import patch
        case = self.dir/'case.json'
        core.write_json(case,{'path':'/api/notes/owned','owner':'A','method':'GET',
            'researcher_owns_both_accounts_and_resource':True,
            'synthetic_private_marker':'H1_TEST_OWNED_NOTE_12345'})
        self.cfg['owned_cases']=[{'origin':self.origin,'case_file':str(case)}]
        core.write_json(self.config,self.cfg)
        with patch.dict(os.environ,{'H1_TEST_A_TOKEN':'TEST_A_OWNED',
                                    'H1_TEST_B_TOKEN':'TEST_B_OWNED'}):
            st=ap.run(self.config,self.dir/'out',approved=True,account_consent=True)
        self.assertEqual(1,len(st['authz_runs']))
        self.assertTrue(any(f['category']=='access-control-idor' for f in st['findings']))
        self.assertNotIn('TEST_A_OWNED',(self.dir/'out'/'state.json').read_text())

    def test_nuclei_offline_ingest_no_network(self):
        sample=self.dir/'out.jsonl'
        sample.write_text(json.dumps({'template-id':'safe-marker','matched-at':'http://127.0.0.1/api/users/1234567890123456789012345','info':{'severity':'medium'}, 'request':'Bearer SECRET_VALUE'})+'\n')
        num=ap.ingest_nuclei(self.dir/'out',sample,self.cfg)
        self.assertEqual(1,num)
        doc=(self.dir/'out'/'nuclei_candidates.json').read_text()
        self.assertNotIn('SECRET_VALUE',doc)
        self.assertNotIn('1234567890123456789012345',doc)

    def test_nuclei_filters_out_of_scope_paths_and_hosts(self):
        lines = [
            {'template-id':'a','matched-at':'https://third-party.invalid/private'},
            {'template-id':'b','matched-at':self.origin+'/forbidden'},
            {'template-id':'c','matched-at':self.origin+'/allowed'},
        ]
        file=self.dir/'out.jsonl'
        file.write_text('\n'.join(json.dumps(x) for x in lines)+'\n')
        n=ap.ingest_nuclei(self.dir/'out',file,self.cfg)
        self.assertEqual(1,n)
        data=core.load_json(self.dir/'out'/'nuclei_candidates.json')
        self.assertEqual('c',data['matches'][0]['template_id'])

    def test_campaign_circuit_breaker_after_server_error(self):
        from unittest.mock import patch
        self.cfg['seed_origins'] = [self.origin,'http://localhost:45123']
        self.cfg['in_scope_hosts'] = ['127.0.0.1','localhost']
        core.write_json(self.config,self.cfg)
        with patch.object(core,'scans',return_value=([],[{'path':'/','status':429}],['Stopped on HTTP 429 at an in-scope path; no further requests sent'])) as scans:
            data=ap.run(self.config,self.dir/'out',approved=True)
        self.assertEqual(1,scans.call_count)
        self.assertEqual(1,len(data['runs']))
        self.assertIn('Stopped remaining campaign',data['halt_reason'])

    def test_preflight_plan_is_offline(self):
        TestApp.urls.clear()
        p=ap.plan(self.cfg)
        self.assertEqual('allowed-by-local-policy',p['targets'][0]['status'])
        self.assertEqual([],TestApp.urls)

if __name__ == '__main__':
    unittest.main()
