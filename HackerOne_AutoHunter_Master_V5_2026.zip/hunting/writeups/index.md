# Public Write-up Index

| Title | Vuln Type | Target | Source |
|---|---|---|---|
| Public-style Case Study: API Role Enforcement Drift | bfla | fictional API | local educational sample, not a retrieved disclosure |
| Public-style Case Study: Object Ownership Mismatch | IDOR | fictional multi-tenant SaaS | local educational sample, not a retrieved disclosure |
| Public-style Case Study: State Transition Mismatch | business-logic | fictional online service | local educational sample, not a retrieved disclosure |
| Public-style Case Study: CORS Read Access Check | cors | fictional profile API | local educational sample, not a retrieved disclosure |
| Public-style Case Study: Rendered Markup Under User Control | stored-xss | fictional content app | local educational sample, not a retrieved disclosure |
