# Public-style Case Study: Rendered Markup Under User Control
Source: local educational sample, not a retrieved disclosure
Date: 2026-11-07
Vulnerability: stored-xss
Target: fictional content app
Entry point: user-owned text field
Precondition: second tester-controlled viewer account
Trust boundary: untrusted markup rendered to another session
Bypass: improper context-sensitive encoding
Proof method: safe inert render marker in controlled viewer, with no data collection
FP trap: markup reflected into plain text has no script execution
Chain opportunity: privileged rendering may raise impact only with authorized proof
Tags: client-side, rendering, stored
