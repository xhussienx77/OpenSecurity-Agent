# Public-style Case Study: Object Ownership Mismatch
Source: local educational sample, not a retrieved disclosure
Date: 2026-11-07
Vulnerability: IDOR
Target: fictional multi-tenant SaaS
Entry point: owned document read endpoint
Precondition: two accounts created by the tester
Trust boundary: object ownership between users
Bypass: server trusts a client-supplied object identifier
Proof method: compare the same user-owned document across two tester accounts
FP trap: a public/shared document may intentionally be readable
Chain opportunity: object discovery may increase exposure only if separately demonstrated
Tags: authorization, multi-tenant, evidence
