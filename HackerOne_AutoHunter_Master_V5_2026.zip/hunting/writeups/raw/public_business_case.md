# Public-style Case Study: State Transition Mismatch
Source: local educational sample, not a retrieved disclosure
Date: 2026-11-07
Vulnerability: business-logic
Target: fictional online service
Entry point: controlled discount redemption flow
Precondition: tester-owned account and test transaction
Trust boundary: business state managed on server
Bypass: state transition fails invariant check
Proof method: compare allowed and attempted state changes in test environment
FP trap: pending versus finalized state differences
Chain opportunity: repeated inconsistent state may produce a bounded balance error
Tags: workflow, state, payments
