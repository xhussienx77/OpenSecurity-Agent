# Public-style Case Study: API Role Enforcement Drift
Source: local educational sample, not a retrieved disclosure
Date: 2026-11-07
Vulnerability: bfla
Target: fictional API
Entry point: owned project configuration endpoint
Precondition: tester-owned low privilege and admin roles
Trust boundary: server authorization on state-changing API action
Bypass: inconsistent role check between UI and API
Proof method: compare permitted and blocked actions using owned project
FP trap: client UI hiding functionality does not establish server access control failure
Chain opportunity: role drift may affect additional owned resources after separate verification
Tags: api, authorization, roles
