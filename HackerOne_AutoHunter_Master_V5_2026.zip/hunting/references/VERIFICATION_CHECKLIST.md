# Verification Checklist

Canonical source: `runtime/registry.json`, `scripts/skill_registry.py`. The `agent-briefing.md`, `AGENTS.md`, `prioritization.md`, `runtime/opencode/loader.md`, `runtime/opencode/ORCHESTRATION.md`, `runtime/opencode/manifest.md` form the contract.

## Operating requirements
- Boot order: briefing → constitution → prioritization → loader → foundations → preflight → resolver → targeted review.
- Repository governance: keep the global skill registry canonical; share across `skills/` and `.agents/skills/`. Run tests after coordinated changes.
- Knowledge priority: `memory/report-lessons.md`, `memory/patterns.md`, `memory/methodology.md`, `memory/targets/<vuln>.md`, then public `writeups/index.md`.
- Per-target artifacts: `testing/<root-domain>/<subdomain>/` in notes, requests, responses, screenshots, scripts, scans, wordlists, urls, subdomains, evidence and reports.
- Scope enforcement: exact host without sibling traversal, program-permission review, rate limits and user-owned data.
- Validation before report: evidence, reproducibility, control context, false positives, demonstrated impact and human approval.
- Status: Ready for supervised autonomous hunting after required external connectors and permissions are configured.
