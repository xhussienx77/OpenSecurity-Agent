# Skill Router

Canonical source: `runtime/registry.json`, `scripts/skill_registry.py`. The `agent-briefing.md`, `AGENTS.md`, `prioritization.md`, `runtime/opencode/loader.md`, `runtime/opencode/ORCHESTRATION.md`, `runtime/opencode/manifest.md` form the contract.

## Operating requirements
- Boot order: briefing → constitution → prioritization → loader → foundations → preflight → resolver → targeted review.
- Repository governance: keep the global skill registry canonical; share across `skills/` and `.agents/skills/`. Run tests after coordinated changes.
- Knowledge priority: `memory/report-lessons.md`, `memory/patterns.md`, `memory/methodology.md`, `memory/targets/<vuln>.md`, then public `writeups/index.md`.
- Per-target artifacts: `testing/<root-domain>/<subdomain>/` in notes, requests, responses, screenshots, scripts, scans, wordlists, urls, subdomains, evidence and reports.
- Scope enforcement: exact host without sibling traversal, program-permission review, rate limits and user-owned data.
- Validation before report: evidence, reproducibility, control context, false positives, demonstrated impact and human approval.
- Status: Ready for supervised autonomous hunting after required external connectors and permissions are configured.

## Canonical skills

| Skill | Trigger terms | Path |
|---|---|---|
| master-bugbounty-rules | foundation | `.agents/skills/master-bugbounty-rules/SKILL.md` |
| learning-engine-integration | foundation | `.agents/skills/learning-engine-integration/SKILL.md` |
| recon-workflow | recon, discovery | `.agents/skills/recon-workflow/SKILL.md` |
| tech-fingerprint | technology, fingerprint, recon | `.agents/skills/tech-fingerprint/SKILL.md` |
| endpoint-triage | endpoint, route, api | `.agents/skills/endpoint-triage/SKILL.md` |
| fuzzing | fuzz, parameter, discovery | `.agents/skills/fuzzing/SKILL.md` |
| dorking-and-osint-discovery | osint, dork, public | `.agents/skills/dorking-and-osint-discovery/SKILL.md` |
| offensive-osint | osint, public | `.agents/skills/offensive-osint/SKILL.md` |
| osint-methodology | osint, public | `.agents/skills/osint-methodology/SKILL.md` |
| js-deep-analysis | javascript, js, source map, bundle | `.agents/skills/js-deep-analysis/SKILL.md` |
| js-secret-and-api-review | javascript, js, secret, api | `.agents/skills/js-secret-and-api-review/SKILL.md` |
| business-context-analysis | business, workflow, payment | `.agents/skills/business-context-analysis/SKILL.md` |
| exploit-chain-analysis | chain, trust boundary | `.agents/skills/exploit-chain-analysis/SKILL.md` |
| evidence-hygiene | evidence, report | `.agents/skills/evidence-hygiene/SKILL.md` |
| structured-summary-reporting | summary, report | `.agents/skills/structured-summary-reporting/SKILL.md` |
| idor-testing | idor, object, ownership, uuid | `.agents/skills/idor-testing/SKILL.md` |
| authz-access-control-tester | authorization, access control, role, tenant, idor | `.agents/skills/authz-access-control-tester/SKILL.md` |
| privilege-escalation-testing | privilege, admin, role | `.agents/skills/privilege-escalation-testing/SKILL.md` |
| api-security-testing | api, rest, json | `.agents/skills/api-security-testing/SKILL.md` |
| request-response-analyzer | request, response, burp, api | `.agents/skills/request-response-analyzer/SKILL.md` |
| request-response-manipulation | request, response, api | `.agents/skills/request-response-manipulation/SKILL.md` |
| xss-client-side-testing | xss, javascript, html, postmessage | `.agents/skills/xss-client-side-testing/SKILL.md` |
| blind-vuln | blind, callback | `.agents/skills/blind-vuln/SKILL.md` |
| parameter-analysis-and-guessing | parameter, query | `.agents/skills/parameter-analysis-and-guessing/SKILL.md` |
| login-security-testing | login, authentication, session | `.agents/skills/login-security-testing/SKILL.md` |
| forgot-password-testing | password reset, recovery, forgot | `.agents/skills/forgot-password-testing/SKILL.md` |
| two-factor-bypass-testing | mfa, otp, 2fa | `.agents/skills/two-factor-bypass-testing/SKILL.md` |
| captcha-bypass-testing | captcha | `.agents/skills/captcha-bypass-testing/SKILL.md` |
| oauth-oidc-testing | oauth, oidc | `.agents/skills/oauth-oidc-testing/SKILL.md` |
| saml-testing | saml | `.agents/skills/saml-testing/SKILL.md` |
| jwt-testing | jwt, token | `.agents/skills/jwt-testing/SKILL.md` |
| okta-attack | okta | `.agents/skills/okta-attack/SKILL.md` |
| m365-entra-attack | entra, m365 | `.agents/skills/m365-entra-attack/SKILL.md` |
| ssrf-redirect-url-testing | ssrf, url fetch, redirect, webhook | `.agents/skills/ssrf-redirect-url-testing/SKILL.md` |
| host-header-injection | host header, forwarded | `.agents/skills/host-header-injection/SKILL.md` |
| file-upload-testing | upload, file | `.agents/skills/file-upload-testing/SKILL.md` |
| xxe-testing | xml, xxe | `.agents/skills/xxe-testing/SKILL.md` |
| cors-misconfiguration | cors, origin | `.agents/skills/cors-misconfiguration/SKILL.md` |
| cache-poisoning-testing | cache | `.agents/skills/cache-poisoning-testing/SKILL.md` |
| http-smuggling-testing | http request smuggling, proxy | `.agents/skills/http-smuggling-testing/SKILL.md` |
| websocket-testing | websocket | `.agents/skills/websocket-testing/SKILL.md` |
| race-condition-testing | race, one-time | `.agents/skills/race-condition-testing/SKILL.md` |
| business-logic-testing | business, payment, coupon, workflow | `.agents/skills/business-logic-testing/SKILL.md` |
| graphql-testing | graphql | `.agents/skills/graphql-testing/SKILL.md` |
| cloud-storage-review | bucket, storage, s3 | `.agents/skills/cloud-storage-review/SKILL.md` |
| cloud-iam-deep | iam, cloud | `.agents/skills/cloud-iam-deep/SKILL.md` |
| llm-ai-security-testing | llm, prompt injection, ai | `.agents/skills/llm-ai-security-testing/SKILL.md` |
| mobile-api-testing | apk, mobile | `.agents/skills/mobile-api-testing/SKILL.md` |
| web3-review | web3, smart contract | `.agents/skills/web3-review/SKILL.md` |
| response-diff-analysis | response diff, baseline, validation | `.agents/skills/response-diff-analysis/SKILL.md` |
| false-positive-filter | false positive, fp, validation | `.agents/skills/false-positive-filter/SKILL.md` |
| evidence-validation-and-severity-calibration | severity, validation, report | `.agents/skills/evidence-validation-and-severity-calibration/SKILL.md` |
| report-writer | report | `.agents/skills/report-writer/SKILL.md` |
| bugcrowd-reporting | bugcrowd, report | `.agents/skills/bugcrowd-reporting/SKILL.md` |
| redteam-report-template | report | `.agents/skills/redteam-report-template/SKILL.md` |
