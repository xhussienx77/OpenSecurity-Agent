# Burp Integration - V4 Bridge carried forward

Preserved code: `integrations/v4/extensions/BurpAutoHunter.py`, `integrations/v4/scripts/burp_bridge.py` and `integrations/v4/scripts/har_triage.py`. See `integrations/v4/docs/BURP_INTEGRATION.md` for previous setup and commands.

The bridge accepts metadata and local XML exports; it is not an all-requests AI exploit engine. Feed raw history into a locally protected workspace, perform redaction before model submission, discard out-of-scope traffic, and review authorization/state transitions with owned accounts. Burp extension installation needs a local GUI and an appropriate Jython version; it is NOT verified here. Never forward authentication secrets, session IDs, complete private bodies or personal data into a remote model.
