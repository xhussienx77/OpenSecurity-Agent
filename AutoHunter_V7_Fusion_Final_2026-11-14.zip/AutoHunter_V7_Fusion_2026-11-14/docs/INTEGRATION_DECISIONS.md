# Integration decision log — 2026-11-14

## Reviewed foundation

- User-provided `AutoHunter_Review.zip` contained 279 allowed-source files, an existing 55-skill canonical/mirror library, `scripts/hunt_state.py` (985 lines with atomic locking, claims, reconciliation), `runtime_preflight.py`, `report_draft.py`, `learning_engine/engine.py`, a Burp v4 integration, `runtime/registry.json`, and OpenCode commands.
- Upstream Claude-BugHunter was reviewed via its public README, `docs/skills.md` (83 skill catalog), `docs/architecture.md`, `engine/scope.py`, `engine/skill_map.py`, and `engine/engine.py`. The entire upstream checkout was *not* available as a file attachment, so the installer performs the exact file-by-file import and audit **on the user's Kali clone**, preserving provenance. It cannot honestly claim a full upstream line-by-line comparison before that source is available.
- Do not conflate catalog completeness with quality, validated vulnerability reproduction, or binary compatibility.

## Keep (existing system stronger or already integrated)

- `scripts/hunt_state.py`: no separate state database competing with existing atomic checkpoints and quota/safety blocks.
- `scripts/runtime_preflight.py`: authoritative pre-test gate, source policies remain external and operator verified.
- `scripts/skill_registry.py` and original `_tools/skillctl.py` 55-skill invariant: preserved. Additional IDs are added without changing the original 55.
- `hunting/learning_engine`: no undocumented automatic model training from unreviewed findings.
- Burp v4 integration and OpenCode agent definitions: untouched.

## Add (offline and deterministic)

1. Exact-host, explicit-subdomain and deny-first supplementary URL validation (strict, segmented paths).
2. Provenance-labeled, deduplicated, metadata-only HAR/JSONL import and privacy-safe route classification.
3. Registry-aware, bounded `native + cbh` skill selection without loading the full library into LLM context.
4. Operator-reviewed seven-question report gate with structured, redacted, platform-aware drafts.
5. Synthetic evaluation scoreboard and explicit INCONCLUSIVE/BLOCKED outcomes.
6. Ten contextual native skills for currently less explicit coverage: session, cross-tenant, API versions, financial GraphQL, state transitions, framework-specific, gRPC, RAG, CI/CD, scope/evidence contract.
7. An upstream skill importer requiring all 83 cataloged source skills and preserving CC BY attribution; namespaced copies avoid collisions.
8. Idempotent installer with backups, collision prevention, no source deletion, and a minimal additive `/hunt` appendix.

## Out of scope by user instruction

- Burp Live Adapter and Automatic Agent Dispatch. No real-world security requests are sent by this release.

## Follow-up technical cautions

- Verify actual runtime model routing through OpenCode because `opencode.json` contains both `agent` and legacy `agents` entries. The source snapshot differs from older DeepSeek/Sol assumptions. Do not silently change assignments.
- `skills/_tools/skillctl.py` still tracks only 55 original V5/V6 skills. The unified registry tracks originals + new + namespaced upstream. Check **both** after installing.
- Maintain single authoritative engagement/task state. V7 Fusion's offline JSON outputs are analysis artifacts, not a second task queue.
- Imported vendor text can contain Claude Code specific paths and instructions: read as third-party references subject to higher-priority program and project policy.

## `/hunt` text hardening (without new agent automation)

The source snapshot's `/hunt` demanded mailbox login and claimed the agent already possessed credentials. It also used unconditional browser and fuzzing mandates. On install, exact matching strings are conservatively replaced with optional, approved test-account access, no credential storage, proper preflight dependency, non-destructive focused checks, and a gated draft report path. Only the command file receives this scoped textual edit; the existing `AGENTS.md`, models, task scheduler and underlying engine are unchanged. If source text differs, no blind replacement is performed.

## `/hunt` text hardening (without new agent automation)

The source snapshot's `/hunt` demanded mailbox login and claimed the agent already possessed credentials. It also used unconditional browser and fuzzing mandates. On install, exact matching strings are conservatively replaced with optional, approved test-account access, no credential storage, preflight dependency, non-destructive focused checks, and a gated draft report path. Only the command file receives these scoped textual edits; existing `AGENTS.md`, models, task scheduler and underlying engine are unchanged. If source text differs, no blind replacement occurs.
