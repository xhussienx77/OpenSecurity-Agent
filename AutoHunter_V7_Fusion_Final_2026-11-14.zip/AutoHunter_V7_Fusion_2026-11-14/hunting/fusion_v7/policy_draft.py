"""Extract unverified scope candidates from operator-supplied program text.

This intentionally NEVER produces authorization_confirmed=true or a usable
allowlist. An operator must independently compare against official live program
terms and populate the policy file themselves.
"""
import re
from pathlib import Path

HOST=re.compile(r'(?<![A-Za-z0-9_.-])(?:\*\.)?(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?![A-Za-z0-9_-])')

def draft(text):
    if not isinstance(text,str) or len(text)>2_000_000:raise ValueError('Input too large')
    # Conservative: only extract potential hosts as hints, no automatic scoping.
    candidates=sorted(set(h.lower() for h in HOST.findall(text)))
    return {'program':'UNVERIFIED','policy_source':'','authorization_confirmed':False,
            'active_testing_allowed':False,'approved_activities':[],
            'allowed_hosts':[],'excluded_hosts':[],
            'allowed_paths':['/'],'excluded_paths':[],'allowed_methods':['GET','HEAD'],
            'unverified_domain_mentions':candidates[:250],
            'review_required':['Official in-scope asset list','Wildcard vs exact hosts','Out-of-scope exclusions',
              'Path and API method restrictions','Prohibited testing methods','Production safety/volume',
              'Approval for authenticated accounts','Policy URL and check date'],
            'warning':'Unverified mentions can include out-of-scope hosts. NEVER copy candidates into allowlist without human verification.'}
