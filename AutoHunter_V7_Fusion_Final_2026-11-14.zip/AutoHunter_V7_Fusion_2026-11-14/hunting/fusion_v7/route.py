"""No-agent-execution analysis and skill selection, using real project models."""
from __future__ import annotations
import json
from pathlib import Path

NATIVE = {
 'auth': ['login-security-testing','oauth-oidc-testing','jwt-testing','v7-session-lifecycle'],
 'authorization':['authz-access-control-tester','idor-testing','v7-cross-tenant-matrix'],
 'api':['endpoint-triage','api-security-testing','v7-shadow-api-inventory'],
 'graphql':['graphql-testing','v7-fintech-graphql-integrity'],
 'client':['js-deep-analysis','js-secret-and-api-review'],
 'business':['business-logic-testing','v7-state-transition-integrity'],
 'framework':['tech-fingerprint','v7-framework-risk-triage'],
 'grpc':['v7-grpc-review','api-security-testing'],
 'rag':['llm-ai-security-testing','v7-rag-integrity'],
 'cicd':['v7-ci-cd-trust-review'],
 'redirect':['ssrf-redirect-url-testing'],
 'file':['file-upload-testing'],
}
CBH = {
 'auth':['cbh-hunt-session','cbh-hunt-oauth','cbh-hunt-mfa-bypass'],
 'authorization':['cbh-hunt-idor','cbh-hunt-auth-bypass'],
 'api':['cbh-hunt-shadow-api','cbh-hunt-api-misconfig'],
 'graphql':['cbh-hunt-graphql','cbh-hunt-fintech-graphql'],
 'client':['cbh-hunt-dom','cbh-hunt-source-leak','cbh-hunt-spa-api'],
 'business':['cbh-hunt-business-logic','cbh-hunt-race-condition'],
 'framework':['cbh-hunt-nextjs','cbh-hunt-laravel','cbh-hunt-springboot'],
 'grpc':['cbh-hunt-grpc'],
 'rag':['cbh-hunt-rag-vector'],
 'cicd':['cbh-hunt-cicd'],
 'redirect':['cbh-hunt-open-redirect','cbh-hunt-ssrf'],
 'file':['cbh-hunt-file-upload'],
}

def configured_models(project):
    project=Path(project)
    config=json.loads((project/'hunting/opencode.json').read_text(encoding='utf-8'))
    # Both 'agent' and 'agents' may be present due to historical config migrations.
    # Never silently pretend that these duplicates are guaranteed to resolve identically.
    a=config.get('agent',{})
    legacy=config.get('agents',{})
    names=sorted(set(a)|set(legacy))
    return {name:{'agent_model':a.get(name,{}).get('model'),
                  'agents_model':legacy.get(name,{}).get('model'),
                  'conflict':bool(a.get(name,{}).get('model') and legacy.get(name,{}).get('model') and a[name]['model']!=legacy[name]['model'])}
            for name in names}

def route_one(item,registry):
    known=set(registry['skills'])
    classes=item.get('classes',[])
    result=[]
    # Native skills first, at most three per case. Vendors only when a related
    # specialty has demonstrable relevance; no massive context injection.
    for cls in classes:
        for sk in NATIVE.get(cls,[]):
            if sk in known and sk not in result:result.append(sk)
    native=result[:3]
    vendor=[]
    for cls in classes:
        for sk in CBH.get(cls,[]):
            if sk in known and sk not in vendor:vendor.append(sk)
    agent=('js-agent' if 'client' in classes else
           'understand-agent' if set(classes)&{'auth','authorization','business','graphql','rag'} else
           'dorking-agent' if item.get('provenance_type')=='osint' else 'recon-agent')
    importance={'authorization':6,'auth':5,'business':5,'graphql':4,'rag':4,'cicd':3,'grpc':3,'api':2,'client':2,'framework':1}
    priority=max([importance.get(c,1) for c in classes] or [1])
    return {'surface_id':item['id'],'suggested_agent':agent,'investigation_priority_1_to_6':priority,'native_skills':native,
            'supplemental_vendor_skills':vendor[:2],
            'action':'READ_ONLY_ANALYSIS_PLAN','active_testing_approved':False,
            'reason':'Suggested by observed metadata; must pass actual authorization and human review.'}

def route_all(surface,registry):
    return {'network_requests':0,'planned':len(surface.get('items',[])),
            'plans':[route_one(x,registry) for x in surface.get('items',[])]}
