"""Redacted offline attack-surface map from JSONL/HAR observations.

No request or response headers, bodies, cookies, URL values, raw URLs, user IDs,
credentials or tokens are persisted. Returned records are hypotheses only.
"""
from __future__ import annotations
import collections
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import parse_qsl
from .scope import Policy, parse_url, ScopeError

UUID = re.compile(r'^[0-9a-f]{8}-[0-9a-f-]{16,}$',re.I)
NUM = re.compile(r'^\d{2,}$')
HEX = re.compile(r'^[0-9a-f]{20,}$',re.I)
B64 = re.compile(r'^[A-Za-z0-9_-]{25,}$')
KEY = re.compile(r'^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$')
CLASSES = {
 'auth': ('login','oauth','sso','signin','callback','session','reset','mfa'),
 'authorization': ('users','accounts','teams','tenants','projects','organizations','roles','permissions','members'),
 'api': ('api','graphql','rest','v1','v2','v3'),
 'graphql': ('graphql',),
 'client': ('.js','.map','webpack','assets','static'),
 'business': ('billing','checkout','order','invite','transfer','wallet','coupon','subscription'),
 'framework': ('_next','actuator','telescope','horizon','laravel','spring'),
 'grpc': ('grpc','reflection'),
 'rag': ('vectors','embedding','rag','search-index'),
 'cicd': ('pipeline','ci','artifact','build','workflow'),
}
PARAM_CLASS = {
 'redirect': ('redirect','next','return','callback','url','returnto'),
 'authorization': ('user_id','account_id','tenant_id','org_id','project_id','owner_id'),
 'file': ('filename','file','upload','path'),
}

def classify(template,keys):
    lower=template.lower(); names={k.lower() for k in keys}
    classes={c for c,hints in CLASSES.items() if any(h in lower for h in hints)}
    classes.update(c for c,hints in PARAM_CLASS.items() if any(k in names for k in hints))
    return sorted(classes or {'api'})

def normalized(url, method):
    host,path,port,u=parse_url(url)
    sensitive_parents={'users','user','accounts','account','projects','project','orders','order',
                       'invites','invite','members','member','payments','payment','tokens','token',
                       'reset','docs','documents','files','customers','customer','profiles','profile'}
    parts=[]
    for i,segment in enumerate(path.split('/')):
        parent=path.split('/')[i-1].lower() if i else ''
        mask=(UUID.fullmatch(segment) or NUM.fullmatch(segment) or HEX.fullmatch(segment) or
              B64.fullmatch(segment) or (parent in sensitive_parents and segment not in ('','me','self')))
        parts.append('{resource-id}' if mask else segment)
    path='/'.join(parts)
    scheme=u.scheme
    # All approved ports are 80 or 443; retaining explicit nondefault ports is unnecessary.
    keys=sorted({k for k,_ in parse_qsl(u.query,keep_blank_values=True,max_num_fields=300) if KEY.fullmatch(k)})
    template=f'{scheme}://{host}{path}'
    signature=f'{method.upper()}|{template}|{",".join(keys)}'
    return hashlib.sha256(signature.encode()).hexdigest()[:24],dict(method=method.upper(),host=host,path=path,
                       url_template=template,parameter_names=keys,
                       classes=classify(path,keys),status='HYPOTHESIS_ONLY',security_impact_proven=False)

def load_observations(path):
    path=Path(path)
    if path.stat().st_size>30_000_000:raise ValueError('Input exceeds offline 30 MB safety limit')
    if path.suffix.lower()=='.har':
        obj=json.loads(path.read_text(encoding='utf-8'))
        return [{'url':e.get('request',{}).get('url'), 'method':e.get('request',{}).get('method','GET'),'source':'har'}
            for e in obj.get('log',{}).get('entries',[])][:20000]
    if path.suffix.lower()=='.jsonl':
        rows=[]
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                if line.strip():
                    if len(rows)>=20000:raise ValueError('Too many observations')
                    rows.append(json.loads(line))
        return rows
    raise ValueError('Only offline .jsonl and .har files supported')

def map_observations(rows, policy):
    if not isinstance(rows,list):raise TypeError('Observations must be a list')
    metrics=collections.Counter(); dedup={}
    for row in rows:
        metrics['input']+=1
        if not isinstance(row,dict) or not isinstance(row.get('url'),str):metrics['invalid']+=1;continue
        method=str(row.get('method','GET')).upper()
        allowed,reason=policy.check(row['url'],method)
        if not allowed:
            metrics['rejected']+=1;continue
        try:sid,item=normalized(row['url'],method)
        except (ValueError,ScopeError):metrics['invalid']+=1;continue
        if sid in dedup:
            metrics['duplicates']+=1;continue
        source=row.get('source','offline')
        item['provenance_type']=source if source in ('har','js','manual','osint','browser','burp','offline') else 'offline'
        item['id']=sid
        dedup[sid]=item
        metrics['accepted']+=1
    return {'schema_version':1,'policy_digest':hashlib.sha256(json.dumps(policy.data,sort_keys=True).encode()).hexdigest(),
            'network_requests':0,'metrics':dict(metrics),'items':sorted(dedup.values(),key=lambda x:(x['host'],x['path'],x['method']))}
