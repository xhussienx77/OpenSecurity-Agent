"""Deterministic offline allow/deny evaluation; no network access.

Do not confuse the result of this supplementary check with proof that the
program currently authorizes testing. Existing runtime_preflight is still the
binding gate before any live target interaction.
"""
from __future__ import annotations
import ipaddress
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

class ScopeError(ValueError):
    pass

NAME = re.compile(r"^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$", re.I)
METHOD = re.compile(r"^[A-Z]{3,12}$")
BAD_ENCODING = re.compile(r"%(?:2f|5c|00|2e|25|0a|0d)", re.I)

def parse_url(url: str):
    if not isinstance(url, str) or len(url) > 4096 or any(ord(c) < 32 for c in url):
        raise ScopeError("URL is invalid, oversized or contains controls")
    if '\\' in url or BAD_ENCODING.search(url):
        raise ScopeError("Ambiguous escaped path or URL")
    try:
        u = urlsplit(url)
        if u.scheme not in ("http", "https") or not u.hostname or u.username is not None or u.password is not None or u.fragment:
            raise ScopeError("Unsafe or incomplete HTTP URL")
        host = u.hostname.lower().rstrip('.')
        host.encode('ascii')
        if not NAME.fullmatch(host) or '..' in host or host.startswith('-') or any(p.startswith('-') or p.endswith('-') for p in host.split('.')):
            raise ScopeError("Invalid hostname")
        try: ipaddress.ip_address(host)
        except ValueError: pass
        else: raise ScopeError("IP literal requires separate reviewed policy")
        port = u.port or (443 if u.scheme == 'https' else 80)
        if port not in (80,443): raise ScopeError("Nonstandard port needs separate approval")
        path = u.path or '/'
        if not path.startswith('/') or '//' in path or any(s in ('.','..') for s in path.split('/')):
            raise ScopeError("Ambiguous URL path")
        return host, path, port, u
    except (ValueError, TypeError, OverflowError, UnicodeError) as exc:
        if isinstance(exc, ScopeError): raise
        raise ScopeError("Invalid URL") from exc

def match_host(host, pattern):
    if not isinstance(pattern, str):return False
    p = pattern.lower().rstrip('.')
    if p.startswith('*.'):
        domain=p[2:]
        return host.endswith('.'+domain) and host != domain
    return host == p

def match_path(path, prefix):
    if not isinstance(prefix,str) or not prefix.startswith('/'): return False
    if prefix=='/':return True
    prefix=prefix.rstrip('/')
    return path==prefix or path.startswith(prefix+'/')

class Policy:
    def __init__(self, data):
        if not isinstance(data, dict):raise ScopeError('Policy must be an object')
        self.data=data
        # Require separately verifiable authorization reference, not LLM assumptions.
        for key in ('allowed_hosts','excluded_hosts','allowed_paths','excluded_paths'):
            value=data.get(key,[])
            if not isinstance(value,list) or any(not isinstance(v,str) for v in value):raise ScopeError(f'{key} must be a string list')
        if not data.get('allowed_hosts'):raise ScopeError('No allowed hosts')
        for p in data['allowed_hosts'] + data.get('excluded_hosts',[]):
            domain=p[2:] if p.startswith('*.') else p
            if not NAME.fullmatch(domain) or '*' in domain or '..' in domain:
                raise ScopeError('Invalid host pattern: '+p[:40])
        for p in data.get('allowed_paths',[]) + data.get('excluded_paths',[]):
            if not p.startswith('/') or BAD_ENCODING.search(p) or '\\' in p or '..' in p.split('/'):
                raise ScopeError('Invalid path rule')
        self.confirmed = data.get('authorization_confirmed') is True and bool(data.get('policy_source'))
    @classmethod
    def load(cls, path):return cls(json.loads(Path(path).read_text(encoding='utf-8')))
    def check(self,url,method='GET',activity='offline'):
        try:host,path,port,u=parse_url(url)
        except ScopeError as exc:return False,'invalid_url:'+str(exc)
        if not self.confirmed:return False,'authorization_or_policy_source_unconfirmed'
        if not isinstance(method,str) or not METHOD.fullmatch(method.upper()):return False,'invalid_method'
        if any(match_host(host,p) for p in self.data.get('excluded_hosts',[])):
            return False,'host_explicitly_denied'
        if not any(match_host(host,p) for p in self.data['allowed_hosts']):return False,'host_not_allowed'
        if any(match_path(path,p) for p in self.data.get('excluded_paths',[])):
            return False,'path_explicitly_denied'
        allow_paths=self.data.get('allowed_paths',['/'])
        if not any(match_path(path,p) for p in allow_paths):return False,'path_not_allowed'
        if method.upper() not in [m.upper() for m in self.data.get('allowed_methods',['GET','HEAD'])]:
            return False,'method_not_approved'
        if activity!='offline':
            if self.data.get('active_testing_allowed') is not True or activity not in self.data.get('approved_activities',[]):
                return False,'active_activity_not_approved'
        return True,'within_recorded_policy_only_revalidate_before_network'
