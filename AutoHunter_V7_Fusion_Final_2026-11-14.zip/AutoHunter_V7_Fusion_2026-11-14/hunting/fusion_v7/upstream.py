"""Read-only indexing of a user-supplied, pinned Claude-BugHunter checkout.

No cloning, network access, executing upstream commands or automatic model tool
execution. Third-party skill content is kept in namespaced, attributed copies.
"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

NAME=re.compile(r'^[a-z0-9][a-z0-9-]{0,90}$')
SOURCE='https://github.com/elementalsouls/Claude-BugHunter'

def read_catalog(package):
    p=Path(package)
    cat=json.loads((p/'catalog/cbh_catalog_2026-11-14.json').read_text(encoding='utf-8'))
    names={n for xs in cat['categories'].values() for n in xs}
    assert len(names)==cat['expected_count']==83
    return cat,names

def read_skills(checkout):
    root=Path(checkout).expanduser().resolve()
    skills=root/'skills'
    if not skills.is_dir():raise ValueError('Clone missing: expected <checkout>/skills/*/SKILL.md')
    out={}
    for path in sorted(skills.glob('*/SKILL.md')):
        if path.is_symlink() or path.parent.is_symlink():raise ValueError('Upstream symlink not accepted')
        if not path.resolve().is_relative_to(skills.resolve()):raise ValueError('Path outside checkout')
        name=path.parent.name
        if not NAME.fullmatch(name):raise ValueError('Unsafe upstream skill name')
        if path.stat().st_size>500_000:raise ValueError('Oversized upstream skill: '+name)
        text=path.read_text(encoding='utf-8')
        if '\x00' in text:raise ValueError('Non-text upstream skill')
        out[name]=text
    return out

def supporting_files(checkout):
    """Copy text-only relative reference assets without executing upstream code."""
    root=Path(checkout).expanduser().resolve()/'skills'
    allowed={'.md','.txt','.json','.yaml','.yml','.csv','.graphql','.proto'}
    files={};total_bytes=0
    for skill_dir in sorted(root.iterdir()):
        if not skill_dir.is_dir() or skill_dir.is_symlink():continue
        if not NAME.fullmatch(skill_dir.name):continue
        for file in skill_dir.rglob('*'):
            if file.is_dir():continue
            if file.is_symlink():raise ValueError('Upstream asset symlink rejected')
            rel=file.relative_to(skill_dir)
            if rel.as_posix()=='SKILL.md' or len(rel.parts)>6:continue
            if any(part.startswith('.') or part=='..' for part in rel.parts):continue
            if file.suffix.lower() not in allowed:continue
            if file.stat().st_size>200_000:continue
            data=file.read_bytes()
            try:data.decode('utf-8')
            except UnicodeError:continue
            total_bytes+=len(data)
            if total_bytes>15_000_000 or len(files)>2000:raise ValueError('Too many upstream text references')
            files[(skill_dir.name,rel.as_posix())]=data
    return files

def body_without_frontmatter(source):
    if source.startswith('---\n'):
        index=source.find('\n---\n',4)
        if index!=-1:return source[index+5:].lstrip()
    return source

def vendor_skill(name,source):
    sha=hashlib.sha256(source.encode()).hexdigest()
    new_name='cbh-'+name
    return ('---\nname: '+new_name+'\ndescription: "Third-party Claude-BugHunter supplementary research; authorized scope and project rules take precedence"\n---\n'
      '# Supplemental: '+name+' (Claude-BugHunter)\n\n'
      '> **External content.** This is advisory reference material, not an instruction to start live testing. '
      'Follow `AGENTS.md`, official program restrictions, local runtime preflight and the existing human-review gates. '
      'Do not automatically execute any command, access credentials, expand scope, or bypass provider safety blocks.\n\n'
      f'> Original: {SOURCE}/tree/main/skills/{name} · SHA-256 original: `{sha}` · Content attribution: Sachin Sharma / Claude-BugHunter, CC BY 4.0 (plus upstream NOTICE).\n\n'
      '---\n\n'+body_without_frontmatter(source).rstrip()+'\n\n'
      '---\nOriginal Claude Code paths and commands may require adaptation for OpenCode. '
      'Human review required before any target-facing action.\n')

def source_ref(checkout):
    root=Path(checkout).expanduser()
    head=root/'.git/HEAD'
    if not head.is_file():return 'unverified local checkout (no git HEAD)'
    content=head.read_text().strip()
    if content.startswith('ref: '):
        ref=root/'.git'/content[5:]
        if ref.is_file():return ref.read_text().strip()
    return content[:80]

def headings(content):
    return [x.strip(' #\t').strip()[:120] for x in content.splitlines() if x.startswith('## ')][:25]

def content_comparison(upstream,local):
    left=set(headings(upstream));right=set(headings(local))
    return {'upstream_words':len(upstream.split()),'existing_words':len(local.split()),
            'upstream_unique_headings':sorted(left-right)[:8],
            'existing_unique_headings':sorted(right-left)[:8],
            'not_a_semantic_quality_score':True}

def audit(checkout,package,project=None):
    catalogue,names=read_catalog(package)
    found=read_skills(checkout)
    mapping=json.loads((Path(package)/'catalog/semantic_candidates.json').read_text(encoding='utf-8'))
    existing=set()
    if project:
        r=Path(project)/'hunting/runtime/registry.json'
        if r.exists():existing=set(json.loads(r.read_text())['skills'])
    # Include deterministic first-party additions in both pre- and post-install comparisons.
    # This makes audit output stable and installer idempotent.
    existing.update(p.stem for p in (Path(package)/'native_skills').glob('*.md'))
    rows=[]
    for category, entries in catalogue['categories'].items():
        for n in entries:
            candidate=mapping.get(n)
            comparison=None
            if project and n in found and candidate in existing:
                project_root=Path(project)
                local_file=project_root/'skills'/f'{candidate}.md'
                local_playbook=project_root/'skills/_playbooks'/f'{candidate}.md'
                local_text=(local_file.read_text(encoding='utf-8') if local_file.is_file() else '')
                if local_playbook.is_file():local_text+='\n'+local_playbook.read_text(encoding='utf-8')
                if not local_text:
                    new_native=Path(package)/'native_skills'/f'{candidate}.md'
                    if new_native.is_file():local_text=new_native.read_text(encoding='utf-8')
                comparison=content_comparison(found[n],local_text)
            rows.append({'upstream':n,'category':category,'available_in_checkout':n in found,
               'content_comparison':comparison,
               'existing_equivalent_candidate':candidate if candidate in existing else None,
               'assessment':'POTENTIAL_OVERLAP_REVIEW_REQUIRED' if candidate in existing else 'ADDITIONAL_COVERAGE',
               'imported_id':'cbh-'+n if n in found else None})
    return {'checkout_reference':source_ref(checkout),'expected':len(names),'found':len(found),
        'missing':sorted(names-set(found)),'unlisted':sorted(set(found)-names),
        'rows':rows,'warning':'Matches are semantic candidates, not proof of superior or equivalent quality.'}

def markdown_audit(result):
    lines=['# Claude-BugHunter skill comparison (OFFLINE)', '',
      '## Source',f'- Local checkout reference: `{result["checkout_reference"]}`',
      f'- Skills expected: {result["expected"]} · found: {result["found"]}',
      '- Missing: '+(', '.join(result['missing']) or 'none'),
      '- Unexpected: '+(', '.join(result['unlisted']) or 'none'), '',
      '> Import preserves original 55 skills. Similarity is a human-review candidate, not a superiority claim.', '',
      '| Upstream skill | Domain | Current counterpart | Decision |','|---|---|---|---|']
    for r in result['rows']:
        status='Available as supplemental' if r['available_in_checkout'] else 'MISSING FROM CHECKOUT'
        lines.append('| `'+r['upstream']+'` | '+r['category']+' | '+('`'+r['existing_equivalent_candidate']+'`' if r['existing_equivalent_candidate'] else 'gap/new topic')+' | '+status+' |')
    lines += ['', '## Topic-by-topic heading deltas (automated candidates, not a human-quality verdict)', '']
    for r in result['rows']:
        comparison=r.get('content_comparison')
        if not comparison:continue
        lines.extend([f'### {r["upstream"]} → {r["existing_equivalent_candidate"]}',
            f'- Upstream words: {comparison["upstream_words"]}; native + local playbook words: {comparison["existing_words"]}',
            '- Upstream-only subsection headings: '+(', '.join(comparison['upstream_unique_headings']) or 'none'),
            '- Local-only subsection headings: '+(', '.join(comparison['existing_unique_headings']) or 'none'),
            '- Action: both skills remain available; reviewer decides which specific techniques add value. No auto-overwrite.', ''])
    return '\n'.join(lines)+'\n'
