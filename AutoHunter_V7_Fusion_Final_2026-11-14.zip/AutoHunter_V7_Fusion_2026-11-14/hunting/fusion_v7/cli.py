"""Offline operator CLI: policy, surface, route, report, model inventory, benchmark."""
import argparse,json,pathlib,sys
from .scope import Policy
from .surface import load_observations,map_observations
from .route import configured_models,route_all
from .report import evaluate,render
from .eval import score
from .policy_draft import draft

def load(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8'))
def write(out,data):
    if out:
        p=pathlib.Path(out);p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(data if isinstance(data,str) else json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print('WROTE:',p)
    else:print(data if isinstance(data,str) else json.dumps(data,indent=2,ensure_ascii=False))

def main(argv=None):
    ap=argparse.ArgumentParser(description='AutoHunter V7 Fusion - OFFLINE ONLY')
    sub=ap.add_subparsers(dest='action',required=True)
    a=sub.add_parser('scope');a.add_argument('--policy',required=True);a.add_argument('--url',required=True);a.add_argument('--method',default='GET')
    a=sub.add_parser('surface');a.add_argument('--policy',required=True);a.add_argument('--input',required=True);a.add_argument('--output')
    a=sub.add_parser('route');a.add_argument('--registry',required=True);a.add_argument('--surface',required=True);a.add_argument('--output')
    a=sub.add_parser('report');a.add_argument('--finding',required=True);a.add_argument('--platform',default='generic');a.add_argument('--output')
    a=sub.add_parser('models');a.add_argument('--project',required=True)
    a=sub.add_parser('benchmark');a.add_argument('--cases',required=True);a.add_argument('--output')
    a=sub.add_parser('policy-draft');a.add_argument('--brief',required=True);a.add_argument('--output')
    x=ap.parse_args(argv)
    try:
        if x.action=='scope':
            ok,reason=Policy.load(x.policy).check(x.url,x.method);write(None,{'allowed':ok,'reason':reason,'network_requests':0});return 0 if ok else 2
        if x.action=='surface':write(x.output,map_observations(load_observations(x.input),Policy.load(x.policy)))
        elif x.action=='route':write(x.output,route_all(load(x.surface),load(x.registry)))
        elif x.action=='report':
            f=load(x.finding);v=evaluate(f);write(x.output,render(f,x.platform))
            if not v['approved_for_draft']:return 3
        elif x.action=='models':write(None,configured_models(x.project))
        elif x.action=='benchmark':write(x.output,score(load(x.cases)))
        elif x.action=='policy-draft':write(x.output,draft(pathlib.Path(x.brief).read_text(encoding='utf-8')))
        return 0
    except (OSError,TypeError,ValueError,KeyError,json.JSONDecodeError) as e:
        print('BLOCKED:',type(e).__name__,str(e)[:200],file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
