"""Offline benchmark metrics; no claims about real findings or real hunts."""
from collections import Counter

def score(cases):
    if not isinstance(cases,list):raise ValueError('Benchmark cases must be a list')
    states=Counter()
    allowed=0; attempted=0; confirmed=0
    for case in cases:
        if not isinstance(case,dict):continue
        states[str(case.get('state','UNCLASSIFIED'))]+=1
        if case.get('in_scope') is True:allowed+=1
        if case.get('tested') is True:attempted+=1
        if case.get('confirmed') is True and case.get('impact_evidence_verified') is True:confirmed+=1
    return {'sample_size':len(cases),'in_scope':allowed,'tested':attempted,
            'confirmed_with_evidence':confirmed,'states':dict(states),
            'coverage_fraction':round(attempted/allowed,4) if allowed else None,
            'note':'These are labels from the supplied offline fixture, not independently verified live vulnerabilities.',
            'network_requests':0}
