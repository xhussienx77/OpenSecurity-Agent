"""AutoHunter V7 Fusion: safe local-only intelligence helpers.

These modules intentionally contain no HTTP clients, shell commands, model API
calls, Burp bridge, agent dispatcher or active testing implementation.
"""
__version__ = "7.0.0-fusion"
