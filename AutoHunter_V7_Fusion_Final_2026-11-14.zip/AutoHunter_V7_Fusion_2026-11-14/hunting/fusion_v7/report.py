"""Human-approval report gate; no submissions, exploitation or network access."""
from __future__ import annotations
import json
import re
from pathlib import Path

REQUIRED=['exact_scope_verified','program_policy_verified','original_observation','security_impact_demonstrated','owned_account_or_data_only','reproduced_independently','false_positives_challenged']
SECRET=re.compile(r'(?i)((?:password|token|secret|cookie|api.?key|authorization)\s*[:=]\s*)[^\s,;]+')
URL_SECRET=re.compile(r'(?i)([?&](?:token|code|api_key|access_token|session|jwt|key)=)[^&\s]+')

def scrub(text):
    text=str(text)
    text=re.sub(r'(?i)(authorization\s*:\s*(?:bearer|basic)\s+)\S+',r'\1[REDACTED]',text)
    text=SECRET.sub(lambda m:m.group(1)+'[REDACTED]',text)
    return URL_SECRET.sub(r'\1[REDACTED]',text)[:15000]

def evaluate(finding):
    if not isinstance(finding,dict):raise ValueError('Finding must be a JSON object')
    gates=finding.get('gates',{})
    passed={k:gates.get(k) is True for k in REQUIRED}
    issues=[k for k,v in passed.items() if not v]
    for name in ['title','asset','role','observed_behavior','expected_behavior','impact','reproduction_steps','evidence_refs','remediation']:
        val=finding.get(name)
        if not val or val in ('unknown','TBD','TODO','N/A','[REDACTED]'):issues.append(name)
    refs=finding.get('evidence_refs')
    if not isinstance(refs,list) or not refs or any(not isinstance(v,str) or not v.startswith('evidence/') or '..' in v or '\\' in v for v in refs):
        issues.append('evidence_refs_must_be_local_safe_paths')
    if finding.get('state')!='CONFIRMED':issues.append('state_not_confirmed')
    if finding.get('human_reviewed') is not True:issues.append('needs_human_review')
    if finding.get('submitted') is True:issues.append('already_submitted')
    if not isinstance(finding.get('reproduction_steps'),list) or len(finding.get('reproduction_steps',[]))<2:
        issues.append('reproduction_steps_incomplete')
    return {'approved_for_draft':not issues,'reasons':sorted(set(issues)),'gate_results':passed,
            'not_a_submission':True,'network_requests':0}

def render(finding,platform='generic'):
    gate=evaluate(finding)
    if not gate['approved_for_draft']:
        return '# Not ready to report\n\nMissing gates: '+', '.join(gate['reasons'])+'\n'
    if platform not in ('generic','hackerone','bugcrowd','intigriti'):
        raise ValueError('Unsupported reporting platform')
    f=lambda name:scrub(finding.get(name,''))
    title='# '+f('title')+'\n\n'
    head=(f'**Asset:** {f("asset")}  \n**Test role:** {f("role")}  \n'
          f'**Platform:** {platform}  \n**State:** CONFIRMED (human reviewed)\n\n')
    steps='\n'.join(f'{i}. {scrub(step)}' for i,step in enumerate(finding['reproduction_steps'],1))
    evidence='\n'.join('- '+scrub(x) for x in finding['evidence_refs'])
    return (title+head+'## Summary\n'+f('observed_behavior')+'\n\n'
       +'## Expected behavior\n'+f('expected_behavior')+'\n\n'
       +'## Security impact\n'+f('impact')+'\n\n'
       +'## Steps to reproduce (authorized test accounts only)\n'+steps+'\n\n'
       +'## Evidence references (attach locally after redaction)\n'+evidence+'\n\n'
       +'## Recommended remediation\n'+f('remediation')+'\n\n'
       +'## Disclosure checks\nHuman-reviewed; verify program acceptance and avoid duplicate submission.\n')
