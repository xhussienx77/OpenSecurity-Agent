"""Synthetic local upstream install. Nothing from GitHub is executed."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from hunt_patch import harden_hunt

class InstallTests(unittest.TestCase):
    def make_fixture(self,tmp):
        p=pathlib.Path(tmp)/'project'
        p.joinpath('hunting/runtime').mkdir(parents=True)
        p.joinpath('hunting/.opencode/commands').mkdir(parents=True)
        p.joinpath('skills').mkdir(parents=True)
        p.joinpath('hunting/runtime/registry.json').write_text(json.dumps({'skills':{
          'master-bugbounty-rules':{'path':'.agents/skills/master-bugbounty-rules/SKILL.md','mirror':'skills/master-bugbounty-rules.md','triggers':['foundation']}}}))
        p.joinpath('hunting/opencode.json').write_text(json.dumps({'model':'deepseek/test','agent':{'build':{'model':'deepseek/test'}}}))
        hunt='---\ndescription: test\nagent: build\n---\n\n## Step 0B: Owned-Account Login\nOpen the mail inbox\n- The agent HAS full access to this inbox\n\n## Hunt Start Contract\n'
        p.joinpath('hunting/.opencode/commands/hunt.md').write_text(hunt)
        p.joinpath('skills/master-bugbounty-rules.md').write_text('---\nname: master-bugbounty-rules\n---\nKEEP ORIGINAL')
        upstream=pathlib.Path(tmp)/'upstream'
        cat=json.loads((ROOT/'catalog/cbh_catalog_2026-11-14.json').read_text())
        for n in [n for group in cat['categories'].values() for n in group]:
            f=upstream/'skills'/n/'SKILL.md';f.parent.mkdir(parents=True,exist_ok=True)
            f.write_text('---\nname: '+n+'\n---\n# '+n+'\nSynthetic test pattern\n')
        ref=upstream/'skills/hunt-grpc/references/protocol.md'
        ref.parent.mkdir(parents=True,exist_ok=True)
        ref.write_text('# Synthetic reference only')
        return p,upstream
    def run_install(self,p,u,*args):
        return subprocess.run([sys.executable,str(ROOT/'install.py'),'--project',str(p),'--source-checkout',str(u),*args],capture_output=True,text=True)
    def test_dry_apply_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,u=self.make_fixture(tmp)
            origin=(p/'skills/master-bugbounty-rules.md').read_bytes()
            cfg=(p/'hunting/opencode.json').read_bytes()
            first=self.run_install(p,u)
            self.assertEqual(first.returncode,0,first.stderr)
            self.assertFalse((p/'skills/v7-grpc-review.md').exists())
            apply=self.run_install(p,u,'--apply')
            self.assertEqual(apply.returncode,0,apply.stderr)
            reg=json.loads((p/'hunting/runtime/registry.json').read_text())
            self.assertEqual(len(reg['skills']),94)
            self.assertEqual((p/'skills/master-bugbounty-rules.md').read_bytes(),origin)
            self.assertEqual((p/'hunting/opencode.json').read_bytes(),cfg)
            h=(p/'hunting/.opencode/commands/hunt.md').read_text()
            self.assertNotIn('The agent HAS full access',h)
            self.assertIn('Open the mail inbox only after explicit human confirmation',h)
            self.assertEqual(self.run_install(p,u).returncode,0)
            again=self.run_install(p,u,'--apply')
            self.assertEqual(again.returncode,0,again.stderr)
            self.assertIn('ALREADY INSTALLED',again.stdout)
            self.assertTrue((p/'hunting/docs/fusion-v7/UPSTREAM_SKILL_COMPARISON.md').exists())
            self.assertTrue((p/'hunting/.agents/skills/cbh-hunt-grpc/references/protocol.md').exists())
    def test_missing_upstream_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,u=self.make_fixture(tmp)
            bad=self.run_install(p,pathlib.Path(tmp)/'nonexistent')
            self.assertNotEqual(bad.returncode,0)
            self.assertFalse((p/'skills/v7-grpc-review.md').exists())
    def test_text_patch_twice(self):
        t='## Step 0B: Owned-Account Login\nDO NOT read creds\n## Hunt Start Contract\n'
        self.assertEqual(harden_hunt(harden_hunt(t)),harden_hunt(t))

if __name__=='__main__':unittest.main()
