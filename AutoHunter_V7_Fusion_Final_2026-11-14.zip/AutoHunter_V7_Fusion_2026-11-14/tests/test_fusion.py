"""Local-only deterministic tests. Requires no network or external packages."""
import json
import pathlib
import sys
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'hunting'))
from fusion_v7.scope import Policy,ScopeError,parse_url
from fusion_v7.surface import map_observations,normalized,load_observations
from fusion_v7.route import route_all
from fusion_v7.report import evaluate,render,scrub
from fusion_v7.eval import score
from fusion_v7.policy_draft import draft
from fusion_v7.upstream import read_catalog,vendor_skill

class Suite(unittest.TestCase):
    def setUp(self):
        self.pol=Policy({'authorization_confirmed':True,'policy_source':'operator-verified-official-program-url',
            'allowed_hosts':['api.example.test','*.example.org'],'excluded_hosts':['private.example.org'],
            'excluded_paths':['/admin'],'allowed_paths':['/api','/open'],
            'allowed_methods':['GET','HEAD'],'active_testing_allowed':False})
    def test_exact_host(self):
        self.assertTrue(self.pol.check('https://api.example.test/api/a')[0])
        self.assertFalse(self.pol.check('https://evilapi.example.test/api/a')[0])
    def test_wildcard(self):
        self.assertTrue(self.pol.check('https://a.example.org/api/a')[0])
        self.assertFalse(self.pol.check('https://example.org/api/a')[0])
        self.assertFalse(self.pol.check('https://private.example.org/api/a')[0])
        self.assertFalse(self.pol.check('https://other-example.org/api/a')[0])
    def test_path_and_method(self):
        self.assertFalse(self.pol.check('https://api.example.test/api-evil')[0])
        self.assertFalse(self.pol.check('https://api.example.test/admin')[0])
        self.assertFalse(self.pol.check('https://api.example.test/api/a','POST')[0])
        self.assertFalse(self.pol.check('https://api.example.test/api/a','GET','fuzz')[0])
    def test_ambiguous_rejected(self):
        for url in ['https://api.example.test/api/../admin','https://api.example.test/api/%2e%2e/admin',
                    'https://api.example.test/api/%2fadmin','https://evil@api.example.test/api/',
                    'https://api.example.test/api/#fragment','https://api.example.test:8080/api/',
                    'https://api.example.test/api//other']:
            with self.subTest(url=url):self.assertFalse(self.pol.check(url)[0])
    def test_default_deny(self):
        p=Policy({'allowed_hosts':['api.example.test']})
        self.assertFalse(p.check('https://api.example.test/api/')[0])
    def test_secret_redaction_inventory(self):
        url1='https://api.example.test/api/users/alice?token=SECRET_ALPHA&filter=on'
        url2='https://api.example.test/api/users/bob?token=SECRET_BETA&filter=off'
        mapped=map_observations([{'url':url1,'source':'har'},{'url':url2,'source':'har'}],self.pol)
        s=json.dumps(mapped)
        self.assertEqual(mapped['metrics']['duplicates'],1)
        self.assertIn('{resource-id}',s)
        for secret in ['SECRET_ALPHA','SECRET_BETA','alice','bob']:
            self.assertNotIn(secret,s)
        self.assertEqual(mapped['network_requests'],0)
    def test_out_of_scope_not_persisted(self):
        mapped=map_observations([{'url':'https://unowned.example.net/api/me'}],self.pol)
        self.assertEqual(mapped['metrics']['rejected'],1)
        self.assertEqual(mapped['items'],[])
    def test_har_local(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'fixture.har'
            p.write_text(json.dumps({'log':{'entries':[{'request':{'url':'https://api.example.test/api/v1','method':'GET','headers':[{'name':'Authorization','value':'Bearer DONTSTORE'}]}}]}}))
            rows=load_observations(p)
            self.assertNotIn('DONTSTORE',json.dumps(rows))
    def test_routing(self):
        surf=map_observations([{'url':'https://api.example.test/api/users/12345'}],self.pol)
        registry={'skills':{n:{} for n in ['idor-testing','authz-access-control-tester','endpoint-triage','cbh-hunt-idor','v7-cross-tenant-matrix']}}
        result=route_all(surf,registry)
        self.assertEqual(result['plans'][0]['suggested_agent'],'understand-agent')
        self.assertIn('cbh-hunt-idor',result['plans'][0]['supplemental_vendor_skills'])
        self.assertFalse(result['plans'][0]['active_testing_approved'])
    def test_report_blocks_observation(self):
        f=json.loads((ROOT/'examples/finding.example.json').read_text())
        self.assertFalse(evaluate(f)['approved_for_draft'])
        self.assertIn('Not ready to report',render(f))
    def test_report_with_all_gates(self):
        f=json.loads((ROOT/'examples/finding.example.json').read_text())
        f.update(state='CONFIRMED',human_reviewed=True,impact='Proof of impact on an authorized own-account fixture')
        for k in f['gates']:f['gates'][k]=True
        self.assertTrue(evaluate(f)['approved_for_draft'])
        self.assertIn('Security impact',render(f,'intigriti'))
        self.assertIn('# Unproven authorization hypothesis',render(f,'intigriti'))
    def test_redaction(self):
        self.assertNotIn('SECRETTOKEN',scrub('authorization: Bearer SECRETTOKEN'))
        self.assertNotIn('FOO',scrub('https://site.example/?token=FOO'))
    def test_eval(self):
        d=score([{'in_scope':True,'tested':True,'state':'BLOCKED'}, {'in_scope':True,'tested':False,'state':'PENDING'}])
        self.assertEqual(d['coverage_fraction'],.5)
    def test_catalog_count(self):
        c,names=read_catalog(ROOT)
        self.assertEqual(len(names),83)
        self.assertEqual(len(c['categories']['web']),58)
    def test_policy_draft_never_authorizes(self):
        p=draft('In scope: api.company.test. Out of scope: internal.company.test')
        self.assertEqual(p['allowed_hosts'],[])
        self.assertFalse(p['authorization_confirmed'])
        self.assertEqual(len(p['unverified_domain_mentions']),2)
    def test_vendor_attribute(self):
        x=vendor_skill('hunt-grpc','---\nname: hunt-grpc\n---\n## Protocol checks\n')
        self.assertIn('name: cbh-hunt-grpc',x)
        self.assertIn('CC BY 4.0',x)
        self.assertIn('## Protocol checks',x)

if __name__=='__main__':unittest.main()
