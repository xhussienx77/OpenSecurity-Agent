# AutoHunter V7 Fusion — offline, additive upgrade

**Scope:** Review/augment the user's existing OpenCode/AutoHunter project with deterministic, local-only planning, scope assessment, inventory, specialist-routing suggestions, gated reporting, benchmark tools, and an **attributed, namespaced import** of Claude-BugHunter's actual skills from a locally cloned source repository. NOT a replacement for the user's original project, a vulnerability guarantee, or a standalone live autonomous hunter.

## What this release deliberately does not do

- No Burp Live Adapter and no Automatic Agent Dispatch.
- No network requests, browser automation, scanning, exploitation, credential access, automatic report submission or background jobs.
- No changes to `hunting/opencode.json`, original 55 canonical skill bodies, original `.agents` mirrors, original `hunt_state.py`, existing report code, learning engine, or any live target data.
- No attempt to bypass model safety restrictions or provider refusals.

## Core compatibility decisions

- Preserve the existing six task/agent roles and optional reviewers; **do not enforce old model assignments**. This project snapshot currently has `deepseek/deepseek-v4-pro` for `build` and some specialists, unlike older discussions. Use OpenCode `debug config` to verify effective runtime model resolution.
- Keep the original 55 named skills byte-for-byte unchanged so legacy `skillctl.py check` still expects 55.
- Add 10 original V7 capability guides with canonical `skills/v7-*.md` and mirrored `hunting/.agents/skills/v7-*/SKILL.md` paths, registered in the existing `runtime/registry.json`.
- Import *all* 83 actual upstream skill bodies and eligible text-only per-skill supporting reference files into `cbh-*` namespaced canonical+mirror paths at installation time, only if checkout has exact expected catalog coverage. This ZIP **does not embed the third-party files**, because the full source checkout was not attached in this chat; the installer reads them directly from your existing `~/bugbounty/Claude-BugHunter-reference` clone.
- Attribution and license notices are copied from the upstream checkout. Full source content remains available as supplemental technique references, not automatic replacements for native 55 skills.
- Existing `/hunt` command keeps its preflight/agent-routing/state controls, receives tightly scoped textual hardening (unsafe credential-inbox and unconditional testing assumptions), and gains a bounded Fusion appendix. The original file is backed up.

## Install on Kali — from an existing source checkout

```bash
cd ~/bugbounty
# If the clone already exists, do not clone it again.
[ -d Claude-BugHunter-reference/skills ] || git clone https://github.com/elementalsouls/Claude-BugHunter.git Claude-BugHunter-reference
# Unzip this package into ~/Downloads
python3 ~/Downloads/AutoHunter_V7_Fusion_2026-11-14/install.py \
  --project ~/bugbounty \
  --source-checkout ~/bugbounty/Claude-BugHunter-reference
# Review the dry-run. Only when comfortable:
python3 ~/Downloads/AutoHunter_V7_Fusion_2026-11-14/install.py \
  --project ~/bugbounty \
  --source-checkout ~/bugbounty/Claude-BugHunter-reference --apply
```

The installer fails closed if the upstream source isn't there or does not contain the 83 skills in the documented catalog. The user can explicitly opt into native-only installation via `--no-vendor`, but that is **not** a complete 83-skill integration. No third-party installer, shell script, workflow or Python module from the cloned repository is ever run.

## Mandatory local validation

```bash
cd ~/bugbounty
python3 hunting/scripts/skill_registry.py check
python3 skills/_tools/skillctl.py check
python3 -m compileall -q hunting/fusion_v7
cd hunting
python3 -m fusion_v7.cli models --project ..
python3 -m fusion_v7.cli scope --policy ../Downloads/your-verified-program-policy.json --url 'https://your-exact-in-scope-host.example/'
opencode debug config   # verify actual model routing; do not assume printed historical config wins
```

Example policy has `authorization_confirmed: false` intentionally. Set it to true **only after independent verification of the program's current official scope**, not as a convenience switch.

## Offline workflow

```bash
cd ~/bugbounty/hunting
python3 -m fusion_v7.cli surface --policy /path/to/verified-program-policy.json --input /path/to/redacted-capture.jsonl --output /tmp/surface-plan.json
python3 -m fusion_v7.cli route --registry runtime/registry.json --surface /tmp/surface-plan.json --output /tmp/skill-plan.json
python3 -m fusion_v7.cli report --finding /path/to/reviewed-finding.json --platform bugcrowd --output /tmp/report-draft.md
python3 -m fusion_v7.cli benchmark --cases /path/to/lab-case-labels.json
```

No output from any command independently proves an exploitable flaw. A report is blocked unless all seven explicit gates, evidence references, original reproduction and human review are present. An external skill pattern is only a candidate hypothesis.

## Recovery/rollback

Installer saves every **modified** file before applying changes under `hunting/backups/v7-fusion-YYYYmmddTHHMMSSZ/` plus `INSTALL_MANIFEST.json` with SHA-256 fingerprints. It never deletes an existing file. To roll back, first stop OpenCode, then restore backup copies of `runtime/registry.json` and `.opencode/commands/hunt.md`. Newly introduced `v7-*` and `cbh-*` files can be removed by comparing their hashes against the manifest; do not blindly delete any file edited since installation. Leave project testing/evidence/session artifacts untouched.

## Upstream attribution

Upstream: https://github.com/elementalsouls/Claude-BugHunter by Sachin Sharma, source and docs accessed 2026-11-14. Upstream code: MIT; methodology content: CC BY 4.0 (review exact upstream LICENSE, LICENSE-CONTENT and NOTICE copied from your checkout). This package's original new files are authored independently; its third-party copies remain attributed derivatives. Consult `hunting/docs/fusion-v7/UPSTREAM_SKILL_COMPARISON.md` generated during installation for every upstream skill and overlap candidates.

## Honest validation status

Unit and simulated-install tests verify local deterministic behavior, plus older project test suites on the sanitized provided snapshot. They do **not** prove production bug-finding performance or a zero-defect guarantee; OpenCode + MCP + real program rules still need system-level confirmation on Kali.

### Optional policy-text extraction (UNVERIFIED)

`python3 -m fusion_v7.cli policy-draft --brief /path/to/program-brief.txt --output /tmp/unverified-policy.json`

This produces **zero authorized hosts** and `authorization_confirmed: false`; a human must check the current official program rules and explicitly fill the allowlist. It is a convenience for reviewing long briefs, not automated authorization.
