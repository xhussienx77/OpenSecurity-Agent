"""Narrow, idempotent repair of documented old /hunt command contradictions."""

def harden_hunt(command):
    command = command.replace(
        '**Browser mandate: ALWAYS use MCP (chrome-devtools-mcp) + Chrome DevTools together for every browser interaction. Never use one without the other.**',
        '**Browser boundary:** Use the configured Chrome DevTools MCP for browser work only when connected and after mandatory preflight. If unavailable, record the blocker and continue only with permitted offline analysis. Never substitute an unapproved browser session.')
    command = command.replace(
        '**Exploit-first mandate:** The objective is a reproducible, high-impact vulnerability. Recon, OSINT, JS analysis, and fuzzing are bounded support work. Once a usable surface exists, resolve its skills and test it immediately; do not wait for a complete inventory or spend the session collecting data without an exploit attempt.',
        '**Evidence-first mandate:** Prioritize high-impact, realistically testable authorization and business-logic hypotheses. Run a bounded, non-destructive verification only after exact-scope and program-policy checks. Never manufacture a vulnerability merely to fill a report.')
    start = command.find('## Step 0B: Owned-Account Login')
    end = command.find('## Hunt Start Contract', start)
    if start != -1 and end != -1:
        safe = """## Step 0B: Optional Authorized Test-Account Login — AFTER STEP 0A

1. Authentication is NOT a prerequisite for unrelated unauthenticated analysis. Use only permitted, researcher-owned test accounts and an approved browser profile.
2. **Open the mail inbox only after explicit human confirmation**, and only when an approved auth flow requires it. Never presume mailbox access or that `login.md` contains reusable credentials.
3. Ask the user to perform or approve sign-in interactively; reuse an existing approved session when allowed. Do not read, save, log, copy or transmit passwords, session cookies, API keys, OTPs, magic links or reset tokens in files or model messages.
4. If login/inbox access is unavailable, record a BLOCKED authenticated task and proceed solely with independently permitted unauthenticated or offline work.
5. Scope preflight, human approval and program policy remain authoritative for every target-facing request.

"""
        command = command[:start]+safe+command[end:]
    command = command.replace('Capture a baseline and execute the first safe controlled exploit variant.',
          'Capture a baseline and, only when policy-authorized, execute one bounded non-destructive verification with an owned-account negative control.')
    command = command.replace('- Do NOT write PoCs or formal reports — wait for explicit user instruction',
          '- Produce a **human-reviewable draft** only for a genuinely CONFIRMED finding satisfying all scope, impact, reproducibility, privacy and false-positive gates. Never auto-submit. For unproven leads, produce an evidence-gap summary, not a vulnerability report.')
    command = command.replace('**For ALL types, fuzz for exposed `.md` files:',
          '**Only if expressly allowed by the program, consider narrow checks for exposed `.md` files:')
    command = command.replace('**AI/LLM apps: always fuzz for',
          '**AI/LLM apps: document candidates offline first; request only if explicitly allowed for')
    return command
