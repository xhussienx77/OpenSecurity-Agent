---
name: v7-fintech-graphql-integrity
description: "Financial GraphQL authorization and accounting integrity; extra V7 offline/authorized guidance"
---
# Financial GraphQL authorization and accounting integrity

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Preconditions
- Use synthetic balances or sandbox-only, reversible operations explicitly authorized by the program. Real-money transfers, redemptions and destructive writes must not be attempted merely to prove impact.
## Schema review
- Map queries and mutations to their owners, roles, input object identifiers, environment and fields that represent balances or entitlements.
- Trace input-to-state transitions and the authoritative ledger versus UI/cache projections; do not interpret a calculated display mismatch as a payment vulnerability.
## Hypotheses
- Read-side cross-account object binding, inconsistent mutation access-control, precision/rounding at display boundaries, replay/idempotency assumptions, inconsistent role checks between GraphQL aliases and REST twins.
## Validation gate
- Prefer local mocks, program-provided sandboxes, or permissioned test accounts and non-monetary fixtures. Require before/after evidence for **your own** disposable objects.
- If reproduction needs money movement, another customer account, state corruption, or concurrency stress, mark BLOCKED and request program guidance.
## Report
- Separate observed server response from inferred ledger impact; specify the exact expected accounting invariant and safe remediation.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
