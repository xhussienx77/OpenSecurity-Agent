---
name: v7-grpc-review
description: "gRPC authentication and schema-boundary review; extra V7 offline/authorized guidance"
---
# gRPC authentication and schema-boundary review

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Inputs
Use permitted protobuf descriptors, client code, app logs and redacted captures; live service reflection requests are only allowed if program rules explicitly include the endpoint.
## Review plan
- Inventory service/method names, streaming versus unary behavior, required metadata, and which actor owns the referenced resources.
- Compare HTTP gateway and gRPC entry points for consistent authorization, resource access and validation expectations.
- Check integer/enum/default-field semantics in local fixtures; distinguish protobuf parser differences from security impact.
## Evidence
- Show a named method, owned-resource test scenario and matching authorized control. Never put live auth metadata or tokens in notebooks or model prompts.
- Missing reflection restriction or exposed schema alone is usually not a reportable security impact.
## Stop rules
No unlimited streaming, load, enumeration of unowned services, or production message mutation. Record what cannot be tested with the approved access level.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
