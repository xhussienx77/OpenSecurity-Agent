---
name: v7-shadow-api-inventory
description: "Historical and shadow API inventory; extra V7 offline/authorized guidance"
---
# Historical and shadow API inventory

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Goal
Identify redundant API versions, stale documentation and unowned interface surfaces from already authorized logs and source code, without guessing live hosts.
## Collection
- Inventory each service boundary, version prefix, route, method and auth requirement from redacted HAR, JavaScript, OpenAPI and approved internal docs.
- Associate source provenance and freshness (observed date, published schema version), not just filename strings.
## Analysis
- Group equivalent operations by resource semantics. Flag possible auth drift, schema differences and version confusion as **hypotheses**, never vulnerabilities.
- Compare public and authenticated documentation; note middleware differences as questions for reviewer.
## Safe checks
- First prove the old version exists from approved captures or public documentation. Only perform targeted, bounded requests when a fresh exact-target policy permits it.
- Never enumerate unlisted subdomains or revive disabled endpoints via unrestricted scanners.
## Output
- Version matrix, coverage denominator, uncertain resources and links to redacted evidence. Deprioritize endpoints that require unavailable test data rather than cycling requests.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
