---
name: v7-framework-risk-triage
description: "Framework-aware defensive triage; extra V7 offline/authorized guidance"
---
# Framework-aware defensive triage

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Objective
Use confirmed framework features to prioritize narrow inspection, never to assume that the presence of a framework or historic CVE proves exploitability.
## Next.js
- Separate static assets, SSR, RSC, middleware and Server Actions when reviewing observed routes. Compare expected auth guards across equivalent paths using local source/docs first.
## Spring Boot / Java
- Distinguish externally exposed management interfaces from deployment-only configuration. Check controller authorization and output serialization through provided artifacts before any authorized external request.
## Laravel / PHP
- Identify route groups, signed URL logic, debugging artifacts and queue/admin components from approved source and public metadata. Avoid active debug exploitation.
## ASP.NET / Node.js
- Note cookie/token auth placement, proxy trust, serializer behavior and deployment-specific middlewares.
## Evidence and stopping
- Record framework version only as an observation. Verify current advisories and patch applicability separately; do not report banner/version information alone.
- Route concrete auth differences to native authorization skills, not to automated CVE probing.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
