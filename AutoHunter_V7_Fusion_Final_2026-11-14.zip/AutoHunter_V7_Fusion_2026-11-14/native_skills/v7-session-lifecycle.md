---
name: v7-session-lifecycle
description: "Authorized session lifecycle differential; extra V7 offline/authorized guidance"
---
# Authorized session lifecycle differential

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Scope and setup
- Use two accounts you own and a clean, isolated browser profile for each. Document session type (cookie/JWT), account role and program restrictions before any replay.
- Record only redacted request identifiers, timestamps, response class and the intended session state; never copy live cookies, bearer tokens, OTPs or recovery links into notes or prompts.
## Focused hypotheses
1. **State transitions** — compare session validity before login, after login, after a legitimate logout and after password/email/MFA changes, within an account you control. A client-side sign-out is not proof of server revocation.
2. **Session binding** — check whether session identity changes during an authorized reauthentication and whether access granted to one of your owned accounts is isolated from the other.
3. **Refresh and expiry** — distinguish current session, refresh, and long-lived device identifiers. Inspect expired-session handling without load or brute-force testing.
4. **Role change** — for accounts and organizations you own, compare expected and observed privileges when roles are modified by an authorized administrator.
## Controls and evidence
- Pair each suspected failure with an equivalent allowed control and confirm whether backend authorization, not merely UI state, changed.
- Save redacted request/response references and timestamps; stop when a program excludes the action or when other user data could be accessed.
- Reject findings based solely on cookie attributes, missing frontend redirects or a stale browser cache. Report only demonstrable unauthorized persistence or access and the minimum proof.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
