---
name: v7-cross-tenant-matrix
description: "Multi-account authorization matrix; extra V7 offline/authorized guidance"
---
# Multi-account authorization matrix

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Setup
- Create an ownership matrix using only two or more expressly permitted testing identities and their own objects (A owns X, B owns Y, shared case S). Log each role and resource in a **redacted** ledger.
- Do not infer an authorization issue when a resource is missing or returns the same empty result for both users.
## Read-path analysis
- Compare own-resource control to cross-account target with identical method, session context, and resource state.
- Test only low-impact reads allowed by program rules. Record whether denial is at object, organization, environment, endpoint, method or API-version boundary.
## Write-path caution
- Any state modification requires an explicitly allowed disposable resource and human authorization. Never modify another customer's data, shared production assets, or funds.
## Evidence gate
- Require resource ownership proof, cross-account control, independently reproduced unauthorized response, and clear security impact.
- Status-code difference alone is an observation. Inconclusive, blocked or lacking a second populated account must remain labeled as such.
- Remove IDs and personal data from artifacts; retain only evidence references.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
