---
name: v7-ci-cd-trust-review
description: "CI/CD pipeline and artifact trust review; extra V7 offline/authorized guidance"
---
# CI/CD pipeline and artifact trust review

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Inventory
- From authorized public workflow YAML and project-owned repositories, identify trigger context, untrusted pull requests, permissions, artifact provenance, dependency source and identity federation trust rules.
## Review
- Check whether untrusted contributions can influence privileged jobs or build outputs; map approval, environment boundaries and runner trust.
- Evaluate repository secret scope and OIDC audience/subject configuration **offline** first; never request or use real cloud credentials discovered during review.
## Controls
- Use local mock workflows or owner-approved CI dry-runs only. Do not submit malicious PRs, poison package registries, or trigger production deploys.
## Evidence
- Document precise trust boundary, triggering role, configuration source, expected control and possible business impact.
- A dependency scanner result or historic advisory without reachable exploit conditions is not a confirmed finding.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
