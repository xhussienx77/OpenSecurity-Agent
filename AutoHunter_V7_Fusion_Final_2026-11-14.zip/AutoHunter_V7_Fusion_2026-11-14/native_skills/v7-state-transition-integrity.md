---
name: v7-state-transition-integrity
description: "Workflow and idempotency state modeling; extra V7 offline/authorized guidance"
---
# Workflow and idempotency state modeling

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Method
- Build a state machine from approved UI/API traffic: states, legal transitions, actors, expected invariants and server ownership checks.
- Focus on logically important but non-destructive boundaries: invitations created/revoked, single-use coupons, retry behavior, order states, or quota accounting in owned disposable data.
## Differential reasoning
- Identify whether a transition can skip validation, apply twice, or be executed by an unauthorized role. Use static analysis or offline test doubles as the first evidence source.
- Treat timeouts, client errors and retries as ambiguous until backend state is checked through permitted own-account views.
## Controls
- Compare before/after snapshots and a matching normal transition; record unique request IDs only if they are nonsecret.
- No high-rate concurrency, racing production payments, duplication of inventory, unwanted emails or third-party data manipulation.
## Result
- Produce hypotheses with preconditions, invariants, bounded verification questions and named blockers. Promote only independently reproduced unauthorized state changes.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
