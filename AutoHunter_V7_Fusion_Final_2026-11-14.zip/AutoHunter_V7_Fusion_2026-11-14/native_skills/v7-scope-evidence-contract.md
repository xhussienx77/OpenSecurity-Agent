---
name: v7-scope-evidence-contract
description: "Program scope and evidence decision contract; extra V7 offline/authorized guidance"
---
# Program scope and evidence decision contract

**Applies only to authorized, exact in-scope targets.** Program restrictions and project `AGENTS.md` override this material.

## Mandatory authorization
- Record current program URL, last operator verification date, explicitly listed targets, wildcard meaning, exclusions and permitted testing techniques.
- Treat unknown host, path, redirect destination and asset ownership as OUT-OF-SCOPE until verified independently. Include program-specific rate limits and prohibited impact types.
## Evidence classification
- OBSERVED: a response or source artifact exists, impact not demonstrated.
- CANDIDATE: a specific authorization or trust-boundary hypothesis with reproducible preconditions.
- INCONCLUSIVE: available controls do not demonstrate the hypothesized impact.
- CONFIRMED: independent reproduction on permitted resources, negative control, precise impact and redacted references.
- REPORTABLE: confirmed plus program acceptance, human review, clear steps, no known duplication and safe disclosure.
## Critical rules
- Never forge data, use target users, expose secrets, or escalate beyond approved proof; stop when post-exploitation or destructive impact would be required.
- A safety/provider refusal is not permission to retry through another model or API.
- Reporting is not a substitute for evidence. Good research may legitimately conclude zero reportable findings.

## Completion checklist
- [ ] Program scope and policy rechecked before any network action
- [ ] Negative control / evidence references or explicit blockers recorded
- [ ] Secrets and PII redacted; no unpermitted or state-changing tests
- [ ] Result classified without inventing a security impact
